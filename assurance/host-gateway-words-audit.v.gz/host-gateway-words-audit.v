From HostGateway Require Import GatewayFrames GatewayWordData GatewayWordsMemory GatewayWordsMath GatewayWordFamily GatewayWords GatewayReads GatewayWordReceipt.
Set Printing All.
Set Printing Depth 1000000.
Set Printing Width 1000000.
Redirect "word-type-0" Check @GatewayFrames.gateway_replace_memory_of.
Redirect "word-axioms-0" Print Assumptions GatewayFrames.gateway_replace_memory_of.
Redirect "word-type-1" Check @GatewayFrames.gateway_framed_same.
Redirect "word-axioms-1" Print Assumptions GatewayFrames.gateway_framed_same.
Redirect "word-type-2" Check @GatewayFrames.gateway_framed_post.
Redirect "word-axioms-2" Print Assumptions GatewayFrames.gateway_framed_post.
Redirect "word-type-3" Check @GatewayFrames.gateway_framed_replace.
Redirect "word-axioms-3" Print Assumptions GatewayFrames.gateway_framed_replace.
Redirect "word-type-4" Check @GatewayFrames.gateway_framed_step.
Redirect "word-axioms-4" Print Assumptions GatewayFrames.gateway_framed_step.
Redirect "word-type-5" Check @GatewayFrames.gateway_framed_prefix.
Redirect "word-axioms-5" Print Assumptions GatewayFrames.gateway_framed_prefix.
Redirect "word-type-6" Check @GatewayFrames.gateway_framed_return_exact.
Redirect "word-axioms-6" Print Assumptions GatewayFrames.gateway_framed_return_exact.
Redirect "word-type-7" Check @GatewayFrames.gateway_framed_execution.
Redirect "word-axioms-7" Print Assumptions GatewayFrames.gateway_framed_execution.
Redirect "word-type-8" Check @GatewayWordData.gateway_imported_add.
Redirect "word-axioms-8" Print Assumptions GatewayWordData.gateway_imported_add.
Redirect "word-type-9" Check @GatewayWordData.gateway_imported_mul.
Redirect "word-axioms-9" Print Assumptions GatewayWordData.gateway_imported_mul.
Redirect "word-type-10" Check @GatewayWordData.gateway_shared_decode.
Redirect "word-axioms-10" Print Assumptions GatewayWordData.gateway_shared_decode.
Redirect "word-type-11" Check @GatewayWordData.gateway_shared_length.
Redirect "word-axioms-11" Print Assumptions GatewayWordData.gateway_shared_length.
Redirect "word-type-12" Check @GatewayWordData.gateway_shared_bound.
Redirect "word-axioms-12" Print Assumptions GatewayWordData.gateway_shared_bound.
Redirect "word-type-13" Check @GatewayWordData.gateway_shared_encoding.
Redirect "word-axioms-13" Print Assumptions GatewayWordData.gateway_shared_encoding.
Redirect "word-type-14" Check @GatewayWordsMemory.gateway_bytes_initial.
Redirect "word-axioms-14" Print Assumptions GatewayWordsMemory.gateway_bytes_initial.
Redirect "word-type-15" Check @GatewayWordsMemory.gateway_bytes_ready_closed.
Redirect "word-axioms-15" Print Assumptions GatewayWordsMemory.gateway_bytes_ready_closed.
Redirect "word-type-16" Check @GatewayWordsMemory.gateway_bytes_store.
Redirect "word-axioms-16" Print Assumptions GatewayWordsMemory.gateway_bytes_store.
Redirect "word-type-17" Check @GatewayWordsMemory.gateway_single_byte_load.
Redirect "word-axioms-17" Print Assumptions GatewayWordsMemory.gateway_single_byte_load.
Redirect "word-type-18" Check @GatewayWordsMemory.gateway_loadbytes_from_loads.
Redirect "word-axioms-18" Print Assumptions GatewayWordsMemory.gateway_loadbytes_from_loads.
Redirect "word-type-19" Check @GatewayWordsMemory.gateway_bytes_complete.
Redirect "word-axioms-19" Print Assumptions GatewayWordsMemory.gateway_bytes_complete.
Redirect "word-type-20" Check @GatewayWordsMemory.gateway_pointer_index.
Redirect "word-axioms-20" Print Assumptions GatewayWordsMemory.gateway_pointer_index.
Redirect "word-type-21" Check @GatewayWordsMemory.gateway_read_ready_closed.
Redirect "word-axioms-21" Print Assumptions GatewayWordsMemory.gateway_read_ready_closed.
Redirect "word-type-22" Check @GatewayWordsMath.gateway_byte_unsigned.
Redirect "word-axioms-22" Print Assumptions GatewayWordsMath.gateway_byte_unsigned.
Redirect "word-type-23" Check @GatewayWordsMath.gateway_word_byte_exact.
Redirect "word-axioms-23" Print Assumptions GatewayWordsMath.gateway_word_byte_exact.
Redirect "word-type-24" Check @GatewayWordsMath.gateway_put32_byte_range.
Redirect "word-axioms-24" Print Assumptions GatewayWordsMath.gateway_put32_byte_range.
Redirect "word-type-25" Check @GatewayWordsMath.gateway_put64_byte_range.
Redirect "word-axioms-25" Print Assumptions GatewayWordsMath.gateway_put64_byte_range.
Redirect "word-type-26" Check @GatewayWordsMath.gateway_put32_decodes.
Redirect "word-axioms-26" Print Assumptions GatewayWordsMath.gateway_put32_decodes.
Redirect "word-type-27" Check @GatewayWordsMath.gateway_put64_decodes.
Redirect "word-axioms-27" Print Assumptions GatewayWordsMath.gateway_put64_decodes.
Redirect "word-type-28" Check @GatewayWordsMath.gateway_int_bytes_bounded.
Redirect "word-axioms-28" Print Assumptions GatewayWordsMath.gateway_int_bytes_bounded.
Redirect "word-type-29" Check @GatewayWordsMath.gateway_put32_encoding.
Redirect "word-axioms-29" Print Assumptions GatewayWordsMath.gateway_put32_encoding.
Redirect "word-type-30" Check @GatewayWordsMath.gateway_put64_encoding.
Redirect "word-axioms-30" Print Assumptions GatewayWordsMath.gateway_put64_encoding.
Redirect "word-type-31" Check @GatewayWordsMath.gateway_decode_cons.
Redirect "word-axioms-31" Print Assumptions GatewayWordsMath.gateway_decode_cons.
Redirect "word-type-32" Check @GatewayWordsMath.gateway_get_value_prefix.
Redirect "word-axioms-32" Print Assumptions GatewayWordsMath.gateway_get_value_prefix.
Redirect "word-type-33" Check @GatewayWordsMath.gateway_decode_bound.
Redirect "word-axioms-33" Print Assumptions GatewayWordsMath.gateway_decode_bound.
Redirect "word-type-34" Check @GatewayWordsMath.gateway_get_value_numeric.
Redirect "word-axioms-34" Print Assumptions GatewayWordsMath.gateway_get_value_numeric.
Redirect "word-type-35" Check @GatewayWordFamily.gateway_extended_closed.
Redirect "word-axioms-35" Print Assumptions GatewayWordFamily.gateway_extended_closed.
Redirect "word-type-36" Check @GatewayWordFamily.gateway_extended_store.
Redirect "word-axioms-36" Print Assumptions GatewayWordFamily.gateway_extended_store.
Redirect "word-type-37" Check @GatewayWordFamily.gateway_extended_initial.
Redirect "word-axioms-37" Print Assumptions GatewayWordFamily.gateway_extended_initial.
Redirect "word-type-38" Check @GatewayWords.gateway_writer_entry.
Redirect "word-axioms-38" Print Assumptions GatewayWords.gateway_writer_entry.
Redirect "word-type-39" Check @GatewayWords.gateway_put32_source_path.
Redirect "word-axioms-39" Print Assumptions GatewayWords.gateway_put32_source_path.
Redirect "word-type-40" Check @GatewayWords.gateway_put64_source_path.
Redirect "word-axioms-40" Print Assumptions GatewayWords.gateway_put64_source_path.
Redirect "word-type-41" Check @GatewayWords.gateway_put32_family.
Redirect "word-axioms-41" Print Assumptions GatewayWords.gateway_put32_family.
Redirect "word-type-42" Check @GatewayWords.gateway_put64_family.
Redirect "word-axioms-42" Print Assumptions GatewayWords.gateway_put64_family.
Redirect "word-type-43" Check @GatewayWords.gateway_put32_framed.
Redirect "word-axioms-43" Print Assumptions GatewayWords.gateway_put32_framed.
Redirect "word-type-44" Check @GatewayWords.gateway_put64_framed.
Redirect "word-axioms-44" Print Assumptions GatewayWords.gateway_put64_framed.
Redirect "word-type-45" Check @GatewayWords.gateway_put32_actual.
Redirect "word-axioms-45" Print Assumptions GatewayWords.gateway_put32_actual.
Redirect "word-type-46" Check @GatewayWords.gateway_put64_actual.
Redirect "word-axioms-46" Print Assumptions GatewayWords.gateway_put64_actual.
Redirect "word-type-47" Check @GatewayWords.gateway_put32_actual_readonly.
Redirect "word-axioms-47" Print Assumptions GatewayWords.gateway_put32_actual_readonly.
Redirect "word-type-48" Check @GatewayWords.gateway_put64_actual_readonly.
Redirect "word-axioms-48" Print Assumptions GatewayWords.gateway_put64_actual_readonly.
Redirect "word-type-49" Check @GatewayReads.gateway_reader_entry.
Redirect "word-axioms-49" Print Assumptions GatewayReads.gateway_reader_entry.
Redirect "word-type-50" Check @GatewayReads.gateway_get64_framed.
Redirect "word-axioms-50" Print Assumptions GatewayReads.gateway_get64_framed.
Redirect "word-type-51" Check @GatewayReads.gateway_read_ready_bounds.
Redirect "word-axioms-51" Print Assumptions GatewayReads.gateway_read_ready_bounds.
Redirect "word-type-52" Check @GatewayReads.gateway_get64_actual.
Redirect "word-axioms-52" Print Assumptions GatewayReads.gateway_get64_actual.
Redirect "word-type-53" Check @GatewayWordReceipt.gateway_native_memvals.
Redirect "word-axioms-53" Print Assumptions GatewayWordReceipt.gateway_native_memvals.
Redirect "word-type-54" Check @GatewayWordReceipt.gateway_native_naturals.
Redirect "word-axioms-54" Print Assumptions GatewayWordReceipt.gateway_native_naturals.
Redirect "word-type-55" Check @GatewayWordReceipt.gateway_words32_bound.
Redirect "word-axioms-55" Print Assumptions GatewayWordReceipt.gateway_words32_bound.
Redirect "word-type-56" Check @GatewayWordReceipt.gateway_words64_bound.
Redirect "word-axioms-56" Print Assumptions GatewayWordReceipt.gateway_words64_bound.
Redirect "word-type-57" Check @GatewayWordReceipt.gateway_put32_shared.
Redirect "word-axioms-57" Print Assumptions GatewayWordReceipt.gateway_put32_shared.
Redirect "word-type-58" Check @GatewayWordReceipt.gateway_put64_shared.
Redirect "word-axioms-58" Print Assumptions GatewayWordReceipt.gateway_put64_shared.
Redirect "word-type-59" Check @GatewayWordReceipt.gateway_ready_actual_bytes.
Redirect "word-axioms-59" Print Assumptions GatewayWordReceipt.gateway_ready_actual_bytes.
Redirect "word-type-60" Check @GatewayWordReceipt.gateway_get64_shared.
Redirect "word-axioms-60" Print Assumptions GatewayWordReceipt.gateway_get64_shared.
Redirect "word-type-61" Check @GatewayWordReceipt.gateway_put64_useful.
Redirect "word-axioms-61" Print Assumptions GatewayWordReceipt.gateway_put64_useful.
Redirect "word-type-62" Check @GatewayWordReceipt.gateway_read_ready_from_bytes.
Redirect "word-axioms-62" Print Assumptions GatewayWordReceipt.gateway_read_ready_from_bytes.
Redirect "word-type-63" Check @GatewayWordReceipt.gateway_put64_allocated.
Redirect "word-axioms-63" Print Assumptions GatewayWordReceipt.gateway_put64_allocated.
Redirect "word-interface-0" Print GatewayMachine.gateway_backend.
Redirect "word-interface-axioms-0" Print Assumptions GatewayMachine.gateway_backend.
Redirect "word-interface-1" Print GatewayFrames.gateway_private_contract.
Redirect "word-interface-axioms-1" Print Assumptions GatewayFrames.gateway_private_contract.
Redirect "word-interface-2" Print GatewayFrames.gateway_framed_path.
Redirect "word-interface-axioms-2" Print Assumptions GatewayFrames.gateway_framed_path.
Redirect "word-interface-3" Print GatewayWordsMemory.gateway_bytes_ready.
Redirect "word-interface-axioms-3" Print Assumptions GatewayWordsMemory.gateway_bytes_ready.
Redirect "word-interface-4" Print GatewayWordFamily.gateway_write_family.
Redirect "word-interface-axioms-4" Print Assumptions GatewayWordFamily.gateway_write_family.
Redirect "word-interface-5" Print GatewayWordFamily.gateway_disjoint_readonly.
Redirect "word-interface-axioms-5" Print Assumptions GatewayWordFamily.gateway_disjoint_readonly.
Redirect "word-interface-6" Print GatewayReads.gateway_get_initial.
Redirect "word-interface-axioms-6" Print Assumptions GatewayReads.gateway_get_initial.
Redirect "word-interface-7" Print GatewayWordReceipt.gateway_encoded_memory.
Redirect "word-interface-axioms-7" Print Assumptions GatewayWordReceipt.gateway_encoded_memory.
