from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
MODULES = ['GatewayPairCopyout', 'GatewayExchangePairOrigins', 'GatewayExchangeOriginSetup',
           'GatewayExchangeOriginPrepared', 'GatewayChannelPairSlices', 'GatewayChannelExecSource',
           'GatewayExchangeChannelSources']
ALLOWED = {'ClassicalDedekindReals.sig_forall_dec', 'ClassicalDedekindReals.sig_not_dec',
           'Classical_Prop.classic', 'FunctionalExtensionality.functional_extensionality_dep',
           'Events.external_functions_sem', 'Events.inline_assembly_sem'}
spec = importlib.util.spec_from_file_location('channel_origin_review_gateway', ROOT / 'verification/host/gateway.py')
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


sources = {}
pending = list(MODULES)
while pending:
    name = pending.pop()
    if name in sources:
        continue
    source = ROOT / 'verification/host' / (name + '.v')
    if not source.is_file():
        source = G.WORK / (name + '.v')
    cached = G.WORK / (name + '.v')
    assert source.read_bytes() == cached.read_bytes(), name
    sources[name] = {'path': str(source.relative_to(ROOT)), 'source': sha(source),
                     'object': sha(G.WORK / (name + '.vo'))}
    for group in re.findall(r'From\s+HostGateway\s+Require\s+Import\s+([A-Za-z0-9_\s]+)\.', source.read_text()):
        pending.extend(group.split())

declarations = []
for module in MODULES:
    stack = []
    for line in (ROOT / 'verification/host' / (module + '.v')).read_text().splitlines():
        begin = re.match(r'Module\s+([A-Za-z0-9_]+)\s*\.', line)
        end = re.match(r'End\s+([A-Za-z0-9_]+)\s*\.', line)
        if begin:
            stack.append(begin.group(1))
        elif end and stack and stack[-1] == end.group(1):
            stack.pop()
        declaration = re.match(r'(?:Theorem|Lemma|Definition|Fixpoint|Record|Inductive)\s+([A-Za-z0-9_]+)', line)
        if declaration:
            declarations.append('.'.join([module, *stack, declaration.group(1)]))

interfaces = [
    'GatewayPairCopyout.gateway_copyout_pair_birth',
    'GatewayPairCopyout.gateway_copyout_pair_slice',
    'GatewayPairCopyout.gateway_copyout_pairs_slice_ordered',
    'GatewayExchangeOriginSetup.PairOriginPrepared.gateway_exchange_spawn_frontier',
    'GatewayExchangeOriginSetup.PairOriginEntry.gateway_exchange_entry_frontier',
    'GatewayChannelExecSource.gateway_native_channels_checked',
]
critical_bodies = ['GatewayExchangeOriginPrepared.actual_exchange_entry_pair_origins',
                   'GatewayExchangeChannelSources.actual_exchange_entry_channel_sources',
                   'GatewayChannelPairSlices.gateway_ordered_pair_slices_native_uses',
                   'GatewayChannelExecSource.gateway_actual_source_pair_exec_channels']
lines = ['From HostGateway Require Import ' + ' '.join(MODULES) + '.',
         'Set Printing All.', 'Set Printing Depth 1000000.', 'Set Printing Width 120.']
for index, name in enumerate(declarations):
    lines += [f'Redirect "origin-{index:03}-type" Check @{name}.',
              f'Redirect "origin-{index:03}-axioms" Print Assumptions {name}.']
for index, name in enumerate(interfaces):
    lines.append(f'Redirect "origin-interface-{index:02}" Print {name}.')
for index, name in enumerate(critical_bodies):
    lines.append(f'Redirect "origin-body-{index:02}" Print {name}.')
query = WORK / 'GatewayChannelOriginQuery.v'
query.write_text('\n'.join(lines) + '\n')
flags = G.flags() + ['-Q', str(WORK), 'HostChannelAudit']
result = G.PROFILE.run(['rocq', 'c', '-q', *flags, str(query)], cwd=WORK, timeout=120)
(WORK / 'query.log').write_text(result.stdout)
records = []
for index, name in enumerate(declarations):
    assumptions = (WORK / f'origin-{index:03}-axioms.out').read_text()
    axioms, uip = G.CONNECTION.foundations(assumptions)
    assert set(axioms) <= ALLOWED, (name, axioms)
    assert set(uip) <= {'Lean.eq'}, (name, uip)
    records.append({'name': name, 'type': (WORK / f'origin-{index:03}-type.out').read_text(),
                    'assumptions': assumptions, 'axioms': axioms, 'definitional_uip': uip})
command = ['rocq', 'check', '-silent', *G.flags(checker=True), '-Q', str(WORK), 'HostChannelAudit',
           'HostChannelAudit.GatewayChannelOriginQuery']
result = G.PROFILE.run(command, cwd=WORK, timeout=120)
(WORK / 'kernel.log').write_text(result.stdout)
for name, row in sources.items():
    assert sha(ROOT / row['path']) == row['source'], name
    assert sha(G.WORK / (name + '.vo')) == row['object'], name
review = {
    'schema': 'leancage-host-channel-source-origins-review-v1',
    'accepted_security_delivery': False,
    'scope': 'Actual original exchange entry to ordered socketpair copyouts, the same pending spawn key/operands, and actual same-birth/exec channel evidence without a future spawn reply.',
    'declarations': records,
    'interfaces': {name: (WORK / f'origin-interface-{index:02}.out').read_text() for index, name in enumerate(interfaces)},
    'critical_bodies': {name: (WORK / f'origin-body-{index:02}.out').read_text() for index, name in enumerate(critical_bodies)},
    'source_objects': sources,
    'current_c_sha256': sha(ROOT / 'linux/host_python.c'),
    'current_clight_sha256': sha(G.WORK / 'GatewaySource.v'),
    'strict_data': {name: sha(G.WORK / name) for name in ['gateway-code.ndjson', 'native-code.ndjson']},
    'kernel_check': {'command': command, 'exit_code': 0, 'stdout_sha256': sha(WORK / 'kernel.log')},
    'remaining_application_producers': [
        'Route each actual global engine handoff to this precise C source invocation and its same stored native rows.',
        'Produce per-operation native source guards and SDK/pre-exec/foreign read/discard classifications, retaining all full-table/support references.',
        'Construct the exact SourceChannelJournal pending commit/ACK/loss annotation and original terminal receive routing.',
        'Instantiate the observed surviving-activation runtime domain; old-image continuations do not resume after callback exec/exit.',
        'Compose actual engine writer, private reply queue, native parser/EOF/reap and public returned result; no whole-host acceptance follows from this source component.'
    ],
}
(WORK / 'review.candidate.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
summary = {'status': 'passed', 'declarations': len(records), 'interfaces': len(interfaces),
           'axioms': sorted({a for row in records for a in row['axioms']}),
           'kernel_exit_code': 0, 'input_drift': []}
(WORK / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
