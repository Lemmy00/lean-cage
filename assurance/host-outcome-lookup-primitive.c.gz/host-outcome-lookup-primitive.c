#include <Python.h>

typedef struct {
    PyMemAllocatorEx original;
    int failures;
} fail_once;

static void *f_malloc(void *context, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.malloc(state->original.ctx, size);
}
static void *f_calloc(void *context, size_t count, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.calloc(state->original.ctx, count, size);
}
static void *f_realloc(void *context, void *pointer, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.realloc(state->original.ctx, pointer, size);
}
static void f_free(void *context, void *pointer) {
    fail_once *state = context;
    state->original.free(state->original.ctx, pointer);
}
static PyObject *probe(PyObject *self, PyObject *dictionary) {
    (void)self;
    if (!PyDict_CheckExact(dictionary) || !PyDict_GetItemString(dictionary, "output")) {
        PyErr_SetString(PyExc_ValueError, "exact dictionary with output is required");
        return NULL;
    }
    fail_once state = {0};
    PyMem_GetAllocator(PYMEM_DOMAIN_OBJ, &state.original);
    PyMemAllocatorEx replacement = {&state, f_malloc, f_calloc, f_realloc, f_free};
    PyMem_SetAllocator(PYMEM_DOMAIN_OBJ, &replacement);
    PyObject *value = PyDict_GetItemString(dictionary, "output");
    int was_null = value == NULL;
    int pending = PyErr_Occurred() != NULL;
    PyMem_SetAllocator(PYMEM_DOMAIN_OBJ, &state.original);
    PyErr_Clear();
    int retained = PyDict_GetItemString(dictionary, "output") != NULL;
    return Py_BuildValue("{s:i,s:i,s:i,s:i}", "failure_injected", state.failures,
                        "returned_null", was_null, "pending_error", pending,
                        "present_after_restore", retained);
}
static PyMethodDef methods[] = {{"probe", probe, METH_O, NULL}, {NULL, NULL, 0, NULL}};
static struct PyModuleDef module = {PyModuleDef_HEAD_INIT, "_lookup_failure", NULL, -1, methods};
PyMODINIT_FUNC PyInit__lookup_failure(void) { return PyModule_Create(&module); }
