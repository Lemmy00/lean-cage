import FilesystemNativeDecoding
import FilesystemBoundaryAuthority
import FilesystemAnchorHistory

set_option pp.universes true
set_option pp.explicit true

#check @LeanCage.Host.Kernel.NativeVfsOperation
#print axioms LeanCage.Host.Kernel.NativeVfsOperation

#check @LeanCage.Host.Kernel.NativePrimitive
#print axioms LeanCage.Host.Kernel.NativePrimitive

#check @LeanCage.Host.Kernel.NativePathSetter
#print axioms LeanCage.Host.Kernel.NativePathSetter

#check @LeanCage.Host.Kernel.NativeCallPathTarget
#print axioms LeanCage.Host.Kernel.NativeCallPathTarget

#check @LeanCage.Host.Kernel.NativeCallAuthorityTarget
#print axioms LeanCage.Host.Kernel.NativeCallAuthorityTarget

#check @LeanCage.Host.Kernel.NativeMetadataContract
#print axioms LeanCage.Host.Kernel.NativeMetadataContract

#check @LeanCage.Host.Kernel.NativeAuthorityProfile
#print axioms LeanCage.Host.Kernel.NativeAuthorityProfile

#check @LeanCage.Host.Kernel.NativeBoundaryAuthorityProfile
#print axioms LeanCage.Host.Kernel.NativeBoundaryAuthorityProfile

#check @LeanCage.Host.Kernel.NativeAnchorProfile
#print axioms LeanCage.Host.Kernel.NativeAnchorProfile

#check @LeanCage.Host.Kernel.path_setter_not_fd_target
#print axioms LeanCage.Host.Kernel.path_setter_not_fd_target

#check @LeanCage.Host.Kernel.NativeCallAuthorityTarget.path_iff
#print axioms LeanCage.Host.Kernel.NativeCallAuthorityTarget.path_iff

#check @LeanCage.Host.Kernel.native_active_parent_authority
#print axioms LeanCage.Host.Kernel.native_active_parent_authority

#check @LeanCage.Host.Kernel.native_boundary_parent_authority
#print axioms LeanCage.Host.Kernel.native_boundary_parent_authority

#check @LeanCage.Host.Kernel.system_anchor_step
#print axioms LeanCage.Host.Kernel.system_anchor_step

#check @LeanCage.Host.NativeCode.vfs_roundtrip
#print axioms LeanCage.Host.NativeCode.vfs_roundtrip

#check @LeanCage.Host.NativeCode.vfs_exact
#print axioms LeanCage.Host.NativeCode.vfs_exact

#check @LeanCage.Host.NativeCode.operation_exact
#print axioms LeanCage.Host.NativeCode.operation_exact

#check @LeanCage.Host.NativeCode.operation_decode_iff
#print axioms LeanCage.Host.NativeCode.operation_decode_iff

#print LeanCage.Host.Kernel.NativeVfsOperation

#print LeanCage.Host.Kernel.NativePrimitive

#print LeanCage.Host.Kernel.NativePathSetter

#print LeanCage.Host.Kernel.NativeCallPathTarget

#print LeanCage.Host.Kernel.NativeCallAuthorityTarget

#print LeanCage.Host.Kernel.NativeMetadataContract

#print LeanCage.Host.Kernel.NativeAuthorityProfile

#print LeanCage.Host.Kernel.NativeBoundaryAuthorityProfile

#print LeanCage.Host.Kernel.NativeAnchorProfile
