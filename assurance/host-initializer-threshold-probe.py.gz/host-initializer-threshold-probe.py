import gc
import importlib.util
import json
from pathlib import Path
import sys

extension = Path('/localhome/milikic/sandbox-formalization/.tools/host/gateway/initialization-runtime/python/leancage/_host.abi3.so')
threshold = int(sys.argv[1])
events = []
seen = set()
returned = False


def observe(phase, information):
    if returned:
        return
    names = tuple(sorted(type.__getattribute__(candidate, '__name__')
        for candidate in object.__subclasses__()
        if type.__getattribute__(candidate, '__module__') == 'leancage._host'))
    if names not in seen:
        seen.add(names)
        events.append(dict(names=names, phase=phase, module_from_spec_returned=returned))


spec = importlib.util.spec_from_file_location('threshold_probe._host', str(extension))
gc.callbacks.append(observe)
gc.set_threshold(threshold, 1, 1)
try:
    module = importlib.util.module_from_spec(spec)
    returned = True
finally:
    gc.callbacks.remove(observe)
spec.loader.exec_module(module)
print(json.dumps(dict(threshold=threshold, events=events,
    partial_type_set_observed=any('Workspace' in event['names'] and 'Outcome' not in event['names']
                                  for event in events),
    scope='bounded read-only GC threshold probe; no constructors, engine, VM or workload')))
