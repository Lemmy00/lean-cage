From Coq Require Import String List ZArith.
From compcert Require Import Coqlib Integers Floats AST Ctypes Cop Clight Clightdefs.
Import Clightdefs.ClightNotations.
Local Open Scope Z_scope.
Local Open Scope string_scope.
Local Open Scope clight_scope.

Module Info.
  Definition version := "3.17".
  Definition build_number := "".
  Definition build_tag := "".
  Definition build_branch := "".
  Definition arch := "x86".
  Definition model := "64".
  Definition abi := "standard".
  Definition bitsize := 64.
  Definition big_endian := false.
  Definition source_file := "slice.c".
  Definition normalized := true.
End Info.

Definition ___builtin_ais_annot : ident := $"__builtin_ais_annot".
Definition ___builtin_annot : ident := $"__builtin_annot".
Definition ___builtin_annot_intval : ident := $"__builtin_annot_intval".
Definition ___builtin_bswap : ident := $"__builtin_bswap".
Definition ___builtin_bswap16 : ident := $"__builtin_bswap16".
Definition ___builtin_bswap32 : ident := $"__builtin_bswap32".
Definition ___builtin_bswap64 : ident := $"__builtin_bswap64".
Definition ___builtin_clz : ident := $"__builtin_clz".
Definition ___builtin_clzl : ident := $"__builtin_clzl".
Definition ___builtin_clzll : ident := $"__builtin_clzll".
Definition ___builtin_ctz : ident := $"__builtin_ctz".
Definition ___builtin_ctzl : ident := $"__builtin_ctzl".
Definition ___builtin_ctzll : ident := $"__builtin_ctzll".
Definition ___builtin_debug : ident := $"__builtin_debug".
Definition ___builtin_expect : ident := $"__builtin_expect".
Definition ___builtin_fabs : ident := $"__builtin_fabs".
Definition ___builtin_fabsf : ident := $"__builtin_fabsf".
Definition ___builtin_fmadd : ident := $"__builtin_fmadd".
Definition ___builtin_fmax : ident := $"__builtin_fmax".
Definition ___builtin_fmin : ident := $"__builtin_fmin".
Definition ___builtin_fmsub : ident := $"__builtin_fmsub".
Definition ___builtin_fnmadd : ident := $"__builtin_fnmadd".
Definition ___builtin_fnmsub : ident := $"__builtin_fnmsub".
Definition ___builtin_fsqrt : ident := $"__builtin_fsqrt".
Definition ___builtin_membar : ident := $"__builtin_membar".
Definition ___builtin_memcpy_aligned : ident := $"__builtin_memcpy_aligned".
Definition ___builtin_read16_reversed : ident := $"__builtin_read16_reversed".
Definition ___builtin_read32_reversed : ident := $"__builtin_read32_reversed".
Definition ___builtin_sel : ident := $"__builtin_sel".
Definition ___builtin_sqrt : ident := $"__builtin_sqrt".
Definition ___builtin_unreachable : ident := $"__builtin_unreachable".
Definition ___builtin_va_arg : ident := $"__builtin_va_arg".
Definition ___builtin_va_copy : ident := $"__builtin_va_copy".
Definition ___builtin_va_end : ident := $"__builtin_va_end".
Definition ___builtin_va_start : ident := $"__builtin_va_start".
Definition ___builtin_write16_reversed : ident := $"__builtin_write16_reversed".
Definition ___builtin_write32_reversed : ident := $"__builtin_write32_reversed".
Definition ___compcert_i64_dtos : ident := $"__compcert_i64_dtos".
Definition ___compcert_i64_dtou : ident := $"__compcert_i64_dtou".
Definition ___compcert_i64_sar : ident := $"__compcert_i64_sar".
Definition ___compcert_i64_sdiv : ident := $"__compcert_i64_sdiv".
Definition ___compcert_i64_shl : ident := $"__compcert_i64_shl".
Definition ___compcert_i64_shr : ident := $"__compcert_i64_shr".
Definition ___compcert_i64_smod : ident := $"__compcert_i64_smod".
Definition ___compcert_i64_smulh : ident := $"__compcert_i64_smulh".
Definition ___compcert_i64_stod : ident := $"__compcert_i64_stod".
Definition ___compcert_i64_stof : ident := $"__compcert_i64_stof".
Definition ___compcert_i64_udiv : ident := $"__compcert_i64_udiv".
Definition ___compcert_i64_umod : ident := $"__compcert_i64_umod".
Definition ___compcert_i64_umulh : ident := $"__compcert_i64_umulh".
Definition ___compcert_i64_utod : ident := $"__compcert_i64_utod".
Definition ___compcert_i64_utof : ident := $"__compcert_i64_utof".
Definition ___compcert_va_composite : ident := $"__compcert_va_composite".
Definition ___compcert_va_float64 : ident := $"__compcert_va_float64".
Definition ___compcert_va_int32 : ident := $"__compcert_va_int32".
Definition ___compcert_va_int64 : ident := $"__compcert_va_int64".
Definition ___compound : ident := $"__compound".
Definition ___errno_location : ident := $"__errno_location".
Definition ___stringlit_1 : ident := $"__stringlit_1".
Definition ___stringlit_2 : ident := $"__stringlit_2".
Definition ___stringlit_3 : ident := $"__stringlit_3".
Definition ___stringlit_4 : ident := $"__stringlit_4".
Definition ___stringlit_5 : ident := $"__stringlit_5".
Definition ___stringlit_6 : ident := $"__stringlit_6".
Definition ___stringlit_7 : ident := $"__stringlit_7".
Definition ___stringlit_8 : ident := $"__stringlit_8".
Definition ___stringlit_9 : ident := $"__stringlit_9".
Definition __exit : ident := $"_exit".
Definition __res : ident := $"_res".
Definition __res__1 : ident := $"_res__1".
Definition __res__2 : ident := $"_res__2".
Definition __res__3 : ident := $"_res__3".
Definition __res__4 : ident := $"_res__4".
Definition _bad : ident := $"bad".
Definition _bytes : ident := $"bytes".
Definition _clean : ident := $"clean".
Definition _close : ident := $"close".
Definition _count : ident := $"count".
Definition _cpu : ident := $"cpu".
Definition _data : ident := $"data".
Definition _decode_frame : ident := $"decode_frame".
Definition _detail : ident := $"detail".
Definition _elapsed : ident := $"elapsed".
Definition _entered : ident := $"entered".
Definition _entry : ident := $"entry".
Definition _err : ident := $"err".
Definition _error : ident := $"error".
Definition _error_number : ident := $"error_number".
Definition _export_digest : ident := $"export_digest".
Definition _export_error : ident := $"export_error".
Definition _export_state : ident := $"export_state".
Definition _fail_child : ident := $"fail_child".
Definition _failure_bytes : ident := $"failure_bytes".
Definition _fault : ident := $"fault".
Definition _fd : ident := $"fd".
Definition _finish : ident := $"finish".
Definition _get32 : ident := $"get32".
Definition _get64 : ident := $"get64".
Definition _i : ident := $"i".
Definition _i__1 : ident := $"i__1".
Definition _kind : ident := $"kind".
Definition _leader_done : ident := $"leader_done".
Definition _leader_status : ident := $"leader_status".
Definition _m4_collect_failure : ident := $"m4_collect_failure".
Definition _m4_roots : ident := $"m4_roots".
Definition _main : ident := $"main".
Definition _memcmp : ident := $"memcmp".
Definition _memcpy : ident := $"memcpy".
Definition _mode : ident := $"mode".
Definition _n : ident := $"n".
Definition _name : ident := $"name".
Definition _omitted : ident := $"omitted".
Definition _oom : ident := $"oom".
Definition _out : ident := $"out".
Definition _p : ident := $"p".
Definition _peak : ident := $"peak".
Definition _pids : ident := $"pids".
Definition _pipefd : ident := $"pipefd".
Definition _preflight : ident := $"preflight".
Definition _put32 : ident := $"put32".
Definition _put64 : ident := $"put64".
Definition _r : ident := $"r".
Definition _read : ident := $"read".
Definition _result : ident := $"result".
Definition _result__1 : ident := $"result__1".
Definition _result_of : ident := $"result_of".
Definition _run : ident := $"run".
Definition _run_id : ident := $"run_id".
Definition _run_uid : ident := $"run_uid".
Definition _send_frame : ident := $"send_frame".
Definition _sequence : ident := $"sequence".
Definition _stage : ident := $"stage".
Definition _strcmp : ident := $"strcmp".
Definition _triggers : ident := $"triggers".
Definition _uid : ident := $"uid".
Definition _used : ident := $"used".
Definition _write : ident := $"write".
Definition _write_all : ident := $"write_all".
Definition _x : ident := $"x".
Definition _t'1 : ident := 128%positive.
Definition _t'10 : ident := 137%positive.
Definition _t'11 : ident := 138%positive.
Definition _t'12 : ident := 139%positive.
Definition _t'13 : ident := 140%positive.
Definition _t'14 : ident := 141%positive.
Definition _t'15 : ident := 142%positive.
Definition _t'16 : ident := 143%positive.
Definition _t'17 : ident := 144%positive.
Definition _t'18 : ident := 145%positive.
Definition _t'19 : ident := 146%positive.
Definition _t'2 : ident := 129%positive.
Definition _t'20 : ident := 147%positive.
Definition _t'21 : ident := 148%positive.
Definition _t'22 : ident := 149%positive.
Definition _t'23 : ident := 150%positive.
Definition _t'24 : ident := 151%positive.
Definition _t'25 : ident := 152%positive.
Definition _t'26 : ident := 153%positive.
Definition _t'27 : ident := 154%positive.
Definition _t'28 : ident := 155%positive.
Definition _t'29 : ident := 156%positive.
Definition _t'3 : ident := 130%positive.
Definition _t'30 : ident := 157%positive.
Definition _t'31 : ident := 158%positive.
Definition _t'32 : ident := 159%positive.
Definition _t'33 : ident := 160%positive.
Definition _t'34 : ident := 161%positive.
Definition _t'35 : ident := 162%positive.
Definition _t'36 : ident := 163%positive.
Definition _t'37 : ident := 164%positive.
Definition _t'38 : ident := 165%positive.
Definition _t'39 : ident := 166%positive.
Definition _t'4 : ident := 131%positive.
Definition _t'40 : ident := 167%positive.
Definition _t'41 : ident := 168%positive.
Definition _t'42 : ident := 169%positive.
Definition _t'43 : ident := 170%positive.
Definition _t'44 : ident := 171%positive.
Definition _t'45 : ident := 172%positive.
Definition _t'46 : ident := 173%positive.
Definition _t'47 : ident := 174%positive.
Definition _t'48 : ident := 175%positive.
Definition _t'49 : ident := 176%positive.
Definition _t'5 : ident := 132%positive.
Definition _t'50 : ident := 177%positive.
Definition _t'51 : ident := 178%positive.
Definition _t'52 : ident := 179%positive.
Definition _t'53 : ident := 180%positive.
Definition _t'54 : ident := 181%positive.
Definition _t'55 : ident := 182%positive.
Definition _t'56 : ident := 183%positive.
Definition _t'57 : ident := 184%positive.
Definition _t'58 : ident := 185%positive.
Definition _t'59 : ident := 186%positive.
Definition _t'6 : ident := 133%positive.
Definition _t'60 : ident := 187%positive.
Definition _t'61 : ident := 188%positive.
Definition _t'62 : ident := 189%positive.
Definition _t'63 : ident := 190%positive.
Definition _t'64 : ident := 191%positive.
Definition _t'65 : ident := 192%positive.
Definition _t'66 : ident := 193%positive.
Definition _t'67 : ident := 194%positive.
Definition _t'68 : ident := 195%positive.
Definition _t'69 : ident := 196%positive.
Definition _t'7 : ident := 134%positive.
Definition _t'70 : ident := 197%positive.
Definition _t'71 : ident := 198%positive.
Definition _t'72 : ident := 199%positive.
Definition _t'73 : ident := 200%positive.
Definition _t'74 : ident := 201%positive.
Definition _t'75 : ident := 202%positive.
Definition _t'76 : ident := 203%positive.
Definition _t'77 : ident := 204%positive.
Definition _t'78 : ident := 205%positive.
Definition _t'79 : ident := 206%positive.
Definition _t'8 : ident := 135%positive.
Definition _t'80 : ident := 207%positive.
Definition _t'81 : ident := 208%positive.
Definition _t'82 : ident := 209%positive.
Definition _t'83 : ident := 210%positive.
Definition _t'84 : ident := 211%positive.
Definition _t'85 : ident := 212%positive.
Definition _t'86 : ident := 213%positive.
Definition _t'87 : ident := 214%positive.
Definition _t'88 : ident := 215%positive.
Definition _t'89 : ident := 216%positive.
Definition _t'9 : ident := 136%positive.
Definition _t'90 : ident := 217%positive.
Definition _t'91 : ident := 218%positive.
Definition _t'92 : ident := 219%positive.
Definition _t'93 : ident := 220%positive.
Definition _t'94 : ident := 221%positive.
Definition _t'95 : ident := 222%positive.
Definition _t'96 : ident := 223%positive.
Definition _t'97 : ident := 224%positive.
Definition _t'98 : ident := 225%positive.
Definition _t'99 : ident := 226%positive.

Definition v___stringlit_7 := {|
  gvar_info := (tarray tschar 12);
  gvar_init := (Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_8 := {|
  gvar_info := (tarray tschar 11);
  gvar_init := (Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 95) ::
                Init_int8 (Int.repr 100) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 112) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_1 := {|
  gvar_info := (tarray tschar 7);
  gvar_init := (Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 109) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 108) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_9 := {|
  gvar_info := (tarray tschar 12);
  gvar_init := (Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 95) ::
                Init_int8 (Int.repr 115) :: Init_int8 (Int.repr 104) ::
                Init_int8 (Int.repr 111) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_3 := {|
  gvar_info := (tarray tschar 17);
  gvar_init := (Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 119) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 110) :: Init_int8 (Int.repr 103) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 113) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_2 := {|
  gvar_info := (tarray tschar 5);
  gvar_init := (Init_int8 (Int.repr 76) :: Init_int8 (Int.repr 67) ::
                Init_int8 (Int.repr 51) :: Init_int8 (Int.repr 82) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_6 := {|
  gvar_info := (tarray tschar 13);
  gvar_init := (Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 104) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_5 := {|
  gvar_info := (tarray tschar 17);
  gvar_init := (Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 117) :: Init_int8 (Int.repr 112) ::
                Init_int8 (Int.repr 108) :: Init_int8 (Int.repr 105) ::
                Init_int8 (Int.repr 99) :: Init_int8 (Int.repr 97) ::
                Init_int8 (Int.repr 116) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v___stringlit_4 := {|
  gvar_info := (tarray tschar 20);
  gvar_init := (Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 112) :: Init_int8 (Int.repr 111) ::
                Init_int8 (Int.repr 114) :: Init_int8 (Int.repr 116) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 98) ::
                Init_int8 (Int.repr 97) :: Init_int8 (Int.repr 100) ::
                Init_int8 (Int.repr 95) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 115) ::
                Init_int8 (Int.repr 101) :: Init_int8 (Int.repr 114) ::
                Init_int8 (Int.repr 118) :: Init_int8 (Int.repr 101) ::
                Init_int8 (Int.repr 100) :: Init_int8 (Int.repr 0) :: nil);
  gvar_readonly := true;
  gvar_volatile := false
|}.

Definition v_run_id := {|
  gvar_info := tulong;
  gvar_init := (Init_space 8 :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition v_mode := {|
  gvar_info := (tptr tschar);
  gvar_init := (Init_addrof ___stringlit_1 (Ptrofs.repr 0) :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition v_preflight := {|
  gvar_info := tint;
  gvar_init := (Init_space 4 :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition v_run_uid := {|
  gvar_info := tuint;
  gvar_init := (Init_space 4 :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition f_fault := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_name, (tptr tschar)) :: nil);
  fn_vars := nil;
  fn_temps := ((_t'1, tint) :: (_t'2, (tptr tschar)) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Sset _t'2 (Evar _mode (tptr tschar)))
    (Scall (Some _t'1)
      (Evar _strcmp (Tfunction ((tptr tschar) :: (tptr tschar) :: nil) tint
                      cc_default))
      ((Etempvar _t'2 (tptr tschar)) :: (Etempvar _name (tptr tschar)) ::
       nil)))
  (Sreturn (Some (Ebinop Oeq (Etempvar _t'1 tint)
                   (Econst_int (Int.repr 0) tint) tint))))
|}.

Definition f_error_number := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := nil;
  fn_vars := nil;
  fn_temps := ((_t'5, (tptr tint)) :: (_t'4, tint) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, (tptr tint)) :: (_t'8, tint) ::
               (_t'7, tint) :: (_t'6, tint) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Ssequence
      (Scall (Some _t'1)
        (Evar ___errno_location (Tfunction nil (tptr tint) cc_default)) nil)
      (Ssequence
        (Sset _t'7 (Ederef (Etempvar _t'1 (tptr tint)) tint))
        (Sifthenelse (Ebinop Ogt (Etempvar _t'7 tint)
                       (Econst_int (Int.repr 0) tint) tint)
          (Ssequence
            (Scall (Some _t'3)
              (Evar ___errno_location (Tfunction nil (tptr tint) cc_default))
              nil)
            (Ssequence
              (Sset _t'8 (Ederef (Etempvar _t'3 (tptr tint)) tint))
              (Sset _t'2
                (Ecast
                  (Ebinop Ole (Etempvar _t'8 tint)
                    (Econst_int (Int.repr 4095) tint) tint) tbool))))
          (Sset _t'2 (Econst_int (Int.repr 0) tint)))))
    (Sifthenelse (Etempvar _t'2 tint)
      (Ssequence
        (Scall (Some _t'5)
          (Evar ___errno_location (Tfunction nil (tptr tint) cc_default))
          nil)
        (Ssequence
          (Sset _t'6 (Ederef (Etempvar _t'5 (tptr tint)) tint))
          (Sset _t'4 (Ecast (Etempvar _t'6 tint) tint))))
      (Sset _t'4 (Ecast (Econst_int (Int.repr 5) tint) tint))))
  (Sreturn (Some (Etempvar _t'4 tint))))
|}.

Definition f_write_all := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_data, (tptr tvoid)) :: (_count, tulong) ::
                nil);
  fn_vars := nil;
  fn_temps := ((_p, (tptr tuchar)) :: (_n, tlong) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, tlong) :: (_t'4, tint) :: nil);
  fn_body :=
(Ssequence
  (Sset _p (Etempvar _data (tptr tvoid)))
  (Ssequence
    (Swhile
      (Etempvar _count tulong)
      (Ssequence
        (Ssequence
          (Scall (Some _t'1)
            (Evar _write (Tfunction (tint :: (tptr tvoid) :: tulong :: nil)
                           tlong cc_default))
            ((Etempvar _fd tint) :: (Etempvar _p (tptr tuchar)) ::
             (Etempvar _count tulong) :: nil))
          (Sset _n (Etempvar _t'1 tlong)))
        (Ssequence
          (Ssequence
            (Sifthenelse (Ebinop Olt (Etempvar _n tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Ssequence
                (Scall (Some _t'3)
                  (Evar ___errno_location (Tfunction nil (tptr tint)
                                            cc_default)) nil)
                (Ssequence
                  (Sset _t'4 (Ederef (Etempvar _t'3 (tptr tint)) tint))
                  (Sset _t'2
                    (Ecast
                      (Ebinop Oeq (Etempvar _t'4 tint)
                        (Econst_int (Int.repr 4) tint) tint) tbool))))
              (Sset _t'2 (Econst_int (Int.repr 0) tint)))
            (Sifthenelse (Etempvar _t'2 tint) Scontinue Sskip))
          (Ssequence
            (Sifthenelse (Ebinop Ole (Etempvar _n tlong)
                           (Econst_int (Int.repr 0) tint) tint)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip)
            (Ssequence
              (Sset _p
                (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _n tlong)
                  (tptr tuchar)))
              (Sset _count
                (Ebinop Osub (Etempvar _count tulong)
                  (Ecast (Etempvar _n tlong) tulong) tulong)))))))
    (Sreturn (Some (Econst_int (Int.repr 0) tint)))))
|}.

Definition f_put32 := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := ((_p, (tptr tuchar)) :: (_x, tuint) :: nil);
  fn_vars := nil;
  fn_temps := ((_i, tint) :: nil);
  fn_body :=
(Ssequence
  (Sset _i (Econst_int (Int.repr 0) tint))
  (Sloop
    (Ssequence
      (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                     (Econst_int (Int.repr 4) tint) tint)
        Sskip
        Sbreak)
      (Sassign
        (Ederef
          (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _i tint)
            (tptr tuchar)) tuchar)
        (Ecast
          (Ebinop Oshr (Etempvar _x tuint)
            (Ebinop Omul (Econst_int (Int.repr 8) tint) (Etempvar _i tint)
              tint) tuint) tuchar)))
    (Sset _i
      (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint) tint))))
|}.

Definition f_put64 := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := ((_p, (tptr tuchar)) :: (_x, tulong) :: nil);
  fn_vars := nil;
  fn_temps := ((_i, tint) :: nil);
  fn_body :=
(Ssequence
  (Sset _i (Econst_int (Int.repr 0) tint))
  (Sloop
    (Ssequence
      (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                     (Econst_int (Int.repr 8) tint) tint)
        Sskip
        Sbreak)
      (Sassign
        (Ederef
          (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _i tint)
            (tptr tuchar)) tuchar)
        (Ecast
          (Ebinop Oshr (Etempvar _x tulong)
            (Ebinop Omul (Econst_int (Int.repr 8) tint) (Etempvar _i tint)
              tint) tulong) tuchar)))
    (Sset _i
      (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint) tint))))
|}.

Definition f_get32 := {|
  fn_return := tuint;
  fn_callconv := cc_default;
  fn_params := ((_p, (tptr tuchar)) :: nil);
  fn_vars := nil;
  fn_temps := ((_x, tuint) :: (_i, tint) :: (_t'1, tuchar) :: nil);
  fn_body :=
(Ssequence
  (Sset _x (Econst_int (Int.repr 0) tint))
  (Ssequence
    (Ssequence
      (Sset _i (Econst_int (Int.repr 0) tint))
      (Sloop
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                         (Econst_int (Int.repr 4) tint) tint)
            Sskip
            Sbreak)
          (Ssequence
            (Sset _t'1
              (Ederef
                (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _i tint)
                  (tptr tuchar)) tuchar))
            (Sset _x
              (Ebinop Oor (Etempvar _x tuint)
                (Ebinop Oshl (Ecast (Etempvar _t'1 tuchar) tuint)
                  (Ebinop Omul (Econst_int (Int.repr 8) tint)
                    (Etempvar _i tint) tint) tuint) tuint))))
        (Sset _i
          (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
            tint))))
    (Sreturn (Some (Etempvar _x tuint)))))
|}.

Definition f_get64 := {|
  fn_return := tulong;
  fn_callconv := cc_default;
  fn_params := ((_p, (tptr tuchar)) :: nil);
  fn_vars := nil;
  fn_temps := ((_x, tulong) :: (_i, tint) :: (_t'1, tuchar) :: nil);
  fn_body :=
(Ssequence
  (Sset _x (Ecast (Econst_int (Int.repr 0) tint) tulong))
  (Ssequence
    (Ssequence
      (Sset _i (Econst_int (Int.repr 0) tint))
      (Sloop
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                         (Econst_int (Int.repr 8) tint) tint)
            Sskip
            Sbreak)
          (Ssequence
            (Sset _t'1
              (Ederef
                (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _i tint)
                  (tptr tuchar)) tuchar))
            (Sset _x
              (Ebinop Oor (Etempvar _x tulong)
                (Ebinop Oshl (Ecast (Etempvar _t'1 tuchar) tulong)
                  (Ebinop Omul (Econst_int (Int.repr 8) tint)
                    (Etempvar _i tint) tint) tulong) tulong))))
        (Sset _i
          (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
            tint))))
    (Sreturn (Some (Etempvar _x tulong)))))
|}.

Definition f_send_frame := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_sequence, tulong) ::
                (_result__1, (Tstruct _result noattr)) :: nil);
  fn_vars := ((_result__1, (Tstruct _result noattr)) ::
              (_bytes, (tarray tuchar 160)) :: nil);
  fn_temps := ((_t'18, tint) :: (_t'17, tint) :: (_t'16, tint) ::
               (_t'15, tint) :: (_t'14, tint) :: (_t'13, tint) ::
               (_t'12, tint) :: (_t'11, tint) :: (_t'10, tint) ::
               (_t'9, tint) :: (_t'8, tint) :: (_t'7, tint) ::
               (_t'6, tint) :: (_t'5, tint) :: (_t'4, tint) ::
               (_t'3, tint) :: (_t'2, tint) :: (_t'1, tint) ::
               (_t'41, tuint) :: (_t'40, tulong) :: (_t'39, tuint) ::
               (_t'38, tuint) :: (_t'37, tuint) :: (_t'36, tuint) ::
               (_t'35, tuint) :: (_t'34, tuint) :: (_t'33, tulong) ::
               (_t'32, tulong) :: (_t'31, tulong) :: (_t'30, tulong) ::
               (_t'29, tulong) :: (_t'28, tuint) :: (_t'27, tuint) ::
               (_t'26, tulong) :: (_t'25, tulong) :: (_t'24, tuint) ::
               (_t'23, tuint) :: (_t'22, tuint) :: (_t'21, tuint) ::
               (_t'20, tuint) :: (_t'19, tuint) :: nil);
  fn_body :=
(Ssequence
  (Sassign (Evar _result__1 (Tstruct _result noattr))
    (Etempvar _result__1 (Tstruct _result noattr)))
  (Ssequence
    (Sassign
      (Ederef
        (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
          (Econst_int (Int.repr 0) tint) (tptr tuchar)) tuchar)
      (Econst_int (Int.repr 0) tint))
    (Ssequence
      (Sassign
        (Ederef
          (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
            (Econst_int (Int.repr 1) tint) (tptr tuchar)) tuchar)
        (Econst_int (Int.repr 0) tint))
      (Ssequence
        (Sassign
          (Ederef
            (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
              (Econst_int (Int.repr 2) tint) (tptr tuchar)) tuchar)
          (Econst_int (Int.repr 0) tint))
        (Ssequence
          (Sassign
            (Ederef
              (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                (Econst_int (Int.repr 3) tint) (tptr tuchar)) tuchar)
            (Econst_int (Int.repr 0) tint))
          (Ssequence
            (Sassign
              (Ederef
                (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                  (Econst_int (Int.repr 4) tint) (tptr tuchar)) tuchar)
              (Econst_int (Int.repr 0) tint))
            (Ssequence
              (Sassign
                (Ederef
                  (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                    (Econst_int (Int.repr 5) tint) (tptr tuchar)) tuchar)
                (Econst_int (Int.repr 0) tint))
              (Ssequence
                (Sassign
                  (Ederef
                    (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                      (Econst_int (Int.repr 6) tint) (tptr tuchar)) tuchar)
                  (Econst_int (Int.repr 0) tint))
                (Ssequence
                  (Sassign
                    (Ederef
                      (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                        (Econst_int (Int.repr 7) tint) (tptr tuchar)) tuchar)
                    (Econst_int (Int.repr 0) tint))
                  (Ssequence
                    (Sassign
                      (Ederef
                        (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                          (Econst_int (Int.repr 8) tint) (tptr tuchar))
                        tuchar) (Econst_int (Int.repr 0) tint))
                    (Ssequence
                      (Sassign
                        (Ederef
                          (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                            (Econst_int (Int.repr 9) tint) (tptr tuchar))
                          tuchar) (Econst_int (Int.repr 0) tint))
                      (Ssequence
                        (Sassign
                          (Ederef
                            (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                              (Econst_int (Int.repr 10) tint) (tptr tuchar))
                            tuchar) (Econst_int (Int.repr 0) tint))
                        (Ssequence
                          (Sassign
                            (Ederef
                              (Ebinop Oadd (Evar _bytes (tarray tuchar 160))
                                (Econst_int (Int.repr 11) tint)
                                (tptr tuchar)) tuchar)
                            (Econst_int (Int.repr 0) tint))
                          (Ssequence
                            (Sassign
                              (Ederef
                                (Ebinop Oadd
                                  (Evar _bytes (tarray tuchar 160))
                                  (Econst_int (Int.repr 12) tint)
                                  (tptr tuchar)) tuchar)
                              (Econst_int (Int.repr 0) tint))
                            (Ssequence
                              (Sassign
                                (Ederef
                                  (Ebinop Oadd
                                    (Evar _bytes (tarray tuchar 160))
                                    (Econst_int (Int.repr 13) tint)
                                    (tptr tuchar)) tuchar)
                                (Econst_int (Int.repr 0) tint))
                              (Ssequence
                                (Sassign
                                  (Ederef
                                    (Ebinop Oadd
                                      (Evar _bytes (tarray tuchar 160))
                                      (Econst_int (Int.repr 14) tint)
                                      (tptr tuchar)) tuchar)
                                  (Econst_int (Int.repr 0) tint))
                                (Ssequence
                                  (Sassign
                                    (Ederef
                                      (Ebinop Oadd
                                        (Evar _bytes (tarray tuchar 160))
                                        (Econst_int (Int.repr 15) tint)
                                        (tptr tuchar)) tuchar)
                                    (Econst_int (Int.repr 0) tint))
                                  (Ssequence
                                    (Sassign
                                      (Ederef
                                        (Ebinop Oadd
                                          (Evar _bytes (tarray tuchar 160))
                                          (Econst_int (Int.repr 16) tint)
                                          (tptr tuchar)) tuchar)
                                      (Econst_int (Int.repr 0) tint))
                                    (Ssequence
                                      (Sassign
                                        (Ederef
                                          (Ebinop Oadd
                                            (Evar _bytes (tarray tuchar 160))
                                            (Econst_int (Int.repr 17) tint)
                                            (tptr tuchar)) tuchar)
                                        (Econst_int (Int.repr 0) tint))
                                      (Ssequence
                                        (Sassign
                                          (Ederef
                                            (Ebinop Oadd
                                              (Evar _bytes (tarray tuchar 160))
                                              (Econst_int (Int.repr 18) tint)
                                              (tptr tuchar)) tuchar)
                                          (Econst_int (Int.repr 0) tint))
                                        (Ssequence
                                          (Sassign
                                            (Ederef
                                              (Ebinop Oadd
                                                (Evar _bytes (tarray tuchar 160))
                                                (Econst_int (Int.repr 19) tint)
                                                (tptr tuchar)) tuchar)
                                            (Econst_int (Int.repr 0) tint))
                                          (Ssequence
                                            (Sassign
                                              (Ederef
                                                (Ebinop Oadd
                                                  (Evar _bytes (tarray tuchar 160))
                                                  (Econst_int (Int.repr 20) tint)
                                                  (tptr tuchar)) tuchar)
                                              (Econst_int (Int.repr 0) tint))
                                            (Ssequence
                                              (Sassign
                                                (Ederef
                                                  (Ebinop Oadd
                                                    (Evar _bytes (tarray tuchar 160))
                                                    (Econst_int (Int.repr 21) tint)
                                                    (tptr tuchar)) tuchar)
                                                (Econst_int (Int.repr 0) tint))
                                              (Ssequence
                                                (Sassign
                                                  (Ederef
                                                    (Ebinop Oadd
                                                      (Evar _bytes (tarray tuchar 160))
                                                      (Econst_int (Int.repr 22) tint)
                                                      (tptr tuchar)) tuchar)
                                                  (Econst_int (Int.repr 0) tint))
                                                (Ssequence
                                                  (Sassign
                                                    (Ederef
                                                      (Ebinop Oadd
                                                        (Evar _bytes (tarray tuchar 160))
                                                        (Econst_int (Int.repr 23) tint)
                                                        (tptr tuchar))
                                                      tuchar)
                                                    (Econst_int (Int.repr 0) tint))
                                                  (Ssequence
                                                    (Sassign
                                                      (Ederef
                                                        (Ebinop Oadd
                                                          (Evar _bytes (tarray tuchar 160))
                                                          (Econst_int (Int.repr 24) tint)
                                                          (tptr tuchar))
                                                        tuchar)
                                                      (Econst_int (Int.repr 0) tint))
                                                    (Ssequence
                                                      (Sassign
                                                        (Ederef
                                                          (Ebinop Oadd
                                                            (Evar _bytes (tarray tuchar 160))
                                                            (Econst_int (Int.repr 25) tint)
                                                            (tptr tuchar))
                                                          tuchar)
                                                        (Econst_int (Int.repr 0) tint))
                                                      (Ssequence
                                                        (Sassign
                                                          (Ederef
                                                            (Ebinop Oadd
                                                              (Evar _bytes (tarray tuchar 160))
                                                              (Econst_int (Int.repr 26) tint)
                                                              (tptr tuchar))
                                                            tuchar)
                                                          (Econst_int (Int.repr 0) tint))
                                                        (Ssequence
                                                          (Sassign
                                                            (Ederef
                                                              (Ebinop Oadd
                                                                (Evar _bytes (tarray tuchar 160))
                                                                (Econst_int (Int.repr 27) tint)
                                                                (tptr tuchar))
                                                              tuchar)
                                                            (Econst_int (Int.repr 0) tint))
                                                          (Ssequence
                                                            (Sassign
                                                              (Ederef
                                                                (Ebinop Oadd
                                                                  (Evar _bytes (tarray tuchar 160))
                                                                  (Econst_int (Int.repr 28) tint)
                                                                  (tptr tuchar))
                                                                tuchar)
                                                              (Econst_int (Int.repr 0) tint))
                                                            (Ssequence
                                                              (Sassign
                                                                (Ederef
                                                                  (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 29) tint)
                                                                    (tptr tuchar))
                                                                  tuchar)
                                                                (Econst_int (Int.repr 0) tint))
                                                              (Ssequence
                                                                (Sassign
                                                                  (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 30) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                  (Econst_int (Int.repr 0) tint))
                                                                (Ssequence
                                                                  (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 31) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                  (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 32) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 33) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 34) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 35) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 36) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 37) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 38) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 39) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 40) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 41) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 42) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 43) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 44) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 45) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 46) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 47) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 48) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 49) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 50) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 51) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 52) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 53) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 54) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 55) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 56) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 57) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 58) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 59) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 60) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 61) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 62) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 63) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 64) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 65) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 66) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 67) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 68) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 69) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 70) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 71) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 72) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 73) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 74) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 75) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 76) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 77) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 78) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 79) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 80) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 81) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 82) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 83) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 84) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 85) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 86) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 87) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 88) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 89) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 90) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 91) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 92) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 93) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 94) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 95) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 96) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 97) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 98) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 99) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 100) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 101) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 102) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 103) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 104) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 105) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 106) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 107) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 108) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 109) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 110) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 111) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 112) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 113) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 114) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 115) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 116) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 117) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 118) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 119) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 120) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 121) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 122) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 123) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 124) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 125) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 126) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 127) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 128) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 129) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 130) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 131) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 132) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 133) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 134) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 135) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 136) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 137) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 138) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 139) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 140) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 141) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 142) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 143) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 144) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 145) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 146) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 147) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 148) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 149) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 150) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 151) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 152) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 153) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 154) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 155) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 156) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 157) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 158) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 159) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint))
                                                                    (Ssequence
                                                                    (Scall None
                                                                    (Evar _memcpy 
                                                                    (Tfunction
                                                                    ((tptr tvoid) ::
                                                                    (tptr tvoid) ::
                                                                    tulong ::
                                                                    nil)
                                                                    (tptr tvoid)
                                                                    cc_default))
                                                                    ((Evar _bytes (tarray tuchar 160)) ::
                                                                    (Evar ___stringlit_2 (tarray tschar 5)) ::
                                                                    (Econst_int (Int.repr 4) tint) ::
                                                                    nil))
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 1) tint))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'41
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 6) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Ecast
                                                                    (Etempvar _t'41 tuint)
                                                                    tuchar)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'40
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _run
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 8) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'40 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 16) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _sequence tulong) ::
                                                                    nil))
                                                                    (Ssequence
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 24) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Ebinop Osub
                                                                    (Econst_int (Int.repr 160) tint)
                                                                    (Econst_int (Int.repr 32) tint)
                                                                    tint) ::
                                                                    nil))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'39
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _stage
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 32) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'39 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'38
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _detail
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 36) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'38 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'37
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _entry
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 40) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'37 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'36
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _clean
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 44) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'36 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'35
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _triggers
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 48) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'35 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'34
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _uid
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 52) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'34 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'33
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _cpu
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 56) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'33 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'32
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _peak
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 64) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'32 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'31
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _out
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 72) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'31 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'30
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _err
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 80) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'30 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'29
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _elapsed
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 88) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'29 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'28
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _export_state
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 96) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'28 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'27
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _omitted
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 100) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'27 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Scall None
                                                                    (Evar _memcpy 
                                                                    (Tfunction
                                                                    ((tptr tvoid) ::
                                                                    (tptr tvoid) ::
                                                                    tulong ::
                                                                    nil)
                                                                    (tptr tvoid)
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 104) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32)) ::
                                                                    (Econst_int (Int.repr 32) tint) ::
                                                                    nil))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'26
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _oom
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 136) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'26 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'25
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _pids
                                                                    tulong))
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 144) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'25 tulong) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'24
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _export_error
                                                                    tuint))
                                                                    (Scall None
                                                                    (Evar _put32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tuint ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 152) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Etempvar _t'24 tuint) ::
                                                                    nil)))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sifthenelse 
                                                                    (Ebinop One
                                                                    (Etempvar _fd tint)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)
                                                                    (Ssequence
                                                                    (Sset _t'23
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sset _t'1
                                                                    (Ecast
                                                                    (Ebinop Ole
                                                                    (Etempvar _t'23 tuint)
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    tint)
                                                                    tbool)))
                                                                    (Sset _t'1
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sifthenelse (Etempvar _t'1 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'3)
                                                                    (Evar _fault 
                                                                    (Tfunction
                                                                    ((tptr tschar) ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Evar ___stringlit_3 (tarray tschar 17)) ::
                                                                    nil))
                                                                    (Sset _t'2
                                                                    (Ecast
                                                                    (Etempvar _t'3 tint)
                                                                    tbool)))
                                                                    (Sset _t'2
                                                                    (Econst_int (Int.repr 0) tint))))
                                                                    (Sifthenelse (Etempvar _t'2 tint)
                                                                    (Scall None
                                                                    (Evar _put64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    tulong ::
                                                                    nil)
                                                                    tvoid
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 16) tint)
                                                                    (tptr tuchar)) ::
                                                                    (Ebinop Oadd
                                                                    (Etempvar _sequence tulong)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tulong) ::
                                                                    nil))
                                                                    Sskip))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sifthenelse 
                                                                    (Ebinop One
                                                                    (Etempvar _fd tint)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)
                                                                    (Ssequence
                                                                    (Sset _t'22
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sset _t'4
                                                                    (Ecast
                                                                    (Ebinop Ole
                                                                    (Etempvar _t'22 tuint)
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    tint)
                                                                    tbool)))
                                                                    (Sset _t'4
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sifthenelse (Etempvar _t'4 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'6)
                                                                    (Evar _fault 
                                                                    (Tfunction
                                                                    ((tptr tschar) ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Evar ___stringlit_4 (tarray tschar 20)) ::
                                                                    nil))
                                                                    (Sset _t'5
                                                                    (Ecast
                                                                    (Etempvar _t'6 tint)
                                                                    tbool)))
                                                                    (Sset _t'5
                                                                    (Econst_int (Int.repr 0) tint))))
                                                                    (Sifthenelse (Etempvar _t'5 tint)
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Evar _bytes (tarray tuchar 160))
                                                                    (Econst_int (Int.repr 28) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 1) tint))
                                                                    Sskip))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sifthenelse 
                                                                    (Ebinop One
                                                                    (Etempvar _fd tint)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)
                                                                    (Ssequence
                                                                    (Sset _t'21
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sset _t'8
                                                                    (Ecast
                                                                    (Ebinop Ole
                                                                    (Etempvar _t'21 tuint)
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    tint)
                                                                    tbool)))
                                                                    (Sset _t'8
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sifthenelse (Etempvar _t'8 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'10)
                                                                    (Evar _fault 
                                                                    (Tfunction
                                                                    ((tptr tschar) ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Evar ___stringlit_5 (tarray tschar 17)) ::
                                                                    nil))
                                                                    (Sset _t'9
                                                                    (Ecast
                                                                    (Etempvar _t'10 tint)
                                                                    tbool)))
                                                                    (Sset _t'9
                                                                    (Econst_int (Int.repr 0) tint))))
                                                                    (Sifthenelse (Etempvar _t'9 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'7)
                                                                    (Evar _write_all 
                                                                    (Tfunction
                                                                    (tint ::
                                                                    (tptr tvoid) ::
                                                                    tulong ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Etempvar _fd tint) ::
                                                                    (Evar _bytes (tarray tuchar 160)) ::
                                                                    (Esizeof (tarray tuchar 160) tulong) ::
                                                                    nil))
                                                                    (Sifthenelse (Etempvar _t'7 tint)
                                                                    (Sreturn (Some 
                                                                    (Eunop Oneg
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)))
                                                                    Sskip))
                                                                    Sskip))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sifthenelse 
                                                                    (Ebinop One
                                                                    (Etempvar _fd tint)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)
                                                                    (Ssequence
                                                                    (Sset _t'20
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sset _t'12
                                                                    (Ecast
                                                                    (Ebinop Ole
                                                                    (Etempvar _t'20 tuint)
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    tint)
                                                                    tbool)))
                                                                    (Sset _t'12
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sifthenelse (Etempvar _t'12 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'14)
                                                                    (Evar _fault 
                                                                    (Tfunction
                                                                    ((tptr tschar) ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Evar ___stringlit_6 (tarray tschar 13)) ::
                                                                    nil))
                                                                    (Sset _t'13
                                                                    (Ecast
                                                                    (Etempvar _t'14 tint)
                                                                    tbool)))
                                                                    (Sset _t'13
                                                                    (Econst_int (Int.repr 0) tint))))
                                                                    (Sifthenelse (Etempvar _t'13 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'11)
                                                                    (Evar _write_all 
                                                                    (Tfunction
                                                                    (tint ::
                                                                    (tptr tvoid) ::
                                                                    tulong ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Etempvar _fd tint) ::
                                                                    (Evar _bytes (tarray tuchar 160)) ::
                                                                    (Econst_int (Int.repr 17) tint) ::
                                                                    nil))
                                                                    (Sreturn (Some (Etempvar _t'11 tint))))
                                                                    Sskip))
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sifthenelse 
                                                                    (Ebinop One
                                                                    (Etempvar _fd tint)
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    tint)
                                                                    (Ssequence
                                                                    (Sset _t'19
                                                                    (Efield
                                                                    (Evar _result__1 (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint))
                                                                    (Sset _t'15
                                                                    (Ecast
                                                                    (Ebinop Ole
                                                                    (Etempvar _t'19 tuint)
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    tint)
                                                                    tbool)))
                                                                    (Sset _t'15
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sifthenelse (Etempvar _t'15 tint)
                                                                    (Ssequence
                                                                    (Scall (Some _t'17)
                                                                    (Evar _fault 
                                                                    (Tfunction
                                                                    ((tptr tschar) ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Evar ___stringlit_7 (tarray tschar 12)) ::
                                                                    nil))
                                                                    (Sset _t'16
                                                                    (Ecast
                                                                    (Etempvar _t'17 tint)
                                                                    tbool)))
                                                                    (Sset _t'16
                                                                    (Econst_int (Int.repr 0) tint))))
                                                                    (Sifthenelse (Etempvar _t'16 tint)
                                                                    (Sreturn (Some (Econst_int (Int.repr 0) tint)))
                                                                    Sskip))
                                                                    (Ssequence
                                                                    (Scall (Some _t'18)
                                                                    (Evar _write_all 
                                                                    (Tfunction
                                                                    (tint ::
                                                                    (tptr tvoid) ::
                                                                    tulong ::
                                                                    nil) tint
                                                                    cc_default))
                                                                    ((Etempvar _fd tint) ::
                                                                    (Evar _bytes (tarray tuchar 160)) ::
                                                                    (Esizeof (tarray tuchar 160) tulong) ::
                                                                    nil))
                                                                    (Sreturn (Some (Etempvar _t'18 tint)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
|}.

Definition f_decode_frame := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_p, (tptr tuchar)) :: (_sequence, tulong) ::
                (_r, (tptr (Tstruct _result noattr))) :: nil);
  fn_vars := ((___compound, (Tstruct _result noattr)) :: nil);
  fn_temps := ((_i, tint) :: (_i__1, tint) :: (_t'53, tint) ::
               (_t'52, tint) :: (_t'51, tint) :: (_t'50, tint) ::
               (_t'49, tint) :: (_t'48, tint) :: (_t'47, tint) ::
               (_t'46, tint) :: (_t'45, tint) :: (_t'44, tint) ::
               (_t'43, tint) :: (_t'42, tint) :: (_t'41, tint) ::
               (_t'40, tint) :: (_t'39, tint) :: (_t'38, tint) ::
               (_t'37, tint) :: (_t'36, tint) :: (_t'35, tint) ::
               (_t'34, tint) :: (_t'33, tint) :: (_t'32, tint) ::
               (_t'31, tint) :: (_t'30, tint) :: (_t'29, tint) ::
               (_t'28, tint) :: (_t'27, tint) :: (_t'26, tint) ::
               (_t'25, tint) :: (_t'24, tulong) :: (_t'23, tulong) ::
               (_t'22, tulong) :: (_t'21, tulong) :: (_t'20, tulong) ::
               (_t'19, tulong) :: (_t'18, tuint) :: (_t'17, tuint) ::
               (_t'16, tuint) :: (_t'15, tuint) :: (_t'14, tuint) ::
               (_t'13, tuint) :: (_t'12, tuint) :: (_t'11, tint) ::
               (_t'10, tuint) :: (_t'9, tint) :: (_t'8, tulong) ::
               (_t'7, tint) :: (_t'6, tulong) :: (_t'5, tint) ::
               (_t'4, tint) :: (_t'3, tint) :: (_t'2, tint) ::
               (_t'1, tint) :: (_t'99, tuchar) :: (_t'98, tuchar) ::
               (_t'97, tuchar) :: (_t'96, tulong) :: (_t'95, tuchar) ::
               (_t'94, tuchar) :: (_t'93, tuint) :: (_t'92, tuint) ::
               (_t'91, tuint) :: (_t'90, tuint) :: (_t'89, tuint) ::
               (_t'88, tuint) :: (_t'87, tulong) :: (_t'86, tulong) ::
               (_t'85, tulong) :: (_t'84, tulong) :: (_t'83, tuchar) ::
               (_t'82, tuint) :: (_t'81, tuint) :: (_t'80, tuint) ::
               (_t'79, tuint) :: (_t'78, tuint) :: (_t'77, tuint) ::
               (_t'76, tuint) :: (_t'75, tuint) :: (_t'74, tuint) ::
               (_t'73, tuint) :: (_t'72, tuint) :: (_t'71, tuint) ::
               (_t'70, tuint) :: (_t'69, tuint) :: (_t'68, tuint) ::
               (_t'67, tuint) :: (_t'66, tuint) :: (_t'65, tuint) ::
               (_t'64, tuint) :: (_t'63, tulong) :: (_t'62, tuint) ::
               (_t'61, tuint) :: (_t'60, tuint) :: (_t'59, tuint) ::
               (_t'58, tuint) :: (_t'57, tint) :: (_t'56, tuint) ::
               (_t'55, tuint) :: (_t'54, tuint) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Ssequence
      (Ssequence
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Scall (Some _t'1)
                    (Evar _memcmp (Tfunction
                                    ((tptr tvoid) :: (tptr tvoid) ::
                                     tulong :: nil) tint cc_default))
                    ((Etempvar _p (tptr tuchar)) ::
                     (Evar ___stringlit_2 (tarray tschar 5)) ::
                     (Econst_int (Int.repr 4) tint) :: nil))
                  (Sifthenelse (Etempvar _t'1 tint)
                    (Sset _t'2 (Econst_int (Int.repr 1) tint))
                    (Ssequence
                      (Sset _t'99
                        (Ederef
                          (Ebinop Oadd (Etempvar _p (tptr tuchar))
                            (Econst_int (Int.repr 4) tint) (tptr tuchar))
                          tuchar))
                      (Sset _t'2
                        (Ecast
                          (Ebinop One (Etempvar _t'99 tuchar)
                            (Econst_int (Int.repr 1) tint) tint) tbool)))))
                (Sifthenelse (Etempvar _t'2 tint)
                  (Sset _t'3 (Econst_int (Int.repr 1) tint))
                  (Ssequence
                    (Sset _t'98
                      (Ederef
                        (Ebinop Oadd (Etempvar _p (tptr tuchar))
                          (Econst_int (Int.repr 5) tint) (tptr tuchar))
                        tuchar))
                    (Sset _t'3 (Ecast (Etempvar _t'98 tuchar) tbool)))))
              (Sifthenelse (Etempvar _t'3 tint)
                (Sset _t'4 (Econst_int (Int.repr 1) tint))
                (Ssequence
                  (Sset _t'97
                    (Ederef
                      (Ebinop Oadd (Etempvar _p (tptr tuchar))
                        (Econst_int (Int.repr 7) tint) (tptr tuchar)) tuchar))
                  (Sset _t'4 (Ecast (Etempvar _t'97 tuchar) tbool)))))
            (Sifthenelse (Etempvar _t'4 tint)
              (Sset _t'5 (Econst_int (Int.repr 1) tint))
              (Ssequence
                (Scall (Some _t'6)
                  (Evar _get64 (Tfunction ((tptr tuchar) :: nil) tulong
                                 cc_default))
                  ((Ebinop Oadd (Etempvar _p (tptr tuchar))
                     (Econst_int (Int.repr 8) tint) (tptr tuchar)) :: nil))
                (Ssequence
                  (Sset _t'96 (Evar _run_id tulong))
                  (Sset _t'5
                    (Ecast
                      (Ebinop One (Etempvar _t'6 tulong)
                        (Etempvar _t'96 tulong) tint) tbool))))))
          (Sifthenelse (Etempvar _t'5 tint)
            (Sset _t'7 (Econst_int (Int.repr 1) tint))
            (Ssequence
              (Scall (Some _t'8)
                (Evar _get64 (Tfunction ((tptr tuchar) :: nil) tulong
                               cc_default))
                ((Ebinop Oadd (Etempvar _p (tptr tuchar))
                   (Econst_int (Int.repr 16) tint) (tptr tuchar)) :: nil))
              (Sset _t'7
                (Ecast
                  (Ebinop One (Etempvar _t'8 tulong)
                    (Etempvar _sequence tulong) tint) tbool)))))
        (Sifthenelse (Etempvar _t'7 tint)
          (Sset _t'9 (Econst_int (Int.repr 1) tint))
          (Ssequence
            (Scall (Some _t'10)
              (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                             cc_default))
              ((Ebinop Oadd (Etempvar _p (tptr tuchar))
                 (Econst_int (Int.repr 24) tint) (tptr tuchar)) :: nil))
            (Sset _t'9
              (Ecast
                (Ebinop One (Etempvar _t'10 tuint)
                  (Ebinop Osub (Econst_int (Int.repr 160) tint)
                    (Econst_int (Int.repr 32) tint) tint) tint) tbool)))))
      (Sifthenelse (Etempvar _t'9 tint)
        (Sset _t'11 (Econst_int (Int.repr 1) tint))
        (Ssequence
          (Scall (Some _t'12)
            (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint cc_default))
            ((Ebinop Oadd (Etempvar _p (tptr tuchar))
               (Econst_int (Int.repr 28) tint) (tptr tuchar)) :: nil))
          (Sset _t'11 (Ecast (Etempvar _t'12 tuint) tbool)))))
    (Sifthenelse (Etempvar _t'11 tint)
      (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
      Sskip))
  (Ssequence
    (Ssequence
      (Sset _i (Econst_int (Int.repr 156) tint))
      (Sloop
        (Ssequence
          (Sifthenelse (Ebinop Olt (Etempvar _i tint)
                         (Econst_int (Int.repr 160) tint) tint)
            Sskip
            Sbreak)
          (Ssequence
            (Sset _t'95
              (Ederef
                (Ebinop Oadd (Etempvar _p (tptr tuchar)) (Etempvar _i tint)
                  (tptr tuchar)) tuchar))
            (Sifthenelse (Etempvar _t'95 tuchar)
              (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
              Sskip)))
        (Sset _i
          (Ebinop Oadd (Etempvar _i tint) (Econst_int (Int.repr 1) tint)
            tint))))
    (Ssequence
      (Ssequence
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Ssequence
                                      (Ssequence
                                        (Ssequence
                                          (Ssequence
                                            (Ssequence
                                              (Ssequence
                                                (Ssequence
                                                  (Ssequence
                                                    (Ssequence
                                                      (Ssequence
                                                        (Ssequence
                                                          (Ssequence
                                                            (Ssequence
                                                              (Ssequence
                                                                (Ssequence
                                                                  (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sset _t'94
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 6) tint)
                                                                    (tptr tuchar))
                                                                    tuchar))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint)
                                                                    (Etempvar _t'94 tuchar)))
                                                                    (Scall (Some _t'13)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 32) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _stage
                                                                    tuint)
                                                                    (Etempvar _t'13 tuint)))
                                                                    (Scall (Some _t'14)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 36) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _detail
                                                                    tuint)
                                                                    (Etempvar _t'14 tuint)))
                                                                    (Scall (Some _t'15)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 40) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _entry
                                                                    tuint)
                                                                    (Etempvar _t'15 tuint)))
                                                                    (Scall (Some _t'16)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 44) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _clean
                                                                    tuint)
                                                                    (Etempvar _t'16 tuint)))
                                                                    (Scall (Some _t'17)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 48) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _triggers
                                                                    tuint)
                                                                    (Etempvar _t'17 tuint)))
                                                                    (Scall (Some _t'18)
                                                                    (Evar _get32 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tuint
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 52) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _uid
                                                                    tuint)
                                                                    (Etempvar _t'18 tuint)))
                                                                    (Scall (Some _t'19)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 8) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _run
                                                                    tulong)
                                                                    (Etempvar _t'19 tulong)))
                                                                    (Scall (Some _t'20)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 56) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _cpu
                                                                    tulong)
                                                                    (Etempvar _t'20 tulong)))
                                                                    (Scall (Some _t'21)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 64) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _peak
                                                                    tulong)
                                                                    (Etempvar _t'21 tulong)))
                                                                    (Scall (Some _t'22)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 72) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _out
                                                                    tulong)
                                                                    (Etempvar _t'22 tulong)))
                                                                    (Scall (Some _t'23)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 80) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _err
                                                                    tulong)
                                                                    (Etempvar _t'23 tulong)))
                                                                    (Scall (Some _t'24)
                                                                    (Evar _get64 
                                                                    (Tfunction
                                                                    ((tptr tuchar) ::
                                                                    nil)
                                                                    tulong
                                                                    cc_default))
                                                                    ((Ebinop Oadd
                                                                    (Etempvar _p (tptr tuchar))
                                                                    (Econst_int (Int.repr 88) tint)
                                                                    (tptr tuchar)) ::
                                                                    nil)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _elapsed
                                                                    tulong)
                                                                    (Etempvar _t'24 tulong)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _oom
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _pids
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_state
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _omitted
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_error
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 0) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 2) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                  (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 3) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                (Sassign
                                                                  (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 4) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                  (Econst_int (Int.repr 0) tint)))
                                                              (Sassign
                                                                (Ederef
                                                                  (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 5) tint)
                                                                    (tptr tuchar))
                                                                  tuchar)
                                                                (Econst_int (Int.repr 0) tint)))
                                                            (Sassign
                                                              (Ederef
                                                                (Ebinop Oadd
                                                                  (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                  (Econst_int (Int.repr 6) tint)
                                                                  (tptr tuchar))
                                                                tuchar)
                                                              (Econst_int (Int.repr 0) tint)))
                                                          (Sassign
                                                            (Ederef
                                                              (Ebinop Oadd
                                                                (Efield
                                                                  (Evar ___compound (Tstruct _result noattr))
                                                                  _export_digest
                                                                  (tarray tuchar 32))
                                                                (Econst_int (Int.repr 7) tint)
                                                                (tptr tuchar))
                                                              tuchar)
                                                            (Econst_int (Int.repr 0) tint)))
                                                        (Sassign
                                                          (Ederef
                                                            (Ebinop Oadd
                                                              (Efield
                                                                (Evar ___compound (Tstruct _result noattr))
                                                                _export_digest
                                                                (tarray tuchar 32))
                                                              (Econst_int (Int.repr 8) tint)
                                                              (tptr tuchar))
                                                            tuchar)
                                                          (Econst_int (Int.repr 0) tint)))
                                                      (Sassign
                                                        (Ederef
                                                          (Ebinop Oadd
                                                            (Efield
                                                              (Evar ___compound (Tstruct _result noattr))
                                                              _export_digest
                                                              (tarray tuchar 32))
                                                            (Econst_int (Int.repr 9) tint)
                                                            (tptr tuchar))
                                                          tuchar)
                                                        (Econst_int (Int.repr 0) tint)))
                                                    (Sassign
                                                      (Ederef
                                                        (Ebinop Oadd
                                                          (Efield
                                                            (Evar ___compound (Tstruct _result noattr))
                                                            _export_digest
                                                            (tarray tuchar 32))
                                                          (Econst_int (Int.repr 10) tint)
                                                          (tptr tuchar))
                                                        tuchar)
                                                      (Econst_int (Int.repr 0) tint)))
                                                  (Sassign
                                                    (Ederef
                                                      (Ebinop Oadd
                                                        (Efield
                                                          (Evar ___compound (Tstruct _result noattr))
                                                          _export_digest
                                                          (tarray tuchar 32))
                                                        (Econst_int (Int.repr 11) tint)
                                                        (tptr tuchar))
                                                      tuchar)
                                                    (Econst_int (Int.repr 0) tint)))
                                                (Sassign
                                                  (Ederef
                                                    (Ebinop Oadd
                                                      (Efield
                                                        (Evar ___compound (Tstruct _result noattr))
                                                        _export_digest
                                                        (tarray tuchar 32))
                                                      (Econst_int (Int.repr 12) tint)
                                                      (tptr tuchar)) tuchar)
                                                  (Econst_int (Int.repr 0) tint)))
                                              (Sassign
                                                (Ederef
                                                  (Ebinop Oadd
                                                    (Efield
                                                      (Evar ___compound (Tstruct _result noattr))
                                                      _export_digest
                                                      (tarray tuchar 32))
                                                    (Econst_int (Int.repr 13) tint)
                                                    (tptr tuchar)) tuchar)
                                                (Econst_int (Int.repr 0) tint)))
                                            (Sassign
                                              (Ederef
                                                (Ebinop Oadd
                                                  (Efield
                                                    (Evar ___compound (Tstruct _result noattr))
                                                    _export_digest
                                                    (tarray tuchar 32))
                                                  (Econst_int (Int.repr 14) tint)
                                                  (tptr tuchar)) tuchar)
                                              (Econst_int (Int.repr 0) tint)))
                                          (Sassign
                                            (Ederef
                                              (Ebinop Oadd
                                                (Efield
                                                  (Evar ___compound (Tstruct _result noattr))
                                                  _export_digest
                                                  (tarray tuchar 32))
                                                (Econst_int (Int.repr 15) tint)
                                                (tptr tuchar)) tuchar)
                                            (Econst_int (Int.repr 0) tint)))
                                        (Sassign
                                          (Ederef
                                            (Ebinop Oadd
                                              (Efield
                                                (Evar ___compound (Tstruct _result noattr))
                                                _export_digest
                                                (tarray tuchar 32))
                                              (Econst_int (Int.repr 16) tint)
                                              (tptr tuchar)) tuchar)
                                          (Econst_int (Int.repr 0) tint)))
                                      (Sassign
                                        (Ederef
                                          (Ebinop Oadd
                                            (Efield
                                              (Evar ___compound (Tstruct _result noattr))
                                              _export_digest
                                              (tarray tuchar 32))
                                            (Econst_int (Int.repr 17) tint)
                                            (tptr tuchar)) tuchar)
                                        (Econst_int (Int.repr 0) tint)))
                                    (Sassign
                                      (Ederef
                                        (Ebinop Oadd
                                          (Efield
                                            (Evar ___compound (Tstruct _result noattr))
                                            _export_digest
                                            (tarray tuchar 32))
                                          (Econst_int (Int.repr 18) tint)
                                          (tptr tuchar)) tuchar)
                                      (Econst_int (Int.repr 0) tint)))
                                  (Sassign
                                    (Ederef
                                      (Ebinop Oadd
                                        (Efield
                                          (Evar ___compound (Tstruct _result noattr))
                                          _export_digest (tarray tuchar 32))
                                        (Econst_int (Int.repr 19) tint)
                                        (tptr tuchar)) tuchar)
                                    (Econst_int (Int.repr 0) tint)))
                                (Sassign
                                  (Ederef
                                    (Ebinop Oadd
                                      (Efield
                                        (Evar ___compound (Tstruct _result noattr))
                                        _export_digest (tarray tuchar 32))
                                      (Econst_int (Int.repr 20) tint)
                                      (tptr tuchar)) tuchar)
                                  (Econst_int (Int.repr 0) tint)))
                              (Sassign
                                (Ederef
                                  (Ebinop Oadd
                                    (Efield
                                      (Evar ___compound (Tstruct _result noattr))
                                      _export_digest (tarray tuchar 32))
                                    (Econst_int (Int.repr 21) tint)
                                    (tptr tuchar)) tuchar)
                                (Econst_int (Int.repr 0) tint)))
                            (Sassign
                              (Ederef
                                (Ebinop Oadd
                                  (Efield
                                    (Evar ___compound (Tstruct _result noattr))
                                    _export_digest (tarray tuchar 32))
                                  (Econst_int (Int.repr 22) tint)
                                  (tptr tuchar)) tuchar)
                              (Econst_int (Int.repr 0) tint)))
                          (Sassign
                            (Ederef
                              (Ebinop Oadd
                                (Efield
                                  (Evar ___compound (Tstruct _result noattr))
                                  _export_digest (tarray tuchar 32))
                                (Econst_int (Int.repr 23) tint)
                                (tptr tuchar)) tuchar)
                            (Econst_int (Int.repr 0) tint)))
                        (Sassign
                          (Ederef
                            (Ebinop Oadd
                              (Efield
                                (Evar ___compound (Tstruct _result noattr))
                                _export_digest (tarray tuchar 32))
                              (Econst_int (Int.repr 24) tint) (tptr tuchar))
                            tuchar) (Econst_int (Int.repr 0) tint)))
                      (Sassign
                        (Ederef
                          (Ebinop Oadd
                            (Efield
                              (Evar ___compound (Tstruct _result noattr))
                              _export_digest (tarray tuchar 32))
                            (Econst_int (Int.repr 25) tint) (tptr tuchar))
                          tuchar) (Econst_int (Int.repr 0) tint)))
                    (Sassign
                      (Ederef
                        (Ebinop Oadd
                          (Efield (Evar ___compound (Tstruct _result noattr))
                            _export_digest (tarray tuchar 32))
                          (Econst_int (Int.repr 26) tint) (tptr tuchar))
                        tuchar) (Econst_int (Int.repr 0) tint)))
                  (Sassign
                    (Ederef
                      (Ebinop Oadd
                        (Efield (Evar ___compound (Tstruct _result noattr))
                          _export_digest (tarray tuchar 32))
                        (Econst_int (Int.repr 27) tint) (tptr tuchar))
                      tuchar) (Econst_int (Int.repr 0) tint)))
                (Sassign
                  (Ederef
                    (Ebinop Oadd
                      (Efield (Evar ___compound (Tstruct _result noattr))
                        _export_digest (tarray tuchar 32))
                      (Econst_int (Int.repr 28) tint) (tptr tuchar)) tuchar)
                  (Econst_int (Int.repr 0) tint)))
              (Sassign
                (Ederef
                  (Ebinop Oadd
                    (Efield (Evar ___compound (Tstruct _result noattr))
                      _export_digest (tarray tuchar 32))
                    (Econst_int (Int.repr 29) tint) (tptr tuchar)) tuchar)
                (Econst_int (Int.repr 0) tint)))
            (Sassign
              (Ederef
                (Ebinop Oadd
                  (Efield (Evar ___compound (Tstruct _result noattr))
                    _export_digest (tarray tuchar 32))
                  (Econst_int (Int.repr 30) tint) (tptr tuchar)) tuchar)
              (Econst_int (Int.repr 0) tint)))
          (Sassign
            (Ederef
              (Ebinop Oadd
                (Efield (Evar ___compound (Tstruct _result noattr))
                  _export_digest (tarray tuchar 32))
                (Econst_int (Int.repr 31) tint) (tptr tuchar)) tuchar)
            (Econst_int (Int.repr 0) tint)))
        (Sassign
          (Ederef (Etempvar _r (tptr (Tstruct _result noattr)))
            (Tstruct _result noattr))
          (Evar ___compound (Tstruct _result noattr))))
      (Ssequence
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Sset _t'92
                            (Efield
                              (Ederef
                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                (Tstruct _result noattr)) _kind tuint))
                          (Sifthenelse (Ebinop Ogt (Etempvar _t'92 tuint)
                                         (Econst_int (Int.repr 7) tint) tint)
                            (Sset _t'25 (Econst_int (Int.repr 1) tint))
                            (Ssequence
                              (Sset _t'93
                                (Efield
                                  (Ederef
                                    (Etempvar _r (tptr (Tstruct _result noattr)))
                                    (Tstruct _result noattr)) _entry tuint))
                              (Sset _t'25
                                (Ecast
                                  (Ebinop Ogt (Etempvar _t'93 tuint)
                                    (Econst_int (Int.repr 2) tint) tint)
                                  tbool)))))
                        (Sifthenelse (Etempvar _t'25 tint)
                          (Sset _t'26 (Econst_int (Int.repr 1) tint))
                          (Ssequence
                            (Sset _t'91
                              (Efield
                                (Ederef
                                  (Etempvar _r (tptr (Tstruct _result noattr)))
                                  (Tstruct _result noattr)) _clean tuint))
                            (Sset _t'26
                              (Ecast
                                (Ebinop Ogt (Etempvar _t'91 tuint)
                                  (Econst_int (Int.repr 1) tint) tint) tbool)))))
                      (Sifthenelse (Etempvar _t'26 tint)
                        (Sset _t'27 (Econst_int (Int.repr 1) tint))
                        (Ssequence
                          (Sset _t'89
                            (Efield
                              (Ederef
                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                (Tstruct _result noattr)) _uid tuint))
                          (Ssequence
                            (Sset _t'90 (Evar _run_uid tuint))
                            (Sset _t'27
                              (Ecast
                                (Ebinop One (Etempvar _t'89 tuint)
                                  (Etempvar _t'90 tuint) tint) tbool))))))
                    (Sifthenelse (Etempvar _t'27 tint)
                      (Sset _t'28 (Econst_int (Int.repr 1) tint))
                      (Ssequence
                        (Sset _t'88
                          (Efield
                            (Ederef
                              (Etempvar _r (tptr (Tstruct _result noattr)))
                              (Tstruct _result noattr)) _triggers tuint))
                        (Sset _t'28 (Ecast (Etempvar _t'88 tuint) tbool)))))
                  (Sifthenelse (Etempvar _t'28 tint)
                    (Sset _t'29 (Econst_int (Int.repr 1) tint))
                    (Ssequence
                      (Sset _t'87
                        (Efield
                          (Ederef
                            (Etempvar _r (tptr (Tstruct _result noattr)))
                            (Tstruct _result noattr)) _cpu tulong))
                      (Sset _t'29 (Ecast (Etempvar _t'87 tulong) tbool)))))
                (Sifthenelse (Etempvar _t'29 tint)
                  (Sset _t'30 (Econst_int (Int.repr 1) tint))
                  (Ssequence
                    (Sset _t'86
                      (Efield
                        (Ederef (Etempvar _r (tptr (Tstruct _result noattr)))
                          (Tstruct _result noattr)) _peak tulong))
                    (Sset _t'30 (Ecast (Etempvar _t'86 tulong) tbool)))))
              (Sifthenelse (Etempvar _t'30 tint)
                (Sset _t'31 (Econst_int (Int.repr 1) tint))
                (Ssequence
                  (Sset _t'85
                    (Efield
                      (Ederef (Etempvar _r (tptr (Tstruct _result noattr)))
                        (Tstruct _result noattr)) _out tulong))
                  (Sset _t'31 (Ecast (Etempvar _t'85 tulong) tbool)))))
            (Sifthenelse (Etempvar _t'31 tint)
              (Sset _t'32 (Econst_int (Int.repr 1) tint))
              (Ssequence
                (Sset _t'84
                  (Efield
                    (Ederef (Etempvar _r (tptr (Tstruct _result noattr)))
                      (Tstruct _result noattr)) _err tulong))
                (Sset _t'32 (Ecast (Etempvar _t'84 tulong) tbool)))))
          (Sifthenelse (Etempvar _t'32 tint)
            (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint) tint)))
            Sskip))
        (Ssequence
          (Ssequence
            (Sset _i__1 (Econst_int (Int.repr 96) tint))
            (Sloop
              (Ssequence
                (Sifthenelse (Ebinop Olt (Etempvar _i__1 tint)
                               (Econst_int (Int.repr 156) tint) tint)
                  Sskip
                  Sbreak)
                (Ssequence
                  (Sset _t'83
                    (Ederef
                      (Ebinop Oadd (Etempvar _p (tptr tuchar))
                        (Etempvar _i__1 tint) (tptr tuchar)) tuchar))
                  (Sifthenelse (Etempvar _t'83 tuchar)
                    (Sreturn (Some (Eunop Oneg (Econst_int (Int.repr 1) tint)
                                     tint)))
                    Sskip)))
              (Sset _i__1
                (Ebinop Oadd (Etempvar _i__1 tint)
                  (Econst_int (Int.repr 1) tint) tint))))
          (Ssequence
            (Ssequence
              (Sset _t'54
                (Efield
                  (Ederef (Etempvar _r (tptr (Tstruct _result noattr)))
                    (Tstruct _result noattr)) _kind tuint))
              (Sswitch (Etempvar _t'54 tuint)
                (LScons (Some 0)
                  (Ssequence
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Sset _t'81
                            (Efield
                              (Ederef
                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                (Tstruct _result noattr)) _stage tuint))
                          (Sifthenelse (Etempvar _t'81 tuint)
                            (Sset _t'33 (Econst_int (Int.repr 1) tint))
                            (Ssequence
                              (Sset _t'82
                                (Efield
                                  (Ederef
                                    (Etempvar _r (tptr (Tstruct _result noattr)))
                                    (Tstruct _result noattr)) _detail tuint))
                              (Sset _t'33
                                (Ecast
                                  (Ebinop Ogt (Etempvar _t'82 tuint)
                                    (Econst_int (Int.repr 255) tint) tint)
                                  tbool)))))
                        (Sifthenelse (Etempvar _t'33 tint)
                          (Sset _t'34 (Econst_int (Int.repr 1) tint))
                          (Ssequence
                            (Sset _t'80
                              (Efield
                                (Ederef
                                  (Etempvar _r (tptr (Tstruct _result noattr)))
                                  (Tstruct _result noattr)) _entry tuint))
                            (Sset _t'34
                              (Ecast
                                (Ebinop One (Etempvar _t'80 tuint)
                                  (Econst_int (Int.repr 1) tint) tint) tbool)))))
                      (Sifthenelse (Etempvar _t'34 tint)
                        (Sreturn (Some (Eunop Oneg
                                         (Econst_int (Int.repr 1) tint) tint)))
                        Sskip))
                    Sbreak)
                  (LScons (Some 1)
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Sset _t'78
                                  (Efield
                                    (Ederef
                                      (Etempvar _r (tptr (Tstruct _result noattr)))
                                      (Tstruct _result noattr)) _stage tuint))
                                (Sifthenelse (Ebinop Olt
                                               (Etempvar _t'78 tuint)
                                               (Econst_int (Int.repr 1) tint)
                                               tint)
                                  (Sset _t'35 (Econst_int (Int.repr 1) tint))
                                  (Ssequence
                                    (Sset _t'79
                                      (Efield
                                        (Ederef
                                          (Etempvar _r (tptr (Tstruct _result noattr)))
                                          (Tstruct _result noattr)) _stage
                                        tuint))
                                    (Sset _t'35
                                      (Ecast
                                        (Ebinop Ogt (Etempvar _t'79 tuint)
                                          (Econst_int (Int.repr 8) tint)
                                          tint) tbool)))))
                              (Sifthenelse (Etempvar _t'35 tint)
                                (Sset _t'36 (Econst_int (Int.repr 1) tint))
                                (Ssequence
                                  (Sset _t'77
                                    (Efield
                                      (Ederef
                                        (Etempvar _r (tptr (Tstruct _result noattr)))
                                        (Tstruct _result noattr)) _detail
                                      tuint))
                                  (Sset _t'36
                                    (Ecast
                                      (Eunop Onotbool (Etempvar _t'77 tuint)
                                        tint) tbool)))))
                            (Sifthenelse (Etempvar _t'36 tint)
                              (Sset _t'37 (Econst_int (Int.repr 1) tint))
                              (Ssequence
                                (Sset _t'76
                                  (Efield
                                    (Ederef
                                      (Etempvar _r (tptr (Tstruct _result noattr)))
                                      (Tstruct _result noattr)) _detail
                                    tuint))
                                (Sset _t'37
                                  (Ecast
                                    (Ebinop Ogt (Etempvar _t'76 tuint)
                                      (Econst_int (Int.repr 4095) tint) tint)
                                    tbool)))))
                          (Sifthenelse (Etempvar _t'37 tint)
                            (Sset _t'38 (Econst_int (Int.repr 1) tint))
                            (Ssequence
                              (Sset _t'75
                                (Efield
                                  (Ederef
                                    (Etempvar _r (tptr (Tstruct _result noattr)))
                                    (Tstruct _result noattr)) _entry tuint))
                              (Sset _t'38
                                (Ecast (Etempvar _t'75 tuint) tbool)))))
                        (Sifthenelse (Etempvar _t'38 tint)
                          (Sreturn (Some (Eunop Oneg
                                           (Econst_int (Int.repr 1) tint)
                                           tint)))
                          Sskip))
                      Sbreak)
                    (LScons (Some 2)
                      (Ssequence
                        (Ssequence
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Sset _t'73
                                  (Efield
                                    (Ederef
                                      (Etempvar _r (tptr (Tstruct _result noattr)))
                                      (Tstruct _result noattr)) _stage tuint))
                                (Sifthenelse (Etempvar _t'73 tuint)
                                  (Sset _t'39 (Econst_int (Int.repr 1) tint))
                                  (Ssequence
                                    (Sset _t'74
                                      (Efield
                                        (Ederef
                                          (Etempvar _r (tptr (Tstruct _result noattr)))
                                          (Tstruct _result noattr)) _detail
                                        tuint))
                                    (Sset _t'39
                                      (Ecast
                                        (Eunop Onotbool
                                          (Etempvar _t'74 tuint) tint) tbool)))))
                              (Sifthenelse (Etempvar _t'39 tint)
                                (Sset _t'40 (Econst_int (Int.repr 1) tint))
                                (Ssequence
                                  (Sset _t'72
                                    (Efield
                                      (Ederef
                                        (Etempvar _r (tptr (Tstruct _result noattr)))
                                        (Tstruct _result noattr)) _detail
                                      tuint))
                                  (Sset _t'40
                                    (Ecast
                                      (Ebinop Ogt (Etempvar _t'72 tuint)
                                        (Econst_int (Int.repr 64) tint) tint)
                                      tbool)))))
                            (Sifthenelse (Etempvar _t'40 tint)
                              (Sset _t'41 (Econst_int (Int.repr 1) tint))
                              (Ssequence
                                (Sset _t'71
                                  (Efield
                                    (Ederef
                                      (Etempvar _r (tptr (Tstruct _result noattr)))
                                      (Tstruct _result noattr)) _entry tuint))
                                (Sset _t'41
                                  (Ecast
                                    (Ebinop One (Etempvar _t'71 tuint)
                                      (Econst_int (Int.repr 1) tint) tint)
                                    tbool)))))
                          (Sifthenelse (Etempvar _t'41 tint)
                            (Sreturn (Some (Eunop Oneg
                                             (Econst_int (Int.repr 1) tint)
                                             tint)))
                            Sskip))
                        Sbreak)
                      (LScons (Some 4)
                        (Ssequence
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Sset _t'69
                                  (Efield
                                    (Ederef
                                      (Etempvar _r (tptr (Tstruct _result noattr)))
                                      (Tstruct _result noattr)) _stage tuint))
                                (Sifthenelse (Ebinop One
                                               (Etempvar _t'69 tuint)
                                               (Econst_int (Int.repr 9) tint)
                                               tint)
                                  (Sset _t'42 (Econst_int (Int.repr 1) tint))
                                  (Ssequence
                                    (Sset _t'70
                                      (Efield
                                        (Ederef
                                          (Etempvar _r (tptr (Tstruct _result noattr)))
                                          (Tstruct _result noattr)) _detail
                                        tuint))
                                    (Sset _t'42
                                      (Ecast
                                        (Eunop Onotbool
                                          (Etempvar _t'70 tuint) tint) tbool)))))
                              (Sifthenelse (Etempvar _t'42 tint)
                                (Sset _t'43 (Econst_int (Int.repr 1) tint))
                                (Ssequence
                                  (Sset _t'68
                                    (Efield
                                      (Ederef
                                        (Etempvar _r (tptr (Tstruct _result noattr)))
                                        (Tstruct _result noattr)) _detail
                                      tuint))
                                  (Sset _t'43
                                    (Ecast
                                      (Ebinop Ogt (Etempvar _t'68 tuint)
                                        (Econst_int (Int.repr 4095) tint)
                                        tint) tbool)))))
                            (Sifthenelse (Etempvar _t'43 tint)
                              (Sreturn (Some (Eunop Oneg
                                               (Econst_int (Int.repr 1) tint)
                                               tint)))
                              Sskip))
                          Sbreak)
                        (LScons (Some 5)
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Ssequence
                                      (Sset _t'66
                                        (Efield
                                          (Ederef
                                            (Etempvar _r (tptr (Tstruct _result noattr)))
                                            (Tstruct _result noattr)) _stage
                                          tuint))
                                      (Sifthenelse (Etempvar _t'66 tuint)
                                        (Sset _t'44
                                          (Econst_int (Int.repr 1) tint))
                                        (Ssequence
                                          (Sset _t'67
                                            (Efield
                                              (Ederef
                                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                                (Tstruct _result noattr))
                                              _detail tuint))
                                          (Sset _t'44
                                            (Ecast (Etempvar _t'67 tuint)
                                              tbool)))))
                                    (Sifthenelse (Etempvar _t'44 tint)
                                      (Sset _t'45
                                        (Econst_int (Int.repr 1) tint))
                                      (Ssequence
                                        (Sset _t'65
                                          (Efield
                                            (Ederef
                                              (Etempvar _r (tptr (Tstruct _result noattr)))
                                              (Tstruct _result noattr))
                                            _entry tuint))
                                        (Sset _t'45
                                          (Ecast (Etempvar _t'65 tuint)
                                            tbool)))))
                                  (Sifthenelse (Etempvar _t'45 tint)
                                    (Sset _t'46
                                      (Econst_int (Int.repr 1) tint))
                                    (Ssequence
                                      (Sset _t'64
                                        (Efield
                                          (Ederef
                                            (Etempvar _r (tptr (Tstruct _result noattr)))
                                            (Tstruct _result noattr)) _clean
                                          tuint))
                                      (Sset _t'46
                                        (Ecast (Etempvar _t'64 tuint) tbool)))))
                                (Sifthenelse (Etempvar _t'46 tint)
                                  (Sset _t'47 (Econst_int (Int.repr 1) tint))
                                  (Ssequence
                                    (Sset _t'63
                                      (Efield
                                        (Ederef
                                          (Etempvar _r (tptr (Tstruct _result noattr)))
                                          (Tstruct _result noattr)) _elapsed
                                        tulong))
                                    (Sset _t'47
                                      (Ecast
                                        (Eunop Onotbool
                                          (Etempvar _t'63 tulong) tint)
                                        tbool)))))
                              (Sifthenelse (Etempvar _t'47 tint)
                                (Sreturn (Some (Eunop Oneg
                                                 (Econst_int (Int.repr 1) tint)
                                                 tint)))
                                Sskip))
                            Sbreak)
                          (LScons (Some 6)
                            (Ssequence
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Ssequence
                                      (Sset _t'61
                                        (Efield
                                          (Ederef
                                            (Etempvar _r (tptr (Tstruct _result noattr)))
                                            (Tstruct _result noattr)) _stage
                                          tuint))
                                      (Sifthenelse (Ebinop One
                                                     (Etempvar _t'61 tuint)
                                                     (Econst_int (Int.repr 8) tint)
                                                     tint)
                                        (Sset _t'48
                                          (Econst_int (Int.repr 1) tint))
                                        (Ssequence
                                          (Sset _t'62
                                            (Efield
                                              (Ederef
                                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                                (Tstruct _result noattr))
                                              _detail tuint))
                                          (Sset _t'48
                                            (Ecast (Etempvar _t'62 tuint)
                                              tbool)))))
                                    (Sifthenelse (Etempvar _t'48 tint)
                                      (Sset _t'49
                                        (Econst_int (Int.repr 1) tint))
                                      (Ssequence
                                        (Sset _t'60
                                          (Efield
                                            (Ederef
                                              (Etempvar _r (tptr (Tstruct _result noattr)))
                                              (Tstruct _result noattr))
                                            _entry tuint))
                                        (Sset _t'49
                                          (Ecast
                                            (Ebinop One
                                              (Etempvar _t'60 tuint)
                                              (Econst_int (Int.repr 1) tint)
                                              tint) tbool)))))
                                  (Sifthenelse (Etempvar _t'49 tint)
                                    (Sset _t'50
                                      (Econst_int (Int.repr 1) tint))
                                    (Ssequence
                                      (Sset _t'59
                                        (Efield
                                          (Ederef
                                            (Etempvar _r (tptr (Tstruct _result noattr)))
                                            (Tstruct _result noattr)) _clean
                                          tuint))
                                      (Sset _t'50
                                        (Ecast (Etempvar _t'59 tuint) tbool)))))
                                (Sifthenelse (Etempvar _t'50 tint)
                                  (Sreturn (Some (Eunop Oneg
                                                   (Econst_int (Int.repr 1) tint)
                                                   tint)))
                                  Sskip))
                              Sbreak)
                            (LScons (Some 7)
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Ssequence
                                      (Ssequence
                                        (Sset _t'57 (Evar _preflight tint))
                                        (Sifthenelse (Eunop Onotbool
                                                       (Etempvar _t'57 tint)
                                                       tint)
                                          (Sset _t'51
                                            (Econst_int (Int.repr 1) tint))
                                          (Ssequence
                                            (Sset _t'58
                                              (Efield
                                                (Ederef
                                                  (Etempvar _r (tptr (Tstruct _result noattr)))
                                                  (Tstruct _result noattr))
                                                _stage tuint))
                                            (Sset _t'51
                                              (Ecast (Etempvar _t'58 tuint)
                                                tbool)))))
                                      (Sifthenelse (Etempvar _t'51 tint)
                                        (Sset _t'52
                                          (Econst_int (Int.repr 1) tint))
                                        (Ssequence
                                          (Sset _t'56
                                            (Efield
                                              (Ederef
                                                (Etempvar _r (tptr (Tstruct _result noattr)))
                                                (Tstruct _result noattr))
                                              _detail tuint))
                                          (Sset _t'52
                                            (Ecast (Etempvar _t'56 tuint)
                                              tbool)))))
                                    (Sifthenelse (Etempvar _t'52 tint)
                                      (Sset _t'53
                                        (Econst_int (Int.repr 1) tint))
                                      (Ssequence
                                        (Sset _t'55
                                          (Efield
                                            (Ederef
                                              (Etempvar _r (tptr (Tstruct _result noattr)))
                                              (Tstruct _result noattr))
                                            _entry tuint))
                                        (Sset _t'53
                                          (Ecast (Etempvar _t'55 tuint)
                                            tbool)))))
                                  (Sifthenelse (Etempvar _t'53 tint)
                                    (Sreturn (Some (Eunop Oneg
                                                     (Econst_int (Int.repr 1) tint)
                                                     tint)))
                                    Sskip))
                                Sbreak)
                              (LScons None
                                (Sreturn (Some (Eunop Oneg
                                                 (Econst_int (Int.repr 1) tint)
                                                 tint)))
                                LSnil))))))))))
            (Sreturn (Some (Econst_int (Int.repr 0) tint)))))))))
|}.

Definition f_result_of := {|
  fn_return := tvoid;
  fn_callconv := {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|};
  fn_params := ((__res, (tptr (Tstruct _result noattr))) :: (_kind, tuint) ::
                (_stage, tuint) :: (_detail, tuint) :: (_entry, tuint) ::
                nil);
  fn_vars := ((___compound, (Tstruct _result noattr)) :: nil);
  fn_temps := ((_t'2, tuint) :: (_t'1, tulong) :: nil);
  fn_body :=
(Ssequence
  (Ssequence
    (Ssequence
      (Ssequence
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Ssequence
                            (Ssequence
                              (Ssequence
                                (Ssequence
                                  (Ssequence
                                    (Ssequence
                                      (Ssequence
                                        (Ssequence
                                          (Ssequence
                                            (Ssequence
                                              (Ssequence
                                                (Ssequence
                                                  (Ssequence
                                                    (Ssequence
                                                      (Ssequence
                                                        (Ssequence
                                                          (Ssequence
                                                            (Ssequence
                                                              (Ssequence
                                                                (Ssequence
                                                                  (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Ssequence
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _kind
                                                                    tuint)
                                                                    (Etempvar _kind tuint))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _stage
                                                                    tuint)
                                                                    (Etempvar _stage tuint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _detail
                                                                    tuint)
                                                                    (Etempvar _detail tuint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _entry
                                                                    tuint)
                                                                    (Etempvar _entry tuint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _clean
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _triggers
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Ssequence
                                                                    (Sset _t'2
                                                                    (Evar _run_uid tuint))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _uid
                                                                    tuint)
                                                                    (Etempvar _t'2 tuint))))
                                                                    (Ssequence
                                                                    (Sset _t'1
                                                                    (Evar _run_id tulong))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _run
                                                                    tulong)
                                                                    (Etempvar _t'1 tulong))))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _cpu
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _peak
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _out
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _err
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _elapsed
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _oom
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _pids
                                                                    tulong)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_state
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _omitted
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_error
                                                                    tuint)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                    (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 0) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                  (Sassign
                                                                    (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 1) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                    (Econst_int (Int.repr 0) tint)))
                                                                (Sassign
                                                                  (Ederef
                                                                    (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 2) tint)
                                                                    (tptr tuchar))
                                                                    tuchar)
                                                                  (Econst_int (Int.repr 0) tint)))
                                                              (Sassign
                                                                (Ederef
                                                                  (Ebinop Oadd
                                                                    (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                    (Econst_int (Int.repr 3) tint)
                                                                    (tptr tuchar))
                                                                  tuchar)
                                                                (Econst_int (Int.repr 0) tint)))
                                                            (Sassign
                                                              (Ederef
                                                                (Ebinop Oadd
                                                                  (Efield
                                                                    (Evar ___compound (Tstruct _result noattr))
                                                                    _export_digest
                                                                    (tarray tuchar 32))
                                                                  (Econst_int (Int.repr 4) tint)
                                                                  (tptr tuchar))
                                                                tuchar)
                                                              (Econst_int (Int.repr 0) tint)))
                                                          (Sassign
                                                            (Ederef
                                                              (Ebinop Oadd
                                                                (Efield
                                                                  (Evar ___compound (Tstruct _result noattr))
                                                                  _export_digest
                                                                  (tarray tuchar 32))
                                                                (Econst_int (Int.repr 5) tint)
                                                                (tptr tuchar))
                                                              tuchar)
                                                            (Econst_int (Int.repr 0) tint)))
                                                        (Sassign
                                                          (Ederef
                                                            (Ebinop Oadd
                                                              (Efield
                                                                (Evar ___compound (Tstruct _result noattr))
                                                                _export_digest
                                                                (tarray tuchar 32))
                                                              (Econst_int (Int.repr 6) tint)
                                                              (tptr tuchar))
                                                            tuchar)
                                                          (Econst_int (Int.repr 0) tint)))
                                                      (Sassign
                                                        (Ederef
                                                          (Ebinop Oadd
                                                            (Efield
                                                              (Evar ___compound (Tstruct _result noattr))
                                                              _export_digest
                                                              (tarray tuchar 32))
                                                            (Econst_int (Int.repr 7) tint)
                                                            (tptr tuchar))
                                                          tuchar)
                                                        (Econst_int (Int.repr 0) tint)))
                                                    (Sassign
                                                      (Ederef
                                                        (Ebinop Oadd
                                                          (Efield
                                                            (Evar ___compound (Tstruct _result noattr))
                                                            _export_digest
                                                            (tarray tuchar 32))
                                                          (Econst_int (Int.repr 8) tint)
                                                          (tptr tuchar))
                                                        tuchar)
                                                      (Econst_int (Int.repr 0) tint)))
                                                  (Sassign
                                                    (Ederef
                                                      (Ebinop Oadd
                                                        (Efield
                                                          (Evar ___compound (Tstruct _result noattr))
                                                          _export_digest
                                                          (tarray tuchar 32))
                                                        (Econst_int (Int.repr 9) tint)
                                                        (tptr tuchar))
                                                      tuchar)
                                                    (Econst_int (Int.repr 0) tint)))
                                                (Sassign
                                                  (Ederef
                                                    (Ebinop Oadd
                                                      (Efield
                                                        (Evar ___compound (Tstruct _result noattr))
                                                        _export_digest
                                                        (tarray tuchar 32))
                                                      (Econst_int (Int.repr 10) tint)
                                                      (tptr tuchar)) tuchar)
                                                  (Econst_int (Int.repr 0) tint)))
                                              (Sassign
                                                (Ederef
                                                  (Ebinop Oadd
                                                    (Efield
                                                      (Evar ___compound (Tstruct _result noattr))
                                                      _export_digest
                                                      (tarray tuchar 32))
                                                    (Econst_int (Int.repr 11) tint)
                                                    (tptr tuchar)) tuchar)
                                                (Econst_int (Int.repr 0) tint)))
                                            (Sassign
                                              (Ederef
                                                (Ebinop Oadd
                                                  (Efield
                                                    (Evar ___compound (Tstruct _result noattr))
                                                    _export_digest
                                                    (tarray tuchar 32))
                                                  (Econst_int (Int.repr 12) tint)
                                                  (tptr tuchar)) tuchar)
                                              (Econst_int (Int.repr 0) tint)))
                                          (Sassign
                                            (Ederef
                                              (Ebinop Oadd
                                                (Efield
                                                  (Evar ___compound (Tstruct _result noattr))
                                                  _export_digest
                                                  (tarray tuchar 32))
                                                (Econst_int (Int.repr 13) tint)
                                                (tptr tuchar)) tuchar)
                                            (Econst_int (Int.repr 0) tint)))
                                        (Sassign
                                          (Ederef
                                            (Ebinop Oadd
                                              (Efield
                                                (Evar ___compound (Tstruct _result noattr))
                                                _export_digest
                                                (tarray tuchar 32))
                                              (Econst_int (Int.repr 14) tint)
                                              (tptr tuchar)) tuchar)
                                          (Econst_int (Int.repr 0) tint)))
                                      (Sassign
                                        (Ederef
                                          (Ebinop Oadd
                                            (Efield
                                              (Evar ___compound (Tstruct _result noattr))
                                              _export_digest
                                              (tarray tuchar 32))
                                            (Econst_int (Int.repr 15) tint)
                                            (tptr tuchar)) tuchar)
                                        (Econst_int (Int.repr 0) tint)))
                                    (Sassign
                                      (Ederef
                                        (Ebinop Oadd
                                          (Efield
                                            (Evar ___compound (Tstruct _result noattr))
                                            _export_digest
                                            (tarray tuchar 32))
                                          (Econst_int (Int.repr 16) tint)
                                          (tptr tuchar)) tuchar)
                                      (Econst_int (Int.repr 0) tint)))
                                  (Sassign
                                    (Ederef
                                      (Ebinop Oadd
                                        (Efield
                                          (Evar ___compound (Tstruct _result noattr))
                                          _export_digest (tarray tuchar 32))
                                        (Econst_int (Int.repr 17) tint)
                                        (tptr tuchar)) tuchar)
                                    (Econst_int (Int.repr 0) tint)))
                                (Sassign
                                  (Ederef
                                    (Ebinop Oadd
                                      (Efield
                                        (Evar ___compound (Tstruct _result noattr))
                                        _export_digest (tarray tuchar 32))
                                      (Econst_int (Int.repr 18) tint)
                                      (tptr tuchar)) tuchar)
                                  (Econst_int (Int.repr 0) tint)))
                              (Sassign
                                (Ederef
                                  (Ebinop Oadd
                                    (Efield
                                      (Evar ___compound (Tstruct _result noattr))
                                      _export_digest (tarray tuchar 32))
                                    (Econst_int (Int.repr 19) tint)
                                    (tptr tuchar)) tuchar)
                                (Econst_int (Int.repr 0) tint)))
                            (Sassign
                              (Ederef
                                (Ebinop Oadd
                                  (Efield
                                    (Evar ___compound (Tstruct _result noattr))
                                    _export_digest (tarray tuchar 32))
                                  (Econst_int (Int.repr 20) tint)
                                  (tptr tuchar)) tuchar)
                              (Econst_int (Int.repr 0) tint)))
                          (Sassign
                            (Ederef
                              (Ebinop Oadd
                                (Efield
                                  (Evar ___compound (Tstruct _result noattr))
                                  _export_digest (tarray tuchar 32))
                                (Econst_int (Int.repr 21) tint)
                                (tptr tuchar)) tuchar)
                            (Econst_int (Int.repr 0) tint)))
                        (Sassign
                          (Ederef
                            (Ebinop Oadd
                              (Efield
                                (Evar ___compound (Tstruct _result noattr))
                                _export_digest (tarray tuchar 32))
                              (Econst_int (Int.repr 22) tint) (tptr tuchar))
                            tuchar) (Econst_int (Int.repr 0) tint)))
                      (Sassign
                        (Ederef
                          (Ebinop Oadd
                            (Efield
                              (Evar ___compound (Tstruct _result noattr))
                              _export_digest (tarray tuchar 32))
                            (Econst_int (Int.repr 23) tint) (tptr tuchar))
                          tuchar) (Econst_int (Int.repr 0) tint)))
                    (Sassign
                      (Ederef
                        (Ebinop Oadd
                          (Efield (Evar ___compound (Tstruct _result noattr))
                            _export_digest (tarray tuchar 32))
                          (Econst_int (Int.repr 24) tint) (tptr tuchar))
                        tuchar) (Econst_int (Int.repr 0) tint)))
                  (Sassign
                    (Ederef
                      (Ebinop Oadd
                        (Efield (Evar ___compound (Tstruct _result noattr))
                          _export_digest (tarray tuchar 32))
                        (Econst_int (Int.repr 25) tint) (tptr tuchar))
                      tuchar) (Econst_int (Int.repr 0) tint)))
                (Sassign
                  (Ederef
                    (Ebinop Oadd
                      (Efield (Evar ___compound (Tstruct _result noattr))
                        _export_digest (tarray tuchar 32))
                      (Econst_int (Int.repr 26) tint) (tptr tuchar)) tuchar)
                  (Econst_int (Int.repr 0) tint)))
              (Sassign
                (Ederef
                  (Ebinop Oadd
                    (Efield (Evar ___compound (Tstruct _result noattr))
                      _export_digest (tarray tuchar 32))
                    (Econst_int (Int.repr 27) tint) (tptr tuchar)) tuchar)
                (Econst_int (Int.repr 0) tint)))
            (Sassign
              (Ederef
                (Ebinop Oadd
                  (Efield (Evar ___compound (Tstruct _result noattr))
                    _export_digest (tarray tuchar 32))
                  (Econst_int (Int.repr 28) tint) (tptr tuchar)) tuchar)
              (Econst_int (Int.repr 0) tint)))
          (Sassign
            (Ederef
              (Ebinop Oadd
                (Efield (Evar ___compound (Tstruct _result noattr))
                  _export_digest (tarray tuchar 32))
                (Econst_int (Int.repr 29) tint) (tptr tuchar)) tuchar)
            (Econst_int (Int.repr 0) tint)))
        (Sassign
          (Ederef
            (Ebinop Oadd
              (Efield (Evar ___compound (Tstruct _result noattr))
                _export_digest (tarray tuchar 32))
              (Econst_int (Int.repr 30) tint) (tptr tuchar)) tuchar)
          (Econst_int (Int.repr 0) tint)))
      (Sassign
        (Ederef
          (Ebinop Oadd
            (Efield (Evar ___compound (Tstruct _result noattr))
              _export_digest (tarray tuchar 32))
            (Econst_int (Int.repr 31) tint) (tptr tuchar)) tuchar)
        (Econst_int (Int.repr 0) tint)))
    (Sassign
      (Ederef (Etempvar __res (tptr (Tstruct _result noattr)))
        (Tstruct _result noattr))
      (Evar ___compound (Tstruct _result noattr))))
  (Sreturn None))
|}.

Definition f_fail_child := {|
  fn_return := tvoid;
  fn_callconv := cc_default;
  fn_params := ((_fd, tint) :: (_stage, tuint) :: (_error, tint) :: nil);
  fn_vars := ((_bytes, (tarray tuchar 8)) :: nil);
  fn_temps := ((_t'3, tint) :: (_t'2, tint) :: (_t'1, tint) :: nil);
  fn_body :=
(Ssequence
  (Scall None
    (Evar _put32 (Tfunction ((tptr tuchar) :: tuint :: nil) tvoid cc_default))
    ((Evar _bytes (tarray tuchar 8)) :: (Etempvar _stage tuint) :: nil))
  (Ssequence
    (Scall None
      (Evar _put32 (Tfunction ((tptr tuchar) :: tuint :: nil) tvoid
                     cc_default))
      ((Ebinop Oadd (Evar _bytes (tarray tuchar 8))
         (Econst_int (Int.repr 4) tint) (tptr tuchar)) ::
       (Ecast (Etempvar _error tint) tuint) :: nil))
    (Ssequence
      (Ssequence
        (Scall (Some _t'3)
          (Evar _fault (Tfunction ((tptr tschar) :: nil) tint cc_default))
          ((Evar ___stringlit_8 (tarray tschar 11)) :: nil))
        (Sifthenelse (Eunop Onotbool (Etempvar _t'3 tint) tint)
          (Ssequence
            (Ssequence
              (Scall (Some _t'1)
                (Evar _fault (Tfunction ((tptr tschar) :: nil) tint
                               cc_default))
                ((Evar ___stringlit_9 (tarray tschar 12)) :: nil))
              (Sifthenelse (Etempvar _t'1 tint)
                (Sset _t'2 (Ecast (Econst_int (Int.repr 3) tint) tint))
                (Sset _t'2 (Ecast (Econst_int (Int.repr 8) tint) tint))))
            (Scall None
              (Evar _write_all (Tfunction
                                 (tint :: (tptr tvoid) :: tulong :: nil) tint
                                 cc_default))
              ((Etempvar _fd tint) :: (Evar _bytes (tarray tuchar 8)) ::
               (Etempvar _t'2 tint) :: nil)))
          Sskip))
      (Scall None (Evar __exit (Tfunction (tint :: nil) tvoid cc_default))
        ((Econst_int (Int.repr 125) tint) :: nil)))))
|}.

Definition f_finish := {|
  fn_return := tint;
  fn_callconv := cc_default;
  fn_params := ((_result__1, (Tstruct _result noattr)) :: nil);
  fn_vars := ((_result__1, (Tstruct _result noattr)) :: nil);
  fn_temps := ((_t'1, tint) :: (_t'8, tuint) :: (_t'7, tuint) ::
               (_t'6, tuint) :: (_t'5, tuint) :: (_t'4, tuint) ::
               (_t'3, tuint) :: (_t'2, tuint) :: nil);
  fn_body :=
(Ssequence
  (Sassign (Evar _result__1 (Tstruct _result noattr))
    (Etempvar _result__1 (Tstruct _result noattr)))
  (Ssequence
    (Scall None
      (Evar _send_frame (Tfunction
                          (tint :: tulong :: (Tstruct _result noattr) :: nil)
                          tint cc_default))
      ((Econst_int (Int.repr 1) tint) :: (Econst_int (Int.repr 0) tint) ::
       (Evar _result__1 (Tstruct _result noattr)) :: nil))
    (Ssequence
      (Ssequence
        (Sset _t'8
          (Efield (Evar _result__1 (Tstruct _result noattr)) _kind tuint))
        (Sifthenelse (Ebinop Oeq (Etempvar _t'8 tuint)
                       (Econst_int (Int.repr 7) tint) tint)
          (Sreturn (Some (Econst_int (Int.repr 0) tint)))
          Sskip))
      (Ssequence
        (Ssequence
          (Sset _t'6
            (Efield (Evar _result__1 (Tstruct _result noattr)) _kind tuint))
          (Sifthenelse (Ebinop Oeq (Etempvar _t'6 tuint)
                         (Econst_int (Int.repr 0) tint) tint)
            (Ssequence
              (Sset _t'7
                (Efield (Evar _result__1 (Tstruct _result noattr)) _detail
                  tuint))
              (Sreturn (Some (Ecast (Etempvar _t'7 tuint) tint))))
            Sskip))
        (Ssequence
          (Ssequence
            (Sset _t'4
              (Efield (Evar _result__1 (Tstruct _result noattr)) _kind tuint))
            (Sifthenelse (Ebinop Oeq (Etempvar _t'4 tuint)
                           (Econst_int (Int.repr 2) tint) tint)
              (Ssequence
                (Sset _t'5
                  (Efield (Evar _result__1 (Tstruct _result noattr)) _detail
                    tuint))
                (Sreturn (Some (Ebinop Oadd (Econst_int (Int.repr 128) tint)
                                 (Ecast (Etempvar _t'5 tuint) tint) tint))))
              Sskip))
          (Ssequence
            (Ssequence
              (Sset _t'2
                (Efield (Evar _result__1 (Tstruct _result noattr)) _kind
                  tuint))
              (Sifthenelse (Ebinop Oeq (Etempvar _t'2 tuint)
                             (Econst_int (Int.repr 1) tint) tint)
                (Sset _t'1 (Ecast (Econst_int (Int.repr 125) tint) tint))
                (Ssequence
                  (Sset _t'3
                    (Efield (Evar _result__1 (Tstruct _result noattr)) _kind
                      tuint))
                  (Sifthenelse (Ebinop Oeq (Etempvar _t'3 tuint)
                                 (Econst_int (Int.repr 3) tint) tint)
                    (Ssequence
                      (Sset _t'1
                        (Ecast (Econst_int (Int.repr 124) tint) tint))
                      (Sset _t'1 (Ecast (Etempvar _t'1 tint) tint)))
                    (Ssequence
                      (Sset _t'1
                        (Ecast (Econst_int (Int.repr 126) tint) tint))
                      (Sset _t'1 (Ecast (Etempvar _t'1 tint) tint)))))))
            (Sreturn (Some (Etempvar _t'1 tint)))))))))
|}.

Definition f_m4_collect_failure := {|
  fn_return := tvoid;
  fn_callconv := {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|};
  fn_params := ((__res, (tptr (Tstruct _result noattr))) :: (_fd, tint) ::
                (_bad, tint) :: (_entered, tint) :: (_leader_done, tint) ::
                (_leader_status, tint) :: nil);
  fn_vars := ((_pipefd, (tarray tint 1)) ::
              (_result__1, (Tstruct _result noattr)) ::
              (_failure_bytes, (tarray tuchar 9)) ::
              (__res__1, (Tstruct _result noattr)) ::
              (__res__2, (Tstruct _result noattr)) ::
              (__res__3, (Tstruct _result noattr)) ::
              (__res__4, (Tstruct _result noattr)) :: nil);
  fn_temps := ((_used, tulong) :: (_n, tlong) :: (_t'24, tuint) ::
               (_t'23, tint) :: (_t'22, tuint) :: (_t'21, tint) ::
               (_t'20, tuint) :: (_t'19, tint) :: (_t'18, tuint) ::
               (_t'17, tint) :: (_t'16, tint) :: (_t'15, tint) ::
               (_t'14, tint) :: (_t'13, tint) :: (_t'12, tint) ::
               (_t'11, tint) :: (_t'10, tint) :: (_t'9, tint) ::
               (_t'8, tint) :: (_t'7, tint) :: (_t'6, tint) ::
               (_t'5, tuint) :: (_t'4, tuint) :: (_t'3, (tptr tint)) ::
               (_t'2, tint) :: (_t'1, tlong) :: (_t'27, tint) ::
               (_t'26, tint) :: (_t'25, tint) :: nil);
  fn_body :=
(Ssequence
  (Sassign
    (Ederef
      (Ebinop Oadd (Evar _pipefd (tarray tint 1))
        (Econst_int (Int.repr 0) tint) (tptr tint)) tint)
    (Etempvar _fd tint))
  (Ssequence
    (Sset _used (Ecast (Econst_int (Int.repr 0) tint) tulong))
    (Ssequence
      (Swhile
        (Ebinop Olt (Etempvar _used tulong)
          (Esizeof (tarray tuchar 9) tulong) tint)
        (Ssequence
          (Ssequence
            (Ssequence
              (Sset _t'27
                (Ederef
                  (Ebinop Oadd (Evar _pipefd (tarray tint 1))
                    (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
              (Scall (Some _t'1)
                (Evar _read (Tfunction
                              (tint :: (tptr tvoid) :: tulong :: nil) tlong
                              cc_default))
                ((Etempvar _t'27 tint) ::
                 (Ebinop Oadd (Evar _failure_bytes (tarray tuchar 9))
                   (Etempvar _used tulong) (tptr tuchar)) ::
                 (Ebinop Osub (Esizeof (tarray tuchar 9) tulong)
                   (Etempvar _used tulong) tulong) :: nil)))
            (Sset _n (Etempvar _t'1 tlong)))
          (Ssequence
            (Ssequence
              (Sifthenelse (Ebinop Olt (Etempvar _n tlong)
                             (Econst_int (Int.repr 0) tint) tint)
                (Ssequence
                  (Scall (Some _t'3)
                    (Evar ___errno_location (Tfunction nil (tptr tint)
                                              cc_default)) nil)
                  (Ssequence
                    (Sset _t'26 (Ederef (Etempvar _t'3 (tptr tint)) tint))
                    (Sset _t'2
                      (Ecast
                        (Ebinop Oeq (Etempvar _t'26 tint)
                          (Econst_int (Int.repr 4) tint) tint) tbool))))
                (Sset _t'2 (Econst_int (Int.repr 0) tint)))
              (Sifthenelse (Etempvar _t'2 tint) Scontinue Sskip))
            (Ssequence
              (Sifthenelse (Ebinop Olt (Etempvar _n tlong)
                             (Econst_int (Int.repr 0) tint) tint)
                (Ssequence (Sset _bad (Econst_int (Int.repr 1) tint)) Sbreak)
                Sskip)
              (Ssequence
                (Sifthenelse (Eunop Onotbool (Etempvar _n tlong) tint)
                  Sbreak
                  Sskip)
                (Sset _used
                  (Ebinop Oadd (Etempvar _used tulong)
                    (Ecast (Etempvar _n tlong) tulong) tulong)))))))
      (Ssequence
        (Ssequence
          (Sset _t'25
            (Ederef
              (Ebinop Oadd (Evar _pipefd (tarray tint 1))
                (Econst_int (Int.repr 0) tint) (tptr tint)) tint))
          (Scall None (Evar _close (Tfunction (tint :: nil) tint cc_default))
            ((Etempvar _t'25 tint) :: nil)))
        (Ssequence
          (Ssequence
            (Ssequence
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Sifthenelse (Eunop Onotbool (Etempvar _bad tint) tint)
                        (Sset _t'15
                          (Ecast
                            (Eunop Onotbool (Etempvar _entered tint) tint)
                            tbool))
                        (Sset _t'15 (Econst_int (Int.repr 0) tint)))
                      (Sifthenelse (Etempvar _t'15 tint)
                        (Sset _t'16
                          (Ecast
                            (Ebinop Oeq (Etempvar _used tulong)
                              (Econst_int (Int.repr 8) tint) tint) tbool))
                        (Sset _t'16 (Econst_int (Int.repr 0) tint))))
                    (Sifthenelse (Etempvar _t'16 tint)
                      (Ssequence
                        (Scall (Some _t'18)
                          (Evar _get32 (Tfunction ((tptr tuchar) :: nil)
                                         tuint cc_default))
                          ((Evar _failure_bytes (tarray tuchar 9)) :: nil))
                        (Sset _t'17
                          (Ecast
                            (Ebinop Oge (Etempvar _t'18 tuint)
                              (Econst_int (Int.repr 1) tint) tint) tbool)))
                      (Sset _t'17 (Econst_int (Int.repr 0) tint))))
                  (Sifthenelse (Etempvar _t'17 tint)
                    (Ssequence
                      (Scall (Some _t'20)
                        (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                                       cc_default))
                        ((Evar _failure_bytes (tarray tuchar 9)) :: nil))
                      (Sset _t'19
                        (Ecast
                          (Ebinop Ole (Etempvar _t'20 tuint)
                            (Econst_int (Int.repr 8) tint) tint) tbool)))
                    (Sset _t'19 (Econst_int (Int.repr 0) tint))))
                (Sifthenelse (Etempvar _t'19 tint)
                  (Ssequence
                    (Scall (Some _t'22)
                      (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                                     cc_default))
                      ((Ebinop Oadd (Evar _failure_bytes (tarray tuchar 9))
                         (Econst_int (Int.repr 4) tint) (tptr tuchar)) ::
                       nil))
                    (Sset _t'21
                      (Ecast
                        (Ebinop Ogt (Etempvar _t'22 tuint)
                          (Econst_int (Int.repr 0) tint) tint) tbool)))
                  (Sset _t'21 (Econst_int (Int.repr 0) tint))))
              (Sifthenelse (Etempvar _t'21 tint)
                (Ssequence
                  (Scall (Some _t'24)
                    (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                                   cc_default))
                    ((Ebinop Oadd (Evar _failure_bytes (tarray tuchar 9))
                       (Econst_int (Int.repr 4) tint) (tptr tuchar)) :: nil))
                  (Sset _t'23
                    (Ecast
                      (Ebinop Ole (Etempvar _t'24 tuint)
                        (Econst_int (Int.repr 4095) tint) tint) tbool)))
                (Sset _t'23 (Econst_int (Int.repr 0) tint))))
            (Sifthenelse (Etempvar _t'23 tint)
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Scall (Some _t'4)
                      (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                                     cc_default))
                      ((Evar _failure_bytes (tarray tuchar 9)) :: nil))
                    (Scall (Some _t'5)
                      (Evar _get32 (Tfunction ((tptr tuchar) :: nil) tuint
                                     cc_default))
                      ((Ebinop Oadd (Evar _failure_bytes (tarray tuchar 9))
                         (Econst_int (Int.repr 4) tint) (tptr tuchar)) ::
                       nil)))
                  (Scall None
                    (Evar _result_of (Tfunction
                                       ((tptr (Tstruct _result noattr)) ::
                                        tuint :: tuint :: tuint :: tuint ::
                                        nil) tvoid
                                       {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|}))
                    ((Eaddrof (Evar __res__4 (Tstruct _result noattr))
                       (tptr (Tstruct _result noattr))) ::
                     (Econst_int (Int.repr 1) tint) ::
                     (Etempvar _t'4 tuint) :: (Etempvar _t'5 tuint) ::
                     (Econst_int (Int.repr 0) tint) :: nil)))
                (Sassign (Evar _result__1 (Tstruct _result noattr))
                  (Evar __res__4 (Tstruct _result noattr))))
              (Ssequence
                (Ssequence
                  (Ssequence
                    (Ssequence
                      (Sifthenelse (Eunop Onotbool (Etempvar _bad tint) tint)
                        (Sset _t'11 (Ecast (Etempvar _entered tint) tbool))
                        (Sset _t'11 (Econst_int (Int.repr 0) tint)))
                      (Sifthenelse (Etempvar _t'11 tint)
                        (Sset _t'12
                          (Ecast
                            (Eunop Onotbool (Etempvar _used tulong) tint)
                            tbool))
                        (Sset _t'12 (Econst_int (Int.repr 0) tint))))
                    (Sifthenelse (Etempvar _t'12 tint)
                      (Sset _t'13 (Ecast (Etempvar _leader_done tint) tbool))
                      (Sset _t'13 (Econst_int (Int.repr 0) tint))))
                  (Sifthenelse (Etempvar _t'13 tint)
                    (Sset _t'14
                      (Ecast
                        (Ebinop Oeq
                          (Ebinop Oand (Etempvar _leader_status tint)
                            (Econst_int (Int.repr 127) tint) tint)
                          (Econst_int (Int.repr 0) tint) tint) tbool))
                    (Sset _t'14 (Econst_int (Int.repr 0) tint))))
                (Sifthenelse (Etempvar _t'14 tint)
                  (Ssequence
                    (Scall None
                      (Evar _result_of (Tfunction
                                         ((tptr (Tstruct _result noattr)) ::
                                          tuint :: tuint :: tuint :: tuint ::
                                          nil) tvoid
                                         {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|}))
                      ((Eaddrof (Evar __res__3 (Tstruct _result noattr))
                         (tptr (Tstruct _result noattr))) ::
                       (Econst_int (Int.repr 0) tint) ::
                       (Econst_int (Int.repr 0) tint) ::
                       (Ebinop Oshr
                         (Ebinop Oand (Etempvar _leader_status tint)
                           (Econst_int (Int.repr 65280) tint) tint)
                         (Econst_int (Int.repr 8) tint) tint) ::
                       (Econst_int (Int.repr 1) tint) :: nil))
                    (Sassign (Evar _result__1 (Tstruct _result noattr))
                      (Evar __res__3 (Tstruct _result noattr))))
                  (Ssequence
                    (Ssequence
                      (Ssequence
                        (Ssequence
                          (Sifthenelse (Eunop Onotbool (Etempvar _bad tint)
                                         tint)
                            (Sset _t'7
                              (Ecast (Etempvar _entered tint) tbool))
                            (Sset _t'7 (Econst_int (Int.repr 0) tint)))
                          (Sifthenelse (Etempvar _t'7 tint)
                            (Sset _t'8
                              (Ecast
                                (Eunop Onotbool (Etempvar _used tulong) tint)
                                tbool))
                            (Sset _t'8 (Econst_int (Int.repr 0) tint))))
                        (Sifthenelse (Etempvar _t'8 tint)
                          (Sset _t'9
                            (Ecast (Etempvar _leader_done tint) tbool))
                          (Sset _t'9 (Econst_int (Int.repr 0) tint))))
                      (Sifthenelse (Etempvar _t'9 tint)
                        (Sset _t'10
                          (Ecast
                            (Ebinop Ogt
                              (Ebinop Oshr
                                (Ecast
                                  (Ebinop Oadd
                                    (Ebinop Oand
                                      (Etempvar _leader_status tint)
                                      (Econst_int (Int.repr 127) tint) tint)
                                    (Econst_int (Int.repr 1) tint) tint)
                                  tschar) (Econst_int (Int.repr 1) tint)
                                tint) (Econst_int (Int.repr 0) tint) tint)
                            tbool))
                        (Sset _t'10 (Econst_int (Int.repr 0) tint))))
                    (Sifthenelse (Etempvar _t'10 tint)
                      (Ssequence
                        (Scall None
                          (Evar _result_of (Tfunction
                                             ((tptr (Tstruct _result noattr)) ::
                                              tuint :: tuint :: tuint ::
                                              tuint :: nil) tvoid
                                             {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|}))
                          ((Eaddrof (Evar __res__2 (Tstruct _result noattr))
                             (tptr (Tstruct _result noattr))) ::
                           (Econst_int (Int.repr 2) tint) ::
                           (Econst_int (Int.repr 0) tint) ::
                           (Ebinop Oand (Etempvar _leader_status tint)
                             (Econst_int (Int.repr 127) tint) tint) ::
                           (Econst_int (Int.repr 1) tint) :: nil))
                        (Sassign (Evar _result__1 (Tstruct _result noattr))
                          (Evar __res__2 (Tstruct _result noattr))))
                      (Ssequence
                        (Ssequence
                          (Sifthenelse (Etempvar _entered tint)
                            (Sset _t'6
                              (Ecast (Econst_int (Int.repr 1) tint) tint))
                            (Sset _t'6
                              (Ecast (Econst_int (Int.repr 2) tint) tint)))
                          (Scall None
                            (Evar _result_of (Tfunction
                                               ((tptr (Tstruct _result noattr)) ::
                                                tuint :: tuint :: tuint ::
                                                tuint :: nil) tvoid
                                               {|cc_vararg:=None; cc_unproto:=false; cc_structret:=true|}))
                            ((Eaddrof
                               (Evar __res__1 (Tstruct _result noattr))
                               (tptr (Tstruct _result noattr))) ::
                             (Econst_int (Int.repr 4) tint) ::
                             (Econst_int (Int.repr 9) tint) ::
                             (Econst_int (Int.repr 71) tint) ::
                             (Etempvar _t'6 tint) :: nil)))
                        (Sassign (Evar _result__1 (Tstruct _result noattr))
                          (Evar __res__1 (Tstruct _result noattr))))))))))
          (Ssequence
            (Sassign
              (Ederef (Etempvar __res (tptr (Tstruct _result noattr)))
                (Tstruct _result noattr))
              (Evar _result__1 (Tstruct _result noattr)))
            (Sreturn None)))))))
|}.

Definition v_m4_roots := {|
  gvar_info := (tarray (tptr (Tfunction nil tvoid cc_default)) 12);
  gvar_init := (Init_addrof _fault (Ptrofs.repr 0) ::
                Init_addrof _error_number (Ptrofs.repr 0) ::
                Init_addrof _write_all (Ptrofs.repr 0) ::
                Init_addrof _put32 (Ptrofs.repr 0) ::
                Init_addrof _put64 (Ptrofs.repr 0) ::
                Init_addrof _get32 (Ptrofs.repr 0) ::
                Init_addrof _get64 (Ptrofs.repr 0) ::
                Init_addrof _send_frame (Ptrofs.repr 0) ::
                Init_addrof _decode_frame (Ptrofs.repr 0) ::
                Init_addrof _result_of (Ptrofs.repr 0) ::
                Init_addrof _fail_child (Ptrofs.repr 0) ::
                Init_addrof _finish (Ptrofs.repr 0) :: nil);
  gvar_readonly := false;
  gvar_volatile := false
|}.

Definition composites : list composite_definition :=
(Composite _result Struct
   (Member_plain _kind tuint :: Member_plain _stage tuint ::
    Member_plain _detail tuint :: Member_plain _entry tuint ::
    Member_plain _clean tuint :: Member_plain _triggers tuint ::
    Member_plain _uid tuint :: Member_plain _run tulong ::
    Member_plain _cpu tulong :: Member_plain _peak tulong ::
    Member_plain _out tulong :: Member_plain _err tulong ::
    Member_plain _elapsed tulong :: Member_plain _oom tulong ::
    Member_plain _pids tulong :: Member_plain _export_state tuint ::
    Member_plain _omitted tuint :: Member_plain _export_error tuint ::
    Member_plain _export_digest (tarray tuchar 32) :: nil)
   noattr :: nil).

Definition global_definitions : list (ident * globdef fundef type) :=
((___compcert_va_int32,
   Gfun(External (EF_runtime "__compcert_va_int32"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tvoid) :: nil) tuint cc_default)) ::
 (___compcert_va_int64,
   Gfun(External (EF_runtime "__compcert_va_int64"
                   (mksignature (AST.Xptr :: nil) AST.Xlong cc_default))
     ((tptr tvoid) :: nil) tulong cc_default)) ::
 (___compcert_va_float64,
   Gfun(External (EF_runtime "__compcert_va_float64"
                   (mksignature (AST.Xptr :: nil) AST.Xfloat cc_default))
     ((tptr tvoid) :: nil) tdouble cc_default)) ::
 (___compcert_va_composite,
   Gfun(External (EF_runtime "__compcert_va_composite"
                   (mksignature (AST.Xptr :: AST.Xlong :: nil) AST.Xptr
                     cc_default)) ((tptr tvoid) :: tulong :: nil)
     (tptr tvoid) cc_default)) ::
 (___compcert_i64_dtos,
   Gfun(External (EF_runtime "__compcert_i64_dtos"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tlong cc_default)) ::
 (___compcert_i64_dtou,
   Gfun(External (EF_runtime "__compcert_i64_dtou"
                   (mksignature (AST.Xfloat :: nil) AST.Xlong cc_default))
     (tdouble :: nil) tulong cc_default)) ::
 (___compcert_i64_stod,
   Gfun(External (EF_runtime "__compcert_i64_stod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tlong :: nil) tdouble cc_default)) ::
 (___compcert_i64_utod,
   Gfun(External (EF_runtime "__compcert_i64_utod"
                   (mksignature (AST.Xlong :: nil) AST.Xfloat cc_default))
     (tulong :: nil) tdouble cc_default)) ::
 (___compcert_i64_stof,
   Gfun(External (EF_runtime "__compcert_i64_stof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tlong :: nil) tfloat cc_default)) ::
 (___compcert_i64_utof,
   Gfun(External (EF_runtime "__compcert_i64_utof"
                   (mksignature (AST.Xlong :: nil) AST.Xsingle cc_default))
     (tulong :: nil) tfloat cc_default)) ::
 (___compcert_i64_sdiv,
   Gfun(External (EF_runtime "__compcert_i64_sdiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_udiv,
   Gfun(External (EF_runtime "__compcert_i64_udiv"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_smod,
   Gfun(External (EF_runtime "__compcert_i64_smod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umod,
   Gfun(External (EF_runtime "__compcert_i64_umod"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) ::
 (___compcert_i64_shl,
   Gfun(External (EF_runtime "__compcert_i64_shl"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_shr,
   Gfun(External (EF_runtime "__compcert_i64_shr"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tulong :: tint :: nil) tulong cc_default)) ::
 (___compcert_i64_sar,
   Gfun(External (EF_runtime "__compcert_i64_sar"
                   (mksignature (AST.Xlong :: AST.Xint :: nil) AST.Xlong
                     cc_default)) (tlong :: tint :: nil) tlong cc_default)) ::
 (___compcert_i64_smulh,
   Gfun(External (EF_runtime "__compcert_i64_smulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___compcert_i64_umulh,
   Gfun(External (EF_runtime "__compcert_i64_umulh"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tulong :: tulong :: nil) tulong
     cc_default)) :: (___stringlit_7, Gvar v___stringlit_7) ::
 (___stringlit_8, Gvar v___stringlit_8) ::
 (___stringlit_1, Gvar v___stringlit_1) ::
 (___stringlit_9, Gvar v___stringlit_9) ::
 (___stringlit_3, Gvar v___stringlit_3) ::
 (___stringlit_2, Gvar v___stringlit_2) ::
 (___stringlit_6, Gvar v___stringlit_6) ::
 (___stringlit_5, Gvar v___stringlit_5) ::
 (___stringlit_4, Gvar v___stringlit_4) ::
 (___builtin_ais_annot,
   Gfun(External (EF_builtin "__builtin_ais_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_bswap64,
   Gfun(External (EF_builtin "__builtin_bswap64"
                   (mksignature (AST.Xlong :: nil) AST.Xlong cc_default))
     (tulong :: nil) tulong cc_default)) ::
 (___builtin_bswap,
   Gfun(External (EF_builtin "__builtin_bswap"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap32,
   Gfun(External (EF_builtin "__builtin_bswap32"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tuint cc_default)) ::
 (___builtin_bswap16,
   Gfun(External (EF_builtin "__builtin_bswap16"
                   (mksignature (AST.Xint16unsigned :: nil)
                     AST.Xint16unsigned cc_default)) (tushort :: nil) tushort
     cc_default)) ::
 (___builtin_clz,
   Gfun(External (EF_builtin "__builtin_clz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_clzl,
   Gfun(External (EF_builtin "__builtin_clzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_clzll,
   Gfun(External (EF_builtin "__builtin_clzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctz,
   Gfun(External (EF_builtin "__builtin_ctz"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tuint :: nil) tint cc_default)) ::
 (___builtin_ctzl,
   Gfun(External (EF_builtin "__builtin_ctzl"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_ctzll,
   Gfun(External (EF_builtin "__builtin_ctzll"
                   (mksignature (AST.Xlong :: nil) AST.Xint cc_default))
     (tulong :: nil) tint cc_default)) ::
 (___builtin_fabs,
   Gfun(External (EF_builtin "__builtin_fabs"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fabsf,
   Gfun(External (EF_builtin "__builtin_fabsf"
                   (mksignature (AST.Xsingle :: nil) AST.Xsingle cc_default))
     (tfloat :: nil) tfloat cc_default)) ::
 (___builtin_fsqrt,
   Gfun(External (EF_builtin "__builtin_fsqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_sqrt,
   Gfun(External (EF_builtin "__builtin_sqrt"
                   (mksignature (AST.Xfloat :: nil) AST.Xfloat cc_default))
     (tdouble :: nil) tdouble cc_default)) ::
 (___builtin_memcpy_aligned,
   Gfun(External (EF_builtin "__builtin_memcpy_aligned"
                   (mksignature
                     (AST.Xptr :: AST.Xptr :: AST.Xlong :: AST.Xlong :: nil)
                     AST.Xvoid cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: tulong :: nil) tvoid
     cc_default)) ::
 (___builtin_sel,
   Gfun(External (EF_builtin "__builtin_sel"
                   (mksignature (AST.Xbool :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tbool :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot,
   Gfun(External (EF_builtin "__builtin_annot"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     ((tptr tschar) :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (___builtin_annot_intval,
   Gfun(External (EF_builtin "__builtin_annot_intval"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xint
                     cc_default)) ((tptr tschar) :: tint :: nil) tint
     cc_default)) ::
 (___builtin_membar,
   Gfun(External (EF_builtin "__builtin_membar"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_va_start,
   Gfun(External (EF_builtin "__builtin_va_start"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_va_arg,
   Gfun(External (EF_builtin "__builtin_va_arg"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_va_copy,
   Gfun(External (EF_builtin "__builtin_va_copy"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xvoid
                     cc_default)) ((tptr tvoid) :: (tptr tvoid) :: nil) tvoid
     cc_default)) ::
 (___builtin_va_end,
   Gfun(External (EF_builtin "__builtin_va_end"
                   (mksignature (AST.Xptr :: nil) AST.Xvoid cc_default))
     ((tptr tvoid) :: nil) tvoid cc_default)) ::
 (___builtin_unreachable,
   Gfun(External (EF_builtin "__builtin_unreachable"
                   (mksignature nil AST.Xvoid cc_default)) nil tvoid
     cc_default)) ::
 (___builtin_expect,
   Gfun(External (EF_builtin "__builtin_expect"
                   (mksignature (AST.Xlong :: AST.Xlong :: nil) AST.Xlong
                     cc_default)) (tlong :: tlong :: nil) tlong cc_default)) ::
 (___builtin_fmax,
   Gfun(External (EF_builtin "__builtin_fmax"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmin,
   Gfun(External (EF_builtin "__builtin_fmin"
                   (mksignature (AST.Xfloat :: AST.Xfloat :: nil) AST.Xfloat
                     cc_default)) (tdouble :: tdouble :: nil) tdouble
     cc_default)) ::
 (___builtin_fmadd,
   Gfun(External (EF_builtin "__builtin_fmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fmsub,
   Gfun(External (EF_builtin "__builtin_fmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmadd,
   Gfun(External (EF_builtin "__builtin_fnmadd"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_fnmsub,
   Gfun(External (EF_builtin "__builtin_fnmsub"
                   (mksignature
                     (AST.Xfloat :: AST.Xfloat :: AST.Xfloat :: nil)
                     AST.Xfloat cc_default))
     (tdouble :: tdouble :: tdouble :: nil) tdouble cc_default)) ::
 (___builtin_read16_reversed,
   Gfun(External (EF_builtin "__builtin_read16_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint16unsigned
                     cc_default)) ((tptr tushort) :: nil) tushort
     cc_default)) ::
 (___builtin_read32_reversed,
   Gfun(External (EF_builtin "__builtin_read32_reversed"
                   (mksignature (AST.Xptr :: nil) AST.Xint cc_default))
     ((tptr tuint) :: nil) tuint cc_default)) ::
 (___builtin_write16_reversed,
   Gfun(External (EF_builtin "__builtin_write16_reversed"
                   (mksignature (AST.Xptr :: AST.Xint16unsigned :: nil)
                     AST.Xvoid cc_default))
     ((tptr tushort) :: tushort :: nil) tvoid cc_default)) ::
 (___builtin_write32_reversed,
   Gfun(External (EF_builtin "__builtin_write32_reversed"
                   (mksignature (AST.Xptr :: AST.Xint :: nil) AST.Xvoid
                     cc_default)) ((tptr tuint) :: tuint :: nil) tvoid
     cc_default)) ::
 (___builtin_debug,
   Gfun(External (EF_external "__builtin_debug"
                   (mksignature (AST.Xint :: nil) AST.Xvoid
                     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|}))
     (tint :: nil) tvoid
     {|cc_vararg:=(Some 1); cc_unproto:=false; cc_structret:=false|})) ::
 (_write,
   Gfun(External (EF_external "write"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (___errno_location,
   Gfun(External (EF_external "__errno_location"
                   (mksignature nil AST.Xptr cc_default)) nil (tptr tint)
     cc_default)) ::
 (_strcmp,
   Gfun(External (EF_external "strcmp"
                   (mksignature (AST.Xptr :: AST.Xptr :: nil) AST.Xint
                     cc_default)) ((tptr tschar) :: (tptr tschar) :: nil)
     tint cc_default)) ::
 (_memcmp,
   Gfun(External (EF_external "memcmp"
                   (mksignature (AST.Xptr :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xint cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: nil) tint cc_default)) ::
 (_memcpy,
   Gfun(External (EF_external "memcpy"
                   (mksignature (AST.Xptr :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xptr cc_default))
     ((tptr tvoid) :: (tptr tvoid) :: tulong :: nil) (tptr tvoid)
     cc_default)) ::
 (__exit,
   Gfun(External (EF_external "_exit"
                   (mksignature (AST.Xint :: nil) AST.Xvoid cc_default))
     (tint :: nil) tvoid cc_default)) ::
 (_read,
   Gfun(External (EF_external "read"
                   (mksignature (AST.Xint :: AST.Xptr :: AST.Xlong :: nil)
                     AST.Xlong cc_default))
     (tint :: (tptr tvoid) :: tulong :: nil) tlong cc_default)) ::
 (_close,
   Gfun(External (EF_external "close"
                   (mksignature (AST.Xint :: nil) AST.Xint cc_default))
     (tint :: nil) tint cc_default)) :: (_run_id, Gvar v_run_id) ::
 (_mode, Gvar v_mode) :: (_preflight, Gvar v_preflight) ::
 (_run_uid, Gvar v_run_uid) :: (_fault, Gfun(Internal f_fault)) ::
 (_error_number, Gfun(Internal f_error_number)) ::
 (_write_all, Gfun(Internal f_write_all)) ::
 (_put32, Gfun(Internal f_put32)) :: (_put64, Gfun(Internal f_put64)) ::
 (_get32, Gfun(Internal f_get32)) :: (_get64, Gfun(Internal f_get64)) ::
 (_send_frame, Gfun(Internal f_send_frame)) ::
 (_decode_frame, Gfun(Internal f_decode_frame)) ::
 (_result_of, Gfun(Internal f_result_of)) ::
 (_fail_child, Gfun(Internal f_fail_child)) ::
 (_finish, Gfun(Internal f_finish)) ::
 (_m4_collect_failure, Gfun(Internal f_m4_collect_failure)) ::
 (_m4_roots, Gvar v_m4_roots) :: nil).

Definition public_idents : list ident :=
(_m4_roots :: _m4_collect_failure :: _close :: _read :: __exit :: _memcpy ::
 _memcmp :: _strcmp :: ___errno_location :: _write :: ___builtin_debug ::
 ___builtin_write32_reversed :: ___builtin_write16_reversed ::
 ___builtin_read32_reversed :: ___builtin_read16_reversed ::
 ___builtin_fnmsub :: ___builtin_fnmadd :: ___builtin_fmsub ::
 ___builtin_fmadd :: ___builtin_fmin :: ___builtin_fmax ::
 ___builtin_expect :: ___builtin_unreachable :: ___builtin_va_end ::
 ___builtin_va_copy :: ___builtin_va_arg :: ___builtin_va_start ::
 ___builtin_membar :: ___builtin_annot_intval :: ___builtin_annot ::
 ___builtin_sel :: ___builtin_memcpy_aligned :: ___builtin_sqrt ::
 ___builtin_fsqrt :: ___builtin_fabsf :: ___builtin_fabs ::
 ___builtin_ctzll :: ___builtin_ctzl :: ___builtin_ctz :: ___builtin_clzll ::
 ___builtin_clzl :: ___builtin_clz :: ___builtin_bswap16 ::
 ___builtin_bswap32 :: ___builtin_bswap :: ___builtin_bswap64 ::
 ___builtin_ais_annot :: ___compcert_i64_umulh :: ___compcert_i64_smulh ::
 ___compcert_i64_sar :: ___compcert_i64_shr :: ___compcert_i64_shl ::
 ___compcert_i64_umod :: ___compcert_i64_smod :: ___compcert_i64_udiv ::
 ___compcert_i64_sdiv :: ___compcert_i64_utof :: ___compcert_i64_stof ::
 ___compcert_i64_utod :: ___compcert_i64_stod :: ___compcert_i64_dtou ::
 ___compcert_i64_dtos :: ___compcert_va_composite ::
 ___compcert_va_float64 :: ___compcert_va_int64 :: ___compcert_va_int32 ::
 nil).

Definition prog : Clight.program := 
  mkprogram composites global_definitions public_idents _main Logic.I.


