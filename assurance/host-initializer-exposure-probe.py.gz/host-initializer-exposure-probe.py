import gc
import hashlib
import importlib.util
import json
from pathlib import Path

extension = Path('/localhome/milikic/sandbox-formalization/.tools/host/gateway/initialization-runtime/python/leancage/_host.abi3.so')
events = []
retained = []
seen = set()
returned = False
in_callback = False


def observe(phase, information):
    global in_callback
    if in_callback or returned:
        return
    in_callback = True
    try:
        for candidate in object.__subclasses__():
            module = type.__getattribute__(candidate, '__module__')
            name = type.__getattribute__(candidate, '__name__')
            if module == 'leancage._host' and name in ('Workspace', 'Outcome', 'Cancellation'):
                key = (name, id(candidate))
                if key not in seen:
                    seen.add(key)
                    retained.append(candidate)
                    events.append(dict(name=name, phase=phase, module_from_spec_returned=returned))
    finally:
        in_callback = False


spec = importlib.util.spec_from_file_location('subclass_probe._host', str(extension))
old_threshold = gc.get_threshold()
gc.callbacks.append(observe)
gc.set_threshold(1, 1, 1)
try:
    module = importlib.util.module_from_spec(spec)
    returned = True
finally:
    gc.set_threshold(*old_threshold)
    gc.callbacks.remove(observe)
spec.loader.exec_module(module)
print(json.dumps(dict(events=events,
    retained_classes_match_returned={type.__getattribute__(candidate, '__name__'):
        candidate is getattr(module, type.__getattribute__(candidate, '__name__'))
        for candidate in retained},
    extension=str(extension), sha256=hashlib.file_digest(extension.open('rb'), 'sha256').hexdigest(),
    scope='read-only public weak subclass-registry probe during actual module creation; no object constructors, engine, VM or workload')))
