import FilesystemOutputSources
import FilesystemReadSources.Source
import FilesystemSnapshotReadForms
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.channel_borrow
#print axioms LeanCage.Host.Kernel.channel_borrow
#check LeanCage.Host.Kernel.actor_borrow_weaken_from
#print axioms LeanCage.Host.Kernel.actor_borrow_weaken_from
#check LeanCage.Host.Kernel.runtime_only_borrow
#print axioms LeanCage.Host.Kernel.runtime_only_borrow
#check LeanCage.Host.Kernel.lower_source_bind
#print axioms LeanCage.Host.Kernel.lower_source_bind
#check LeanCage.Host.Kernel.Lowered.actor_bind
#print axioms LeanCage.Host.Kernel.Lowered.actor_bind
#check LeanCage.Host.Kernel.Lowered.actor_filesystem
#print axioms LeanCage.Host.Kernel.Lowered.actor_filesystem
#check LeanCage.Host.Kernel.Lowered.checked_bind_borrow
#print axioms LeanCage.Host.Kernel.Lowered.checked_bind_borrow
#check LeanCage.Host.Kernel.actor_borrow_history
#print axioms LeanCage.Host.Kernel.actor_borrow_history
#check LeanCage.Host.Kernel.selected_borrowed_reference
#print axioms LeanCage.Host.Kernel.selected_borrowed_reference
#check LeanCage.Host.Kernel.Lowered.snapshot_close_directory_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_close_directory_borrow
#check LeanCage.Host.Kernel.Lowered.snapshot_enumerate_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_enumerate_borrow
#check LeanCage.Host.Kernel.Lowered.snapshot_workspace_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_workspace_borrow
#check LeanCage.Host.Kernel.Lowered.snapshot_stdin_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_stdin_borrow
#check LeanCage.Host.Kernel.Lowered.snapshot_identify_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_identify_borrow
#check LeanCage.Host.Kernel.Lowered.snapshot_freeze_borrow
#print axioms LeanCage.Host.Kernel.Lowered.snapshot_freeze_borrow
#check LeanCage.Host.Kernel.Lowered.execute_checked_borrow
#print axioms LeanCage.Host.Kernel.Lowered.execute_checked_borrow
#check LeanCage.Host.Kernel.Lowered.dispatch_borrow
#print axioms LeanCage.Host.Kernel.Lowered.dispatch_borrow
#check LeanCage.Host.Kernel.Lowered.cli_borrow
#print axioms LeanCage.Host.Kernel.Lowered.cli_borrow
#check LeanCage.Host.Kernel.Lowered.commands_borrow
#print axioms LeanCage.Host.Kernel.Lowered.commands_borrow
#check LeanCage.Host.Kernel.Lowered.entrypoint_borrow
#print axioms LeanCage.Host.Kernel.Lowered.entrypoint_borrow
#check LeanCage.Host.Kernel.actual_live_inherited_reference
#print axioms LeanCage.Host.Kernel.actual_live_inherited_reference
#check LeanCage.Host.Kernel.actual_inherited_operation_reference
#print axioms LeanCage.Host.Kernel.actual_inherited_operation_reference
#check LeanCage.Host.Kernel.Lowered.actor_checked_bind
#print axioms LeanCage.Host.Kernel.Lowered.actor_checked_bind
#check LeanCage.Host.Kernel.Lowered.actor_lift_borrow
#print axioms LeanCage.Host.Kernel.Lowered.actor_lift_borrow
#check LeanCage.Host.Kernel.Lowered.validator_finish_borrow
#print axioms LeanCage.Host.Kernel.Lowered.validator_finish_borrow
#check LeanCage.Host.Kernel.Lowered.validator_borrow
#print axioms LeanCage.Host.Kernel.Lowered.validator_borrow
#check LeanCage.Host.Kernel.Lowered.policy_prepare_borrow
#print axioms LeanCage.Host.Kernel.Lowered.policy_prepare_borrow
#check LeanCage.Host.Kernel.Lowered.dispatch_image_borrow
#print axioms LeanCage.Host.Kernel.Lowered.dispatch_image_borrow
#check LeanCage.Host.Kernel.Lowered.cleanup_run_borrow
#print axioms LeanCage.Host.Kernel.Lowered.cleanup_run_borrow
#check LeanCage.Host.Kernel.Lowered.duration_borrow
#print axioms LeanCage.Host.Kernel.Lowered.duration_borrow
#check LeanCage.Host.Kernel.Lowered.execute_run_borrow
#print axioms LeanCage.Host.Kernel.Lowered.execute_run_borrow
#check LeanCage.Host.Kernel.Lowered.bootstrap_read_borrow
#print axioms LeanCage.Host.Kernel.Lowered.bootstrap_read_borrow
#check LeanCage.Host.Kernel.Lowered.load_bundle_borrow
#print axioms LeanCage.Host.Kernel.Lowered.load_bundle_borrow
#check LeanCage.Host.Kernel.Lowered.identified_copy_borrow
#print axioms LeanCage.Host.Kernel.Lowered.identified_copy_borrow
#check LeanCage.Host.Kernel.Lowered.check_file_borrow
#print axioms LeanCage.Host.Kernel.Lowered.check_file_borrow
#check LeanCage.Host.Kernel.Lowered.check_bundle_borrow
#print axioms LeanCage.Host.Kernel.Lowered.check_bundle_borrow
#check LeanCage.Host.Kernel.Lowered.running_image_borrow
#print axioms LeanCage.Host.Kernel.Lowered.running_image_borrow
#check LeanCage.Host.Kernel.Lowered.policy_load_borrow
#print axioms LeanCage.Host.Kernel.Lowered.policy_load_borrow
#check LeanCage.Host.Kernel.Lowered.seal_borrow
#print axioms LeanCage.Host.Kernel.Lowered.seal_borrow
#check LeanCage.Host.Kernel.Lowered.packet_exact_borrow
#print axioms LeanCage.Host.Kernel.Lowered.packet_exact_borrow
#check LeanCage.Host.Kernel.Lowered.packet_read_borrow
#print axioms LeanCage.Host.Kernel.Lowered.packet_read_borrow
#check LeanCage.Host.Kernel.Lowered.close_effect_borrow
#print axioms LeanCage.Host.Kernel.Lowered.close_effect_borrow
#check LeanCage.Host.Kernel.Lowered.directory_descend_borrow
#print axioms LeanCage.Host.Kernel.Lowered.directory_descend_borrow
#check LeanCage.Host.Kernel.Lowered.directory_parent_borrow
#print axioms LeanCage.Host.Kernel.Lowered.directory_parent_borrow
#check LeanCage.Host.Kernel.Lowered.temporary_parent_borrow
#print axioms LeanCage.Host.Kernel.Lowered.temporary_parent_borrow
#check LeanCage.Host.Kernel.Lowered.run_create_borrow
#print axioms LeanCage.Host.Kernel.Lowered.run_create_borrow
#check LeanCage.Host.Kernel.Lowered.run_release_borrow
#print axioms LeanCage.Host.Kernel.Lowered.run_release_borrow
#check LeanCage.Host.Kernel.Lowered.run_cleanup_borrow
#print axioms LeanCage.Host.Kernel.Lowered.run_cleanup_borrow
#check LeanCage.Host.Kernel.Lowered.image_writer_borrow
#print axioms LeanCage.Host.Kernel.Lowered.image_writer_borrow
#check LeanCage.Host.Kernel.Lowered.image_create_borrow
#print axioms LeanCage.Host.Kernel.Lowered.image_create_borrow
#check LeanCage.Host.Kernel.Lowered.outcome_identify_borrow
#print axioms LeanCage.Host.Kernel.Lowered.outcome_identify_borrow
#check LeanCage.Host.Kernel.Lowered.publication_unlink_relative_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_unlink_relative_borrow
#check LeanCage.Host.Kernel.Lowered.publication_cleanup_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_cleanup_borrow
#check LeanCage.Host.Kernel.Lowered.publication_close_owned_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_close_owned_borrow
#check LeanCage.Host.Kernel.Lowered.publication_finish_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_finish_borrow
#check LeanCage.Host.Kernel.Lowered.publication_absolute_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_absolute_borrow
#check LeanCage.Host.Kernel.Lowered.publication_destination_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_destination_borrow
#check LeanCage.Host.Kernel.Lowered.publication_attempt_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_attempt_borrow
#check LeanCage.Host.Kernel.Lowered.publication_publish_borrow
#print axioms LeanCage.Host.Kernel.Lowered.publication_publish_borrow
#check LeanCage.Host.Kernel.Lowered.hash_only_borrow
#print axioms LeanCage.Host.Kernel.Lowered.hash_only_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_read_file_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_read_file_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_optional_file_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_optional_file_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_collect_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_collect_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_export_blobs_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_export_blobs_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_manifest_blobs_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_manifest_blobs_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_result_json_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_result_json_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_marker_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_marker_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_verify_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_verify_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_policy_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_policy_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_validate_metadata_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_validate_metadata_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_complete_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_complete_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_stored_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_stored_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_destination_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_destination_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_at_destination_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_at_destination_borrow
#check LeanCage.Host.Kernel.Lowered.retrieval_report_borrow
#print axioms LeanCage.Host.Kernel.Lowered.retrieval_report_borrow
#check LeanCage.Host.Snapshot.walk_input
#print axioms LeanCage.Host.Snapshot.walk_input
#check LeanCage.Host.Snapshot.walkChildren_input
#print axioms LeanCage.Host.Snapshot.walkChildren_input
#check LeanCage.Host.Snapshot.copyWorkspace_input
#print axioms LeanCage.Host.Snapshot.copyWorkspace_input
#check LeanCage.Host.Snapshot.copyStdin_input
#print axioms LeanCage.Host.Snapshot.copyStdin_input
#check LeanCage.Host.Snapshot.freeze_input
#print axioms LeanCage.Host.Snapshot.freeze_input
#check LeanCage.Host.Snapshot.freeze_no_write_prefix
#print axioms LeanCage.Host.Snapshot.freeze_no_write_prefix
#check LeanCage.Host.Snapshot.input_bind
#print axioms LeanCage.Host.Snapshot.input_bind
#check LeanCage.Host.Snapshot.input_prefix
#print axioms LeanCage.Host.Snapshot.input_prefix
#check LeanCage.Host.Snapshot.readLoop_input
#print axioms LeanCage.Host.Snapshot.readLoop_input
#check LeanCage.Host.Snapshot.closeResult_input
#print axioms LeanCage.Host.Snapshot.closeResult_input
#check LeanCage.Host.Snapshot.copyOpened_input
#print axioms LeanCage.Host.Snapshot.copyOpened_input
#check LeanCage.Host.Snapshot.copyAt_input
#print axioms LeanCage.Host.Snapshot.copyAt_input
#check LeanCage.Host.Snapshot.hash_input
#print axioms LeanCage.Host.Snapshot.hash_input
#check LeanCage.Host.Snapshot.closeDirectory_input
#print axioms LeanCage.Host.Snapshot.closeDirectory_input
#check LeanCage.Host.Snapshot.enumerate_input
#print axioms LeanCage.Host.Snapshot.enumerate_input
#check LeanCage.Host.Snapshot.closeResult_post
#print axioms LeanCage.Host.Snapshot.closeResult_post
#check LeanCage.Host.Snapshot.closeDirectory_post
#print axioms LeanCage.Host.Snapshot.closeDirectory_post
#check LeanCage.Host.Snapshot.closeDirectory_value
#print axioms LeanCage.Host.Snapshot.closeDirectory_value
#check LeanCage.Host.Snapshot.state_blobs
#print axioms LeanCage.Host.Snapshot.state_blobs
#check LeanCage.Host.Snapshot.walk_state_valid
#print axioms LeanCage.Host.Snapshot.walk_state_valid
#check LeanCage.Host.Snapshot.walkChildren_state_valid
#print axioms LeanCage.Host.Snapshot.walkChildren_state_valid
#check LeanCage.Host.Snapshot.copyWorkspace_state_valid
#print axioms LeanCage.Host.Snapshot.copyWorkspace_state_valid
#check LeanCage.Host.Snapshot.public_child
#print axioms LeanCage.Host.Snapshot.public_child
#check LeanCage.Host.Snapshot.acquired_frame
#print axioms LeanCage.Host.Snapshot.acquired_frame
#check LeanCage.Host.Snapshot.appendEntry_update
#print axioms LeanCage.Host.Snapshot.appendEntry_update
#check LeanCage.Host.Snapshot.appendEntry_blobs
#print axioms LeanCage.Host.Snapshot.appendEntry_blobs
#check LeanCage.Host.Snapshot.walk_acquired
#print axioms LeanCage.Host.Snapshot.walk_acquired
#check LeanCage.Host.Snapshot.walkChildren_acquired
#print axioms LeanCage.Host.Snapshot.walkChildren_acquired
#check LeanCage.Host.Snapshot.copyWorkspace_origin
#print axioms LeanCage.Host.Snapshot.copyWorkspace_origin
#check LeanCage.Host.Snapshot.copyWorkspace_acquired
#print axioms LeanCage.Host.Snapshot.copyWorkspace_acquired
#check LeanCage.Host.Kernel.closeDirectory_noRead
#print axioms LeanCage.Host.Kernel.closeDirectory_noRead
#print LeanCage.Host.Kernel.DirectoryRetirementContract
#print axioms LeanCage.Host.Kernel.DirectoryRetirementContract
#print LeanCage.Host.Snapshot.closeDirectory
#print axioms LeanCage.Host.Snapshot.closeDirectory
#print LeanCage.Host.Snapshot.walk
#print axioms LeanCage.Host.Snapshot.walk
#print LeanCage.Host.Entrypoint.run
#print axioms LeanCage.Host.Entrypoint.run
#print LeanCage.Host.Kernel.RuntimeDescriptorContract
#print axioms LeanCage.Host.Kernel.RuntimeDescriptorContract
#print LeanCage.Host.Kernel.ActorBorrowPost
#print axioms LeanCage.Host.Kernel.ActorBorrowPost
