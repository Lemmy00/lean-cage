import TransportProofs
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
#check @LeanCage.Host.littleEndian_size
#print axioms LeanCage.Host.littleEndian_size
#check @LeanCage.Host.fromLittleEndian_bound
#print axioms LeanCage.Host.fromLittleEndian_bound
#check @LeanCage.Host.fromLittleEndian_littleEndian
#print axioms LeanCage.Host.fromLittleEndian_littleEndian
#check @LeanCage.Host.fromLittleEndian_littleEndian_exact
#print axioms LeanCage.Host.fromLittleEndian_littleEndian_exact
#check @LeanCage.Host.littleEndian_fromLittleEndian
#print axioms LeanCage.Host.littleEndian_fromLittleEndian
#check @LeanCage.Host.littleEndian_injective
#print axioms LeanCage.Host.littleEndian_injective
#check @LeanCage.Host.Transport.step_error
#print axioms LeanCage.Host.Transport.step_error
#check @LeanCage.Host.Transport.byte_error
#print axioms LeanCage.Host.Transport.byte_error
#check @LeanCage.Host.Transport.run_error
#print axioms LeanCage.Host.Transport.run_error
#check @LeanCage.Host.Transport.fail_report
#print axioms LeanCage.Host.Transport.fail_report
#check @LeanCage.Host.Transport.oversized_chunk
#print axioms LeanCage.Host.Transport.oversized_chunk
#check @LeanCage.Host.Transport.bytes_append
#print axioms LeanCage.Host.Transport.bytes_append
#check @LeanCage.Host.Transport.header_parse_fields
#print axioms LeanCage.Host.Transport.header_parse_fields
#check @LeanCage.Host.Transport.finish_requires_eof
#print axioms LeanCage.Host.Transport.finish_requires_eof
#check @LeanCage.Host.Transport.finish_clean
#print axioms LeanCage.Host.Transport.finish_clean
#check @LeanCage.Host.Transport.init_fields
#print axioms LeanCage.Host.Transport.init_fields
#check @LeanCage.Host.Transport.prefix_size
#print axioms LeanCage.Host.Transport.prefix_size
#check @LeanCage.Host.Transport.cap_le_active
#print axioms LeanCage.Host.Transport.cap_le_active
#check @LeanCage.Host.Transport.acceptHeader_fields
#print axioms LeanCage.Host.Transport.acceptHeader_fields
#check @LeanCage.Host.Transport.commit_ok
#print axioms LeanCage.Host.Transport.commit_ok
#check @LeanCage.Host.Transport.header_parse_self
#print axioms LeanCage.Host.Transport.header_parse_self
#check @LeanCage.Host.Transport.header_word64
#print axioms LeanCage.Host.Transport.header_word64
#check @LeanCage.Host.Transport.acceptBlob_fields
#print axioms LeanCage.Host.Transport.acceptBlob_fields
#check @LeanCage.Host.Transport.bounded_fail
#print axioms LeanCage.Host.Transport.bounded_fail
#check @LeanCage.Host.Transport.bounded_init
#print axioms LeanCage.Host.Transport.bounded_init
#check @LeanCage.Host.Transport.bounded_append
#print axioms LeanCage.Host.Transport.bounded_append
#check @LeanCage.Host.Transport.bounded_commit
#print axioms LeanCage.Host.Transport.bounded_commit
#check @LeanCage.Host.Transport.bounded_phase
#print axioms LeanCage.Host.Transport.bounded_phase
#check @LeanCage.Host.Transport.bounded_byte
#print axioms LeanCage.Host.Transport.bounded_byte
#check @LeanCage.Host.Transport.bounded_bytes
#print axioms LeanCage.Host.Transport.bounded_bytes
#check @LeanCage.Host.Transport.bounded_step
#print axioms LeanCage.Host.Transport.bounded_step
#check @LeanCage.Host.Transport.bounded_run
#print axioms LeanCage.Host.Transport.bounded_run
#check @LeanCage.Host.Transport.frame_count
#print axioms LeanCage.Host.Transport.frame_count
#check @LeanCage.Host.Transport.bounded_storage
#print axioms LeanCage.Host.Transport.bounded_storage
#check @LeanCage.Host.Transport.tag_beq
#print axioms LeanCage.Host.Transport.tag_beq
#check @LeanCage.Host.Transport.ledger_commit
#print axioms LeanCage.Host.Transport.ledger_commit
#check @LeanCage.Host.Transport.ledger_byte
#print axioms LeanCage.Host.Transport.ledger_byte
#check @LeanCage.Host.Transport.indexed_empty
#print axioms LeanCage.Host.Transport.indexed_empty
#check @LeanCage.Host.Transport.indexed_append
#print axioms LeanCage.Host.Transport.indexed_append
#check @LeanCage.Host.Transport.indexed_byte
#print axioms LeanCage.Host.Transport.indexed_byte
#check @LeanCage.Host.Transport.indexed_bytes
#print axioms LeanCage.Host.Transport.indexed_bytes
#check @LeanCage.Host.Transport.indexed_step
#print axioms LeanCage.Host.Transport.indexed_step
#check @LeanCage.Host.Transport.indexed_run
#print axioms LeanCage.Host.Transport.indexed_run
#check @LeanCage.Host.Transport.framed_commit
#print axioms LeanCage.Host.Transport.framed_commit
#check @LeanCage.Host.Transport.framed_byte
#print axioms LeanCage.Host.Transport.framed_byte
#check @LeanCage.Host.Transport.framed_bytes
#print axioms LeanCage.Host.Transport.framed_bytes
#check @LeanCage.Host.Transport.framed_step
#print axioms LeanCage.Host.Transport.framed_step
#check @LeanCage.Host.Transport.framed_run
#print axioms LeanCage.Host.Transport.framed_run
#check @LeanCage.Host.Transport.append_wire
#print axioms LeanCage.Host.Transport.append_wire
#check @LeanCage.Host.Transport.commit_wire
#print axioms LeanCage.Host.Transport.commit_wire
#check @LeanCage.Host.Transport.byte_clean_before
#print axioms LeanCage.Host.Transport.byte_clean_before
#check @LeanCage.Host.Transport.byte_wire
#print axioms LeanCage.Host.Transport.byte_wire
#check @LeanCage.Host.Transport.bytes_error
#print axioms LeanCage.Host.Transport.bytes_error
#check @LeanCage.Host.Transport.bytes_clean_before
#print axioms LeanCage.Host.Transport.bytes_clean_before
#check @LeanCage.Host.Transport.bytes_wire
#print axioms LeanCage.Host.Transport.bytes_wire
#check @LeanCage.Host.Transport.step_clean_before
#print axioms LeanCage.Host.Transport.step_clean_before
#check @LeanCage.Host.Transport.run_clean_before
#print axioms LeanCage.Host.Transport.run_clean_before
#check @LeanCage.Host.Transport.step_wire
#print axioms LeanCage.Host.Transport.step_wire
#check @LeanCage.Host.Transport.run_wire
#print axioms LeanCage.Host.Transport.run_wire
#check @LeanCage.Host.Transport.commit_preserves
#print axioms LeanCage.Host.Transport.commit_preserves
#check @LeanCage.Host.Transport.byte_preserves
#print axioms LeanCage.Host.Transport.byte_preserves
#check @LeanCage.Host.Transport.byte_static
#print axioms LeanCage.Host.Transport.byte_static
#check @LeanCage.Host.Transport.bytes_static
#print axioms LeanCage.Host.Transport.bytes_static
#check @LeanCage.Host.Transport.step_config
#print axioms LeanCage.Host.Transport.step_config
#check @LeanCage.Host.Transport.run_config
#print axioms LeanCage.Host.Transport.run_config
#check @LeanCage.Host.Transport.data_fragmentation
#print axioms LeanCage.Host.Transport.data_fragmentation
#check @LeanCage.Host.Transport.data_step_eq_bytes
#print axioms LeanCage.Host.Transport.data_step_eq_bytes
#check @LeanCage.Host.Transport.data_normal_form
#print axioms LeanCage.Host.Transport.data_normal_form
#check @LeanCage.Host.Transport.arbitrary_fragmentation
#print axioms LeanCage.Host.Transport.arbitrary_fragmentation
#check @LeanCage.Host.Transport.finish_shape
#print axioms LeanCage.Host.Transport.finish_shape
#check @LeanCage.Host.Transport.accepted_stream
#print axioms LeanCage.Host.Transport.accepted_stream
#check @LeanCage.Host.Transport.frameWire_injective
#print axioms LeanCage.Host.Transport.frameWire_injective
#check @LeanCage.Host.Transport.record_member
#print axioms LeanCage.Host.Transport.record_member
#check @LeanCage.Host.Transport.record_bounded
#print axioms LeanCage.Host.Transport.record_bounded
#check @LeanCage.Host.Transport.known_report_byte
#print axioms LeanCage.Host.Transport.known_report_byte
#check @LeanCage.Host.Transport.known_report_bytes
#print axioms LeanCage.Host.Transport.known_report_bytes
#check @LeanCage.Host.Transport.known_report_step
#print axioms LeanCage.Host.Transport.known_report_step
#check @LeanCage.Host.Transport.known_report_run
#print axioms LeanCage.Host.Transport.known_report_run
#check @LeanCage.Host.Transport.accepted_unique_records
#print axioms LeanCage.Host.Transport.accepted_unique_records
#check @LeanCage.Host.Transport.blob_output_count
#print axioms LeanCage.Host.Transport.blob_output_count
#check @LeanCage.Host.Transport.blob_output_bytes
#print axioms LeanCage.Host.Transport.blob_output_bytes
#check @LeanCage.Host.Transport.accepted_blob_bounds
#print axioms LeanCage.Host.Transport.accepted_blob_bounds
#check @LeanCage.Host.Transport.blob_key_injective
#print axioms LeanCage.Host.Transport.blob_key_injective
#check @LeanCage.Host.Transport.bounded_active_bytes
#print axioms LeanCage.Host.Transport.bounded_active_bytes
#check @LeanCage.Host.Transport.accepted_record_bounds
#print axioms LeanCage.Host.Transport.accepted_record_bounds
#check @LeanCage.Host.Transport.reachable_invariants
#print axioms LeanCage.Host.Transport.reachable_invariants
#check @LeanCage.Host.Transport.data_eof_static
#print axioms LeanCage.Host.Transport.data_eof_static
#check @LeanCage.Host.Transport.step_eof_origin
#print axioms LeanCage.Host.Transport.step_eof_origin
#check @LeanCage.Host.Transport.run_eof_origin
#print axioms LeanCage.Host.Transport.run_eof_origin
#check @LeanCage.Host.Transport.accepted_has_eof
#print axioms LeanCage.Host.Transport.accepted_has_eof
#check @LeanCage.Host.Transport.terminal_parse_fields
#print axioms LeanCage.Host.Transport.terminal_parse_fields
#check @LeanCage.Host.Transport.accepted_terminal_bounds
#print axioms LeanCage.Host.Transport.accepted_terminal_bounds
#check @LeanCage.Host.Transport.accepted_output_copies
#print axioms LeanCage.Host.Transport.accepted_output_copies
#check @LeanCage.Host.Transport.error_message_bounded
#print axioms LeanCage.Host.Transport.error_message_bounded
#check @LeanCage.Host.Transport.Witness.initialized
#print axioms LeanCage.Host.Transport.Witness.initialized
#check @LeanCage.Host.Transport.Witness.useful_exact
#print axioms LeanCage.Host.Transport.Witness.useful_exact
#check @LeanCage.Host.Transport.Witness.eof_required
#print axioms LeanCage.Host.Transport.Witness.eof_required
#check @LeanCage.Host.Transport.Witness.truncation_rejected
#print axioms LeanCage.Host.Transport.Witness.truncation_rejected
#check @LeanCage.Host.Transport.Witness.trailing_rejected
#print axioms LeanCage.Host.Transport.Witness.trailing_rejected
#check @LeanCage.Host.Transport.Witness.eof_is_final
#print axioms LeanCage.Host.Transport.Witness.eof_is_final
#check @LeanCage.Host.Transport.Witness.duplicate_report_rejected
#print axioms LeanCage.Host.Transport.Witness.duplicate_report_rejected
#check @LeanCage.Host.Transport.Witness.duplicate_preserves_report
#print axioms LeanCage.Host.Transport.Witness.duplicate_preserves_report
#check @LeanCage.Host.Transport.Witness.reserved_rejected
#print axioms LeanCage.Host.Transport.Witness.reserved_rejected
#check @LeanCage.Host.Transport.Witness.unknown_tag_rejected
#print axioms LeanCage.Host.Transport.Witness.unknown_tag_rejected
#check @LeanCage.Host.Transport.Witness.maximum_uint64_rejected
#print axioms LeanCage.Host.Transport.Witness.maximum_uint64_rejected
#check @LeanCage.Host.Transport.Witness.terminal_bounds_rejected
#print axioms LeanCage.Host.Transport.Witness.terminal_bounds_rejected
#check @LeanCage.Host.Transport.Witness.useful_blob_exact
#print axioms LeanCage.Host.Transport.Witness.useful_blob_exact
#check @LeanCage.Host.Transport.Witness.duplicate_blob_rejected
#print axioms LeanCage.Host.Transport.Witness.duplicate_blob_rejected
#check @LeanCage.Host.Transport.Witness.aggregate_bytes_rejected
#print axioms LeanCage.Host.Transport.Witness.aggregate_bytes_rejected
#check @LeanCage.Host.Transport.Witness.malformed_digest_rejected
#print axioms LeanCage.Host.Transport.Witness.malformed_digest_rejected
#check @LeanCage.Host.Transport.Witness.short_blob_rejected
#print axioms LeanCage.Host.Transport.Witness.short_blob_rejected
#check @LeanCage.Host.Transport.Witness.missing_report_rejected
#print axioms LeanCage.Host.Transport.Witness.missing_report_rejected
#check @LeanCage.Host.Transport.Witness.mismatched_identity_rejected
#print axioms LeanCage.Host.Transport.Witness.mismatched_identity_rejected
#print LeanCage.Host.Transport.Limits
#print LeanCage.Host.Transport.Limits.Valid
#print LeanCage.Host.Transport.Header
#print LeanCage.Host.Transport.Header.parse
#print LeanCage.Host.Transport.Frame
#print LeanCage.Host.Transport.Frame.Valid
#print LeanCage.Host.Transport.Terminal
#print LeanCage.Host.Transport.Terminal.parse
#print LeanCage.Host.Transport.State
#print LeanCage.Host.Transport.State.init
#print LeanCage.Host.Transport.State.acceptHeader
#print LeanCage.Host.Transport.State.acceptBlob
#print LeanCage.Host.Transport.State.commit?
#print LeanCage.Host.Transport.State.byte
#print LeanCage.Host.Transport.State.step
#print LeanCage.Host.Transport.State.run
#print LeanCage.Host.Transport.State.finish
#print LeanCage.Host.Transport.State.Bounded
#print LeanCage.Host.Transport.Indexed
#print LeanCage.Host.Transport.State.Framed
#print LeanCage.Host.Transport.Result
#print LeanCage.Host.Transport.retainedBudget
#print LeanCage.Host.Transport.activeBudget
