import FilesystemNativeExecRows
import FilesystemNativeForkRows
set_option pp.universes true
set_option pp.proofs true
set_option pp.explicit true
set_option pp.fullNames true
#check @LeanCage.Host.NativeCode.encode_call_exact
#check @LeanCage.Host.NativeCode.bound_source_row
#check @LeanCage.Host.NativeCode.source_handle_at
#check @LeanCage.Host.NativeCode.source_committed_fork
#check @LeanCage.Host.NativeCode.source_fork_references
#check @LeanCage.Host.NativeChannels.initial_binding_of_native_evidence
#check @LeanCage.Host.NativeChannels.actual_exec_binding
#print LeanCage.Host.NativeCode.PrimitiveRowAt
#print LeanCage.Host.NativeCode.Interprets
#print LeanCage.Host.NativeCode.SelectedCall
#print LeanCage.Host.NativeCode.ForkReferences
#print LeanCage.Host.NativeChannels.Evidence
#print axioms LeanCage.Host.NativeCode.encode_call_exact
#print axioms LeanCage.Host.NativeCode.bound_source_row
#print axioms LeanCage.Host.NativeCode.source_handle_at
#print axioms LeanCage.Host.NativeCode.source_committed_fork
#print axioms LeanCage.Host.NativeCode.source_fork_references
#print axioms LeanCage.Host.NativeChannels.initial_binding_of_native_evidence
#print axioms LeanCage.Host.NativeChannels.actual_exec_binding
