import FilesystemInitial
import FilesystemDirectorySources
import FilesystemMetadata
import FilesystemRootAuthority
import FilesystemExecFlags
import FilesystemHandoff
import FilesystemLookups
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.rawObjects_live
#print axioms LeanCage.Host.Kernel.rawObjects_live
#check LeanCage.Host.Kernel.initial_reference_ipc
#print axioms LeanCage.Host.Kernel.initial_reference_ipc
#check LeanCage.Host.Kernel.initial_reference_outside_data
#print axioms LeanCage.Host.Kernel.initial_reference_outside_data
#check LeanCage.Host.Kernel.actual_new_child_call
#print axioms LeanCage.Host.Kernel.actual_new_child_call
#check LeanCage.Host.Kernel.actual_fresh_child_call
#print axioms LeanCage.Host.Kernel.actual_fresh_child_call
#check LeanCage.Host.Kernel.actual_run_child_call
#print axioms LeanCage.Host.Kernel.actual_run_child_call
#check LeanCage.Host.Kernel.same_authority_trans
#print axioms LeanCage.Host.Kernel.same_authority_trans
#check LeanCage.Host.Kernel.same_authority_regular
#print axioms LeanCage.Host.Kernel.same_authority_regular
#check LeanCage.Host.Kernel.same_authority_directory
#print axioms LeanCage.Host.Kernel.same_authority_directory
#check LeanCage.Host.Kernel.same_authority_mask
#print axioms LeanCage.Host.Kernel.same_authority_mask
#check LeanCage.Host.Kernel.same_authority_trusted
#print axioms LeanCage.Host.Kernel.same_authority_trusted
#check LeanCage.Host.Kernel.operation_keeps_authority
#print axioms LeanCage.Host.Kernel.operation_keeps_authority
#check LeanCage.Host.Kernel.foreign_host_authority_retained
#print axioms LeanCage.Host.Kernel.foreign_host_authority_retained
#check LeanCage.Host.Kernel.foreign_unowned_authority_retained
#print axioms LeanCage.Host.Kernel.foreign_unowned_authority_retained
#check LeanCage.Host.Kernel.masked_no_search
#print axioms LeanCage.Host.Kernel.masked_no_search
#check LeanCage.Host.Kernel.masked_no_write
#print axioms LeanCage.Host.Kernel.masked_no_write
#check LeanCage.Host.Kernel.fresh_mkdir_foreign_denied
#print axioms LeanCage.Host.Kernel.fresh_mkdir_foreign_denied
#check LeanCage.Host.Kernel.actual_private_mkdir_birth
#print axioms LeanCage.Host.Kernel.actual_private_mkdir_birth
#check LeanCage.Host.Kernel.root_authority_after
#print axioms LeanCage.Host.Kernel.root_authority_after
#check LeanCage.Host.Kernel.foreign_root_authority_after
#print axioms LeanCage.Host.Kernel.foreign_root_authority_after
#check LeanCage.Host.Kernel.ordinary_foreign_preserves_root
#print axioms LeanCage.Host.Kernel.ordinary_foreign_preserves_root
#check LeanCage.Host.Kernel.ordinary_foreign_root_authorities
#print axioms LeanCage.Host.Kernel.ordinary_foreign_root_authorities
#check LeanCage.Host.Kernel.register_actual_root_authority
#print axioms LeanCage.Host.Kernel.register_actual_root_authority
#check LeanCage.Host.Kernel.closed_open_bit
#print axioms LeanCage.Host.Kernel.closed_open_bit
#check LeanCage.Host.Kernel.step_flags_covered
#print axioms LeanCage.Host.Kernel.step_flags_covered
#check LeanCage.Host.Kernel.step_seal_flags_covered
#print axioms LeanCage.Host.Kernel.step_seal_flags_covered
#check LeanCage.Host.Kernel.runtime_flags_covered
#print axioms LeanCage.Host.Kernel.runtime_flags_covered
#check LeanCage.Host.Kernel.initial_channels_covered
#print axioms LeanCage.Host.Kernel.initial_channels_covered
#check LeanCage.Host.Kernel.passive_closed_open
#print axioms LeanCage.Host.Kernel.passive_closed_open
#check LeanCage.Host.Kernel.safe_closed_open
#print axioms LeanCage.Host.Kernel.safe_closed_open
#check LeanCage.Host.Kernel.safe_closed_program
#print axioms LeanCage.Host.Kernel.safe_closed_program
#check LeanCage.Host.Kernel.run_creation_closed_program
#print axioms LeanCage.Host.Kernel.run_creation_closed_program
#check LeanCage.Host.Kernel.run_cleanup_closed_program
#print axioms LeanCage.Host.Kernel.run_cleanup_closed_program
#check LeanCage.Host.Kernel.image_closed_program
#print axioms LeanCage.Host.Kernel.image_closed_program
#check LeanCage.Host.Kernel.publisher_closed_program
#print axioms LeanCage.Host.Kernel.publisher_closed_program
#check LeanCage.Host.Kernel.cleanup_closed_open
#print axioms LeanCage.Host.Kernel.cleanup_closed_open
#check LeanCage.Host.Kernel.validator_mutation_closed_open
#print axioms LeanCage.Host.Kernel.validator_mutation_closed_open
#check LeanCage.Host.Kernel.run_mutation_closed_open
#print axioms LeanCage.Host.Kernel.run_mutation_closed_open
#check LeanCage.Host.Kernel.entrypoint_closed_open
#print axioms LeanCage.Host.Kernel.entrypoint_closed_open
#check LeanCage.Host.Kernel.selected_actor_closed_open
#print axioms LeanCage.Host.Kernel.selected_actor_closed_open
#check LeanCage.Host.Kernel.seal_descriptors_covered
#print axioms LeanCage.Host.Kernel.seal_descriptors_covered
#check LeanCage.Host.Kernel.actual_startup_raw_closed
#print axioms LeanCage.Host.Kernel.actual_startup_raw_closed
#check LeanCage.Host.Kernel.operation_flags_covered
#print axioms LeanCage.Host.Kernel.operation_flags_covered
#check LeanCage.Host.Kernel.recorded_closed_effect
#print axioms LeanCage.Host.Kernel.recorded_closed_effect
#check LeanCage.Host.Kernel.recorded_raw_closed
#print axioms LeanCage.Host.Kernel.recorded_raw_closed
#check LeanCage.Host.Kernel.actor_history_raw
#print axioms LeanCage.Host.Kernel.actor_history_raw
#check LeanCage.Host.Kernel.actual_selected_spawn_raw_closed
#print axioms LeanCage.Host.Kernel.actual_selected_spawn_raw_closed
#check LeanCage.Host.Kernel.actual_actor_handoff
#print axioms LeanCage.Host.Kernel.actual_actor_handoff
#check LeanCage.Host.Kernel.handoff_engine_present
#print axioms LeanCage.Host.Kernel.handoff_engine_present
#check LeanCage.Host.Kernel.selected_event_alive
#print axioms LeanCage.Host.Kernel.selected_event_alive
#check LeanCage.Host.Kernel.actual_selected_actor_history
#print axioms LeanCage.Host.Kernel.actual_selected_actor_history
#check LeanCage.Host.Kernel.actual_source_spawn_raw_closed
#print axioms LeanCage.Host.Kernel.actual_source_spawn_raw_closed
#print LeanCage.Host.Kernel.EngineChannels
#print axioms LeanCage.Host.Kernel.EngineChannels
#print LeanCage.Host.Kernel.InitialEngineBinding
#print axioms LeanCage.Host.Kernel.InitialEngineBinding
#print LeanCage.Host.Kernel.rawObjects
#print axioms LeanCage.Host.Kernel.rawObjects
#print LeanCage.Host.Kernel.rawCloseExec
#print axioms LeanCage.Host.Kernel.rawCloseExec
#print LeanCage.Host.Kernel.NewChildCall
#print axioms LeanCage.Host.Kernel.NewChildCall
#print LeanCage.Host.Kernel.FreshChildCall
#print axioms LeanCage.Host.Kernel.FreshChildCall
#print LeanCage.Host.Kernel.RunChildCall
#print axioms LeanCage.Host.Kernel.RunChildCall
#print LeanCage.Host.Kernel.SameAuthority
#print axioms LeanCage.Host.Kernel.SameAuthority
#print LeanCage.Host.Kernel.AuthorityRetained
#print axioms LeanCage.Host.Kernel.AuthorityRetained
#print LeanCage.Host.Kernel.CanChangeAuthority
#print axioms LeanCage.Host.Kernel.CanChangeAuthority
#print LeanCage.Host.Kernel.AccountContract
#print axioms LeanCage.Host.Kernel.AccountContract
#print LeanCage.Host.Kernel.ForeignAuthorityContract
#print axioms LeanCage.Host.Kernel.ForeignAuthorityContract
#print LeanCage.Host.Kernel.RuntimeAuthorityContract
#print axioms LeanCage.Host.Kernel.RuntimeAuthorityContract
#print LeanCage.Host.Kernel.RootAuthorityAt
#print axioms LeanCage.Host.Kernel.RootAuthorityAt
#print LeanCage.Host.Kernel.RootAuthorities
#print axioms LeanCage.Host.Kernel.RootAuthorities
#print LeanCage.Host.Kernel.ClosedOpenRequest
#print axioms LeanCage.Host.Kernel.ClosedOpenRequest
#print LeanCage.Host.Kernel.CloseExecContract
#print axioms LeanCage.Host.Kernel.CloseExecContract
#print LeanCage.Host.Kernel.RuntimeCloseExecContract
#print axioms LeanCage.Host.Kernel.RuntimeCloseExecContract
#print LeanCage.Host.Kernel.FlagsCovered
#print axioms LeanCage.Host.Kernel.FlagsCovered
#print LeanCage.Host.Kernel.RawClosedOnExec
#print axioms LeanCage.Host.Kernel.RawClosedOnExec
#print LeanCage.Host.Kernel.ClosedEffect
#print axioms LeanCage.Host.Kernel.ClosedEffect
#print LeanCage.Host.Kernel.HandoffCut
#print axioms LeanCage.Host.Kernel.HandoffCut
#print LeanCage.Host.Kernel.NativeChannelProducer
#print axioms LeanCage.Host.Kernel.NativeChannelProducer
#print LeanCage.Host.Kernel.SelectedActorHistory
#print axioms LeanCage.Host.Kernel.SelectedActorHistory
#print LeanCage.Host.Kernel.CanSearch
#print axioms LeanCage.Host.Kernel.CanSearch
#print LeanCage.Host.Kernel.CanWrite
#print axioms LeanCage.Host.Kernel.CanWrite
#print LeanCage.Host.Kernel.NamespacePassive
#print axioms LeanCage.Host.Kernel.NamespacePassive
#print LeanCage.Host.Kernel.AbsoluteLookupContract
#print axioms LeanCage.Host.Kernel.AbsoluteLookupContract
#print LeanCage.Host.VirtualMachine.NamespacePassiveRequest
#print axioms LeanCage.Host.VirtualMachine.NamespacePassiveRequest
#print LeanCage.Host.VirtualMachine.BoundedEffect
#print axioms LeanCage.Host.VirtualMachine.BoundedEffect
