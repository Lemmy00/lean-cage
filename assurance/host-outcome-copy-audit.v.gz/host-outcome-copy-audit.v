(* Append-only private-dictionary-copy interface amendment. *)
From HostGateway Require Import GatewayObjects GatewayReferenceParserComplete GatewayReferenceParserPool GatewayOwnedOutcome.
Set Printing All.
Set Printing Depth 1000000.
Set Printing Width 1000000.
Check @gateway_request_dictionary_copy.
Print gateway_request_dictionary_copy.
Print Assumptions gateway_request_dictionary_copy.
Check @gateway_reference_actual_parser_complete.
Print Assumptions gateway_reference_actual_parser_complete.
Check @gateway_reference_actual_parser_with_reservations.
Print Assumptions gateway_reference_actual_parser_with_reservations.
Check @gateway_actual_owned_outcome.
Print Assumptions gateway_actual_owned_outcome.
