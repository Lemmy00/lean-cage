From HostGateway Require Import GatewayPairCopyout GatewayExchangePairOrigins GatewayExchangeOriginSetup GatewayExchangeOriginPrepared GatewayChannelPairSlices GatewayChannelExecSource GatewayExchangeChannelSources.
Set Printing All.
Set Printing Depth 1000000.
Set Printing Width 120.
Redirect "origin-000-type" Check @GatewayPairCopyout.gateway_copyout_pair_birth.
Redirect "origin-000-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_birth.
Redirect "origin-001-type" Check @GatewayPairCopyout.gateway_copyout_pair_forget.
Redirect "origin-001-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_forget.
Redirect "origin-002-type" Check @GatewayPairCopyout.actual_exchange_pair_copyout.
Redirect "origin-002-axioms" Print Assumptions GatewayPairCopyout.actual_exchange_pair_copyout.
Redirect "origin-003-type" Check @GatewayPairCopyout.gateway_copyout_pair_slice.
Redirect "origin-003-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_slice.
Redirect "origin-004-type" Check @GatewayPairCopyout.gateway_copyout_pair_slice_positioned.
Redirect "origin-004-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_slice_positioned.
Redirect "origin-005-type" Check @GatewayPairCopyout.gateway_copyout_pairs_slice_ordered.
Redirect "origin-005-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pairs_slice_ordered.
Redirect "origin-006-type" Check @GatewayPairCopyout.gateway_copyout_pair_slice_append.
Redirect "origin-006-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_slice_append.
Redirect "origin-007-type" Check @GatewayPairCopyout.gateway_copyout_pairs_slice_ordered_append.
Redirect "origin-007-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pairs_slice_ordered_append.
Redirect "origin-008-type" Check @GatewayPairCopyout.gateway_copyout_pair_slice_prepend.
Redirect "origin-008-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pair_slice_prepend.
Redirect "origin-009-type" Check @GatewayPairCopyout.gateway_copyout_pairs_slice_ordered_prepend.
Redirect "origin-009-axioms" Print Assumptions GatewayPairCopyout.gateway_copyout_pairs_slice_ordered_prepend.
Redirect "origin-010-type" Check @GatewayExchangePairOrigins.PairOriginFirst.actual_exchange_data_pair_before_control.
Redirect "origin-010-axioms" Print Assumptions GatewayExchangePairOrigins.PairOriginFirst.actual_exchange_data_pair_before_control.
Redirect "origin-011-type" Check @GatewayExchangePairOrigins.PairOriginRetention.actual_exchange_second_pair_preserves_first_separate.
Redirect "origin-011-axioms" Print Assumptions GatewayExchangePairOrigins.PairOriginRetention.actual_exchange_second_pair_preserves_first_separate.
Redirect "origin-012-type" Check @GatewayExchangePairOrigins.PairOriginControl.actual_exchange_control_pair_before_flags_separate.
Redirect "origin-012-axioms" Print Assumptions GatewayExchangePairOrigins.PairOriginControl.actual_exchange_control_pair_before_flags_separate.
Redirect "origin-013-type" Check @GatewayExchangePairOrigins.PairOriginConnections.actual_exchange_connections_before_flags_distinct.
Redirect "origin-013-axioms" Print Assumptions GatewayExchangePairOrigins.PairOriginConnections.actual_exchange_connections_before_flags_distinct.
Redirect "origin-014-type" Check @GatewayExchangeOriginSetup.PairOriginBuilders.actual_exchange_empty_sdk_before_initializers_distinct.
Redirect "origin-014-axioms" Print Assumptions GatewayExchangeOriginSetup.PairOriginBuilders.actual_exchange_empty_sdk_before_initializers_distinct.
Redirect "origin-015-type" Check @GatewayExchangeOriginSetup.PairOriginLaunch.actual_exchange_source_launch_distinct.
Redirect "origin-015-axioms" Print Assumptions GatewayExchangeOriginSetup.PairOriginLaunch.actual_exchange_source_launch_distinct.
Redirect "origin-016-type" Check @GatewayExchangeOriginSetup.PairOriginPrepared.gateway_exchange_spawn_frontier.
Redirect "origin-016-axioms" Print Assumptions GatewayExchangeOriginSetup.PairOriginPrepared.gateway_exchange_spawn_frontier.
Redirect "origin-017-type" Check @GatewayExchangeOriginSetup.PairOriginEntry.gateway_exchange_entry_frontier.
Redirect "origin-017-axioms" Print Assumptions GatewayExchangeOriginSetup.PairOriginEntry.gateway_exchange_entry_frontier.
Redirect "origin-018-type" Check @GatewayExchangeOriginSetup.PairOriginEntry.actual_exchange_allocated_entry_spawn.
Redirect "origin-018-axioms" Print Assumptions GatewayExchangeOriginSetup.PairOriginEntry.actual_exchange_allocated_entry_spawn.
Redirect "origin-019-type" Check @GatewayExchangeOriginPrepared.actual_exchange_entry_pair_origins.
Redirect "origin-019-axioms" Print Assumptions GatewayExchangeOriginPrepared.actual_exchange_entry_pair_origins.
Redirect "origin-020-type" Check @GatewayChannelPairSlices.gateway_pair_slice_native_use.
Redirect "origin-020-axioms" Print Assumptions GatewayChannelPairSlices.gateway_pair_slice_native_use.
Redirect "origin-021-type" Check @GatewayChannelPairSlices.gateway_ordered_pair_slices_native_uses.
Redirect "origin-021-axioms" Print Assumptions GatewayChannelPairSlices.gateway_ordered_pair_slices_native_uses.
Redirect "origin-022-type" Check @GatewayChannelExecSource.gateway_native_channels_checked.
Redirect "origin-022-axioms" Print Assumptions GatewayChannelExecSource.gateway_native_channels_checked.
Redirect "origin-023-type" Check @GatewayChannelExecSource.gateway_actual_source_pair_exec_channels.
Redirect "origin-023-axioms" Print Assumptions GatewayChannelExecSource.gateway_actual_source_pair_exec_channels.
Redirect "origin-024-type" Check @GatewayExchangeChannelSources.actual_exchange_entry_channel_sources.
Redirect "origin-024-axioms" Print Assumptions GatewayExchangeChannelSources.actual_exchange_entry_channel_sources.
Redirect "origin-interface-00" Print GatewayPairCopyout.gateway_copyout_pair_birth.
Redirect "origin-interface-01" Print GatewayPairCopyout.gateway_copyout_pair_slice.
Redirect "origin-interface-02" Print GatewayPairCopyout.gateway_copyout_pairs_slice_ordered.
Redirect "origin-interface-03" Print GatewayExchangeOriginSetup.PairOriginPrepared.gateway_exchange_spawn_frontier.
Redirect "origin-interface-04" Print GatewayExchangeOriginSetup.PairOriginEntry.gateway_exchange_entry_frontier.
Redirect "origin-interface-05" Print GatewayChannelExecSource.gateway_native_channels_checked.
Redirect "origin-body-00" Print GatewayExchangeOriginPrepared.actual_exchange_entry_pair_origins.
Redirect "origin-body-01" Print GatewayExchangeChannelSources.actual_exchange_entry_channel_sources.
Redirect "origin-body-02" Print GatewayChannelPairSlices.gateway_ordered_pair_slices_native_uses.
Redirect "origin-body-03" Print GatewayChannelExecSource.gateway_actual_source_pair_exec_channels.
