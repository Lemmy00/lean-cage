import FilesystemNamespaces
import FilesystemMetadata
import FilesystemRootAuthority
import FilesystemMarkers
import FilesystemChildEffects
import FilesystemAuthoritySources
import FilesystemGlobalAuthority
import FilesystemPublicationBorrowing
import FilesystemActorBorrowing
import FilesystemVirtualMachineBorrowing
import FilesystemAuthenticity
import ControllerChildEffects
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.fresh_directory_lookup
#print axioms LeanCage.Host.Kernel.fresh_directory_lookup
#check LeanCage.Host.Kernel.untouched_entry
#print axioms LeanCage.Host.Kernel.untouched_entry
#check LeanCage.Host.Kernel.same_authority_trans
#print axioms LeanCage.Host.Kernel.same_authority_trans
#check LeanCage.Host.Kernel.same_authority_regular
#print axioms LeanCage.Host.Kernel.same_authority_regular
#check LeanCage.Host.Kernel.same_authority_directory
#print axioms LeanCage.Host.Kernel.same_authority_directory
#check LeanCage.Host.Kernel.same_authority_mask
#print axioms LeanCage.Host.Kernel.same_authority_mask
#check LeanCage.Host.Kernel.same_authority_trusted
#print axioms LeanCage.Host.Kernel.same_authority_trusted
#check LeanCage.Host.Kernel.operation_keeps_authority
#print axioms LeanCage.Host.Kernel.operation_keeps_authority
#check LeanCage.Host.Kernel.foreign_host_authority_retained
#print axioms LeanCage.Host.Kernel.foreign_host_authority_retained
#check LeanCage.Host.Kernel.foreign_unowned_authority_retained
#print axioms LeanCage.Host.Kernel.foreign_unowned_authority_retained
#check LeanCage.Host.Kernel.masked_no_search
#print axioms LeanCage.Host.Kernel.masked_no_search
#check LeanCage.Host.Kernel.masked_no_write
#print axioms LeanCage.Host.Kernel.masked_no_write
#check LeanCage.Host.Kernel.fresh_mkdir_foreign_denied
#print axioms LeanCage.Host.Kernel.fresh_mkdir_foreign_denied
#check LeanCage.Host.Kernel.actual_private_mkdir_birth
#print axioms LeanCage.Host.Kernel.actual_private_mkdir_birth
#check LeanCage.Host.Kernel.root_authority_after
#print axioms LeanCage.Host.Kernel.root_authority_after
#check LeanCage.Host.Kernel.foreign_root_authority_after
#print axioms LeanCage.Host.Kernel.foreign_root_authority_after
#check LeanCage.Host.Kernel.ordinary_foreign_preserves_root
#print axioms LeanCage.Host.Kernel.ordinary_foreign_preserves_root
#check LeanCage.Host.Kernel.ordinary_foreign_root_authorities
#print axioms LeanCage.Host.Kernel.ordinary_foreign_root_authorities
#check LeanCage.Host.Kernel.register_actual_root_authority
#print axioms LeanCage.Host.Kernel.register_actual_root_authority
#check LeanCage.Host.Kernel.syscall_keeps_marker
#print axioms LeanCage.Host.Kernel.syscall_keeps_marker
#check LeanCage.Host.Kernel.accepted_public_tick_excludes_marker
#print axioms LeanCage.Host.Kernel.accepted_public_tick_excludes_marker
#check LeanCage.Host.Kernel.guarded_copy_excludes_object
#print axioms LeanCage.Host.Kernel.guarded_copy_excludes_object
#check LeanCage.Host.Kernel.ExternalStep.process
#print axioms LeanCage.Host.Kernel.ExternalStep.process
#check LeanCage.Host.Kernel.external_journal_processes
#print axioms LeanCage.Host.Kernel.external_journal_processes
#check LeanCage.Host.Kernel.selected_external_cut
#print axioms LeanCage.Host.Kernel.selected_external_cut
#check LeanCage.Host.Kernel.actual_foreign_source
#print axioms LeanCage.Host.Kernel.actual_foreign_source
#check LeanCage.Host.Kernel.owned_child_kernel_step
#print axioms LeanCage.Host.Kernel.owned_child_kernel_step
#check LeanCage.Host.Kernel.passive_authority_safe
#print axioms LeanCage.Host.Kernel.passive_authority_safe
#check LeanCage.Host.Kernel.publication_authority_safe
#print axioms LeanCage.Host.Kernel.publication_authority_safe
#check LeanCage.Host.Kernel.publication_authority_program
#print axioms LeanCage.Host.Kernel.publication_authority_program
#check LeanCage.Host.Kernel.run_creation_authority_program
#print axioms LeanCage.Host.Kernel.run_creation_authority_program
#check LeanCage.Host.Kernel.run_cleanup_authority_program
#print axioms LeanCage.Host.Kernel.run_cleanup_authority_program
#check LeanCage.Host.Kernel.safe_authority_program
#print axioms LeanCage.Host.Kernel.safe_authority_program
#check LeanCage.Host.Kernel.image_authority_program
#print axioms LeanCage.Host.Kernel.image_authority_program
#check LeanCage.Host.Kernel.cleanup_authority_safe
#print axioms LeanCage.Host.Kernel.cleanup_authority_safe
#check LeanCage.Host.Kernel.validator_authority_safe
#print axioms LeanCage.Host.Kernel.validator_authority_safe
#check LeanCage.Host.Kernel.run_authority_safe
#print axioms LeanCage.Host.Kernel.run_authority_safe
#check LeanCage.Host.Kernel.entrypoint_authority_safe
#print axioms LeanCage.Host.Kernel.entrypoint_authority_safe
#check LeanCage.Host.Kernel.selected_authority_safe
#print axioms LeanCage.Host.Kernel.selected_authority_safe
#check LeanCage.Host.Kernel.tracked_attribute_is_not_acl
#print axioms LeanCage.Host.Kernel.tracked_attribute_is_not_acl
#check LeanCage.Host.Kernel.actual_no_acl_setter
#print axioms LeanCage.Host.Kernel.actual_no_acl_setter
#check LeanCage.Host.Kernel.external_step_authority
#print axioms LeanCage.Host.Kernel.external_step_authority
#check LeanCage.Host.Kernel.external_journal_authority
#print axioms LeanCage.Host.Kernel.external_journal_authority
#check LeanCage.Host.Kernel.selected_action_authority_safe
#print axioms LeanCage.Host.Kernel.selected_action_authority_safe
#check LeanCage.Host.Kernel.actual_external_authority_journal
#print axioms LeanCage.Host.Kernel.actual_external_authority_journal
#check LeanCage.Host.Kernel.writeLoop_borrow
#print axioms LeanCage.Host.Kernel.writeLoop_borrow
#check LeanCage.Host.Kernel.writeNew_borrow
#print axioms LeanCage.Host.Kernel.writeNew_borrow
#check LeanCage.Host.Kernel.directoryEnsure_borrow
#print axioms LeanCage.Host.Kernel.directoryEnsure_borrow
#check LeanCage.Host.Kernel.publication_under_borrow
#print axioms LeanCage.Host.Kernel.publication_under_borrow
#check LeanCage.Host.Kernel.publication_write_relative_borrow
#print axioms LeanCage.Host.Kernel.publication_write_relative_borrow
#check LeanCage.Host.Kernel.borrow_forIn
#print axioms LeanCage.Host.Kernel.borrow_forIn
#check LeanCage.Host.Kernel.publication_directories_borrow
#print axioms LeanCage.Host.Kernel.publication_directories_borrow
#check LeanCage.Host.Kernel.publication_exports_borrow
#print axioms LeanCage.Host.Kernel.publication_exports_borrow
#check LeanCage.Host.Kernel.publication_fill_borrow
#print axioms LeanCage.Host.Kernel.publication_fill_borrow
#check LeanCage.Host.Kernel.authentication_key_borrow
#print axioms LeanCage.Host.Kernel.authentication_key_borrow
#check LeanCage.Host.Kernel.authentication_borrow
#print axioms LeanCage.Host.Kernel.authentication_borrow
#check LeanCage.Host.Kernel.publication_prepare_borrow
#print axioms LeanCage.Host.Kernel.publication_prepare_borrow
#check LeanCage.Host.Kernel.actual_prepare_retains_stage
#print axioms LeanCage.Host.Kernel.actual_prepare_retains_stage
#check LeanCage.Host.Kernel.actor_borrow_physical_prefix
#print axioms LeanCage.Host.Kernel.actor_borrow_physical_prefix
#check LeanCage.Host.Kernel.actor_borrow_returns
#print axioms LeanCage.Host.Kernel.actor_borrow_returns
#check LeanCage.Host.Kernel.actor_prefix_from_history
#print axioms LeanCage.Host.Kernel.actor_prefix_from_history
#check LeanCage.Host.Kernel.vm_prefix_retains_reference
#print axioms LeanCage.Host.Kernel.vm_prefix_retains_reference
#check LeanCage.Host.Kernel.vm_return_retains_reference
#print axioms LeanCage.Host.Kernel.vm_return_retains_reference
#check LeanCage.Host.Kernel.observed_marker_tag
#print axioms LeanCage.Host.Kernel.observed_marker_tag
#check LeanCage.Host.Kernel.actual_marker_source_query
#print axioms LeanCage.Host.Kernel.actual_marker_source_query
#check LeanCage.Host.Kernel.accepted_nonquery_is_forgery
#print axioms LeanCage.Host.Kernel.accepted_nonquery_is_forgery
#check LeanCage.Host.Kernel.actual_verification_origin_or_forgery
#print axioms LeanCage.Host.Kernel.actual_verification_origin_or_forgery
#check LeanCage.Host.Kernel.accepted_bad_reduces
#print axioms LeanCage.Host.Kernel.accepted_bad_reduces
#check LeanCage.Host.Kernel.bad_sample_count_le
#print axioms LeanCage.Host.Kernel.bad_sample_count_le
#check LeanCage.Host.Kernel.actor_borrow_weaken
#print axioms LeanCage.Host.Kernel.actor_borrow_weaken
#check LeanCage.Host.Kernel.perform_passive_borrow
#print axioms LeanCage.Host.Kernel.perform_passive_borrow
#check LeanCage.Host.Kernel.perform_fresh_borrow
#print axioms LeanCage.Host.Kernel.perform_fresh_borrow
#check LeanCage.Host.Kernel.vm_close_borrow
#print axioms LeanCage.Host.Kernel.vm_close_borrow
#check LeanCage.Host.Kernel.clock_borrow
#print axioms LeanCage.Host.Kernel.clock_borrow
#check LeanCage.Host.Kernel.poll_borrow
#print axioms LeanCage.Host.Kernel.poll_borrow
#check LeanCage.Host.Kernel.runtime_read_borrow
#print axioms LeanCage.Host.Kernel.runtime_read_borrow
#check LeanCage.Host.VirtualMachine.connect_borrow
#print axioms LeanCage.Host.VirtualMachine.connect_borrow
#check LeanCage.Host.VirtualMachine.consume_borrow
#print axioms LeanCage.Host.VirtualMachine.consume_borrow
#check LeanCage.Host.VirtualMachine.consume_ready_borrow
#print axioms LeanCage.Host.VirtualMachine.consume_ready_borrow
#check LeanCage.Host.VirtualMachine.loop_borrow
#print axioms LeanCage.Host.VirtualMachine.loop_borrow
#check LeanCage.Host.VirtualMachine.observe_exit_borrow
#print axioms LeanCage.Host.VirtualMachine.observe_exit_borrow
#check LeanCage.Host.VirtualMachine.reap_borrow
#print axioms LeanCage.Host.VirtualMachine.reap_borrow
#check LeanCage.Host.VirtualMachine.run_borrow
#print axioms LeanCage.Host.VirtualMachine.run_borrow
#check LeanCage.Host.VirtualMachine.loop_borrow_source
#print axioms LeanCage.Host.VirtualMachine.loop_borrow_source
#check LeanCage.Application.ControllerFilesystem.metadata_authority_safe
#print axioms LeanCage.Application.ControllerFilesystem.metadata_authority_safe
#check LeanCage.Application.ControllerFilesystem.actual_controller_authority
#print axioms LeanCage.Application.ControllerFilesystem.actual_controller_authority
#check LeanCage.Application.ControllerFilesystem.backend_authority_from_actual_programs
#print axioms LeanCage.Application.ControllerFilesystem.backend_authority_from_actual_programs
#print LeanCage.Host.Kernel.Handle
#print axioms LeanCage.Host.Kernel.Handle
#print LeanCage.Host.Kernel.Description
#print axioms LeanCage.Host.Kernel.Description
#print LeanCage.Host.Kernel.TrackedAttribute
#print axioms LeanCage.Host.Kernel.TrackedAttribute
#print LeanCage.Host.Kernel.NamespaceContract
#print axioms LeanCage.Host.Kernel.NamespaceContract
#print LeanCage.Host.Kernel.SameAuthority
#print axioms LeanCage.Host.Kernel.SameAuthority
#print LeanCage.Host.Kernel.AuthoritySafeRequest
#print axioms LeanCage.Host.Kernel.AuthoritySafeRequest
#print LeanCage.Host.Kernel.AuthoritySafeEffect
#print axioms LeanCage.Host.Kernel.AuthoritySafeEffect
#print LeanCage.Host.Kernel.AccountContract
#print axioms LeanCage.Host.Kernel.AccountContract
#print LeanCage.Host.Kernel.ForeignAuthorityContract
#print axioms LeanCage.Host.Kernel.ForeignAuthorityContract
#print LeanCage.Host.Kernel.RuntimeAuthorityContract
#print axioms LeanCage.Host.Kernel.RuntimeAuthorityContract
#print LeanCage.Host.Kernel.GloballyHeld
#print axioms LeanCage.Host.Kernel.GloballyHeld
#print LeanCage.Host.Kernel.AuthoritySafeAction
#print axioms LeanCage.Host.Kernel.AuthoritySafeAction
#print LeanCage.Host.Kernel.ChildAuthoritySafe
#print axioms LeanCage.Host.Kernel.ChildAuthoritySafe
#print LeanCage.Host.Kernel.ExternalAuthoritySafe
#print axioms LeanCage.Host.Kernel.ExternalAuthoritySafe
#print LeanCage.Host.Kernel.GlobalAuthorityContract
#print axioms LeanCage.Host.Kernel.GlobalAuthorityContract
#print LeanCage.Host.Kernel.BackendAuthorityProducer
#print axioms LeanCage.Host.Kernel.BackendAuthorityProducer
#print LeanCage.Host.Kernel.ChildOperation
#print axioms LeanCage.Host.Kernel.ChildOperation
#print LeanCage.Host.Kernel.ChildPrimitive
#print axioms LeanCage.Host.Kernel.ChildPrimitive
#print LeanCage.Host.Kernel.ChildCallAt
#print axioms LeanCage.Host.Kernel.ChildCallAt
#print LeanCage.Host.Kernel.ExternalStep
#print axioms LeanCage.Host.Kernel.ExternalStep
#print LeanCage.Host.Kernel.ExternalJournal
#print axioms LeanCage.Host.Kernel.ExternalJournal
#print LeanCage.Host.Kernel.OwnedChildCall
#print axioms LeanCage.Host.Kernel.OwnedChildCall
#print LeanCage.Host.Kernel.ActorBorrowPost
#print axioms LeanCage.Host.Kernel.ActorBorrowPost
#print LeanCage.Host.Kernel.ActorPhysicalPrefix
#print axioms LeanCage.Host.Kernel.ActorPhysicalPrefix
#print LeanCage.Host.Kernel.observedEvent
#print axioms LeanCage.Host.Kernel.observedEvent
#print LeanCage.Host.Kernel.SourceSigningQuery
#print axioms LeanCage.Host.Kernel.SourceSigningQuery
#print LeanCage.Host.Kernel.SourceSigned
#print axioms LeanCage.Host.Kernel.SourceSigned
#print LeanCage.Host.Kernel.MacForgery
#print axioms LeanCage.Host.Kernel.MacForgery
#print LeanCage.Host.Kernel.acceptedBad
#print axioms LeanCage.Host.Kernel.acceptedBad
#print LeanCage.Host.Kernel.observedTag
#print axioms LeanCage.Host.Kernel.observedTag
#print LeanCage.Host.VirtualMachine.ConnectionFresh
#print axioms LeanCage.Host.VirtualMachine.ConnectionFresh
#print LeanCage.Host.VirtualMachine.FreshConnection
#print axioms LeanCage.Host.VirtualMachine.FreshConnection
#print LeanCage.Host.VirtualMachine.afterWait
#print axioms LeanCage.Host.VirtualMachine.afterWait
#print LeanCage.Host.VirtualMachine.loopAfterSend
#print axioms LeanCage.Host.VirtualMachine.loopAfterSend
#print LeanCage.Host.VirtualMachine.loopAfterConnection
#print axioms LeanCage.Host.VirtualMachine.loopAfterConnection
#print LeanCage.Host.VirtualMachine.loopAfterWait
#print axioms LeanCage.Host.VirtualMachine.loopAfterWait
#print LeanCage.Host.VirtualMachine.runAfterState
#print axioms LeanCage.Host.VirtualMachine.runAfterState
#print LeanCage.Application.ControllerFilesystem.metadataRequest
#print axioms LeanCage.Application.ControllerFilesystem.metadataRequest
#print LeanCage.Application.ControllerFilesystem.ControllerRuntimeContract
#print axioms LeanCage.Application.ControllerFilesystem.ControllerRuntimeContract
#print LeanCage.Application.ControllerFilesystem.VmmRuntimeContract
#print axioms LeanCage.Application.ControllerFilesystem.VmmRuntimeContract
#print LeanCage.Application.ControllerFilesystem.ControllerCallSource
#print axioms LeanCage.Application.ControllerFilesystem.ControllerCallSource
