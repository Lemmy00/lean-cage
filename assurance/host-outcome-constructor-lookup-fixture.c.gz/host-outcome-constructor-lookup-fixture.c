#define _GNU_SOURCE
#include <Python.h>
#include <string.h>
typedef struct {
    PyMemAllocatorEx original;
    int failures;
} fail_once;

static void *f_malloc(void *context, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.malloc(state->original.ctx, size);
}
static void *f_calloc(void *context, size_t count, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.calloc(state->original.ctx, count, size);
}
static void *f_realloc(void *context, void *pointer, size_t size) {
    fail_once *state = context;
    if (!state->failures) { state->failures = 1; return NULL; }
    return state->original.realloc(state->original.ctx, pointer, size);
}
static void f_free(void *context, void *pointer) {
    fail_once *state = context;
    state->original.free(state->original.ctx, pointer);
}

static const char *fault_target;
static int fault_seen;
static int fault_injected;
static PyObject *guarded_lookup(PyObject *dictionary, const char *name) {
    if (fault_target && strcmp(name, fault_target) == 0 && ++fault_seen == 2) {
        fail_once state = {0};
        PyMem_GetAllocator(PYMEM_DOMAIN_OBJ, &state.original);
        PyMemAllocatorEx replacement = {&state, f_malloc, f_calloc, f_realloc, f_free};
        PyMem_SetAllocator(PYMEM_DOMAIN_OBJ, &replacement);
        PyObject *result = PyDict_GetItemString(dictionary, name);
        PyMem_SetAllocator(PYMEM_DOMAIN_OBJ, &state.original);
        fault_injected = state.failures;
        return result;
    }
    return PyDict_GetItemString(dictionary, name);
}
#define PyDict_GetItemString guarded_lookup
#include "/localhome/milikic/sandbox-formalization/linux/host_python.c"
#undef PyDict_GetItemString

PyObject *leancage_outcome_lookup_probe(PyObject *data, int field) {
    fault_target = field ? "output" : "files";
    fault_seen = 0;
    fault_injected = 0;
    PyObject *result = host_outcome_from(data);
    fault_target = NULL;
    return result;
}
int leancage_outcome_lookup_was_injected(void) { return fault_injected; }
