import PublicationCustodyProofs
import ValidationReapingProofs
import FilesystemPublicationSource
import FilesystemSpawnSources
import EntrypointExecutableProofs
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.VirtualMachine.read_safe_bind
#print axioms LeanCage.Host.VirtualMachine.read_safe_bind
#check LeanCage.Host.VirtualMachine.read_safe_prefix
#print axioms LeanCage.Host.VirtualMachine.read_safe_prefix
#check LeanCage.Host.VirtualMachine.prefix_of_return_bind
#print axioms LeanCage.Host.VirtualMachine.prefix_of_return_bind
#check LeanCage.Host.VirtualMachine.source_profile_bind
#print axioms LeanCage.Host.VirtualMachine.source_profile_bind
#check LeanCage.Host.VirtualMachine.source_profile_read_safe
#print axioms LeanCage.Host.VirtualMachine.source_profile_read_safe
#check LeanCage.Host.VirtualMachine.perform_profile
#print axioms LeanCage.Host.VirtualMachine.perform_profile
#check LeanCage.Host.VirtualMachine.runtime_read_profile
#print axioms LeanCage.Host.VirtualMachine.runtime_read_profile
#check LeanCage.Host.VirtualMachine.consume_profile
#print axioms LeanCage.Host.VirtualMachine.consume_profile
#check LeanCage.Host.VirtualMachine.runtime_clock_profile
#print axioms LeanCage.Host.VirtualMachine.runtime_clock_profile
#check LeanCage.Host.VirtualMachine.runtime_poll_profile
#print axioms LeanCage.Host.VirtualMachine.runtime_poll_profile
#check LeanCage.Host.VirtualMachine.close_profile
#print axioms LeanCage.Host.VirtualMachine.close_profile
#check LeanCage.Host.VirtualMachine.connect_profile
#print axioms LeanCage.Host.VirtualMachine.connect_profile
#check LeanCage.Host.VirtualMachine.consume_ready_profile
#print axioms LeanCage.Host.VirtualMachine.consume_ready_profile
#check LeanCage.Host.VirtualMachine.after_send_profile
#print axioms LeanCage.Host.VirtualMachine.after_send_profile
#check LeanCage.Host.VirtualMachine.connected_profile
#print axioms LeanCage.Host.VirtualMachine.connected_profile
#check LeanCage.Host.VirtualMachine.loop_profile
#print axioms LeanCage.Host.VirtualMachine.loop_profile
#check LeanCage.Host.VirtualMachine.observe_exit_profile
#print axioms LeanCage.Host.VirtualMachine.observe_exit_profile
#check LeanCage.Host.VirtualMachine.reap_profile
#print axioms LeanCage.Host.VirtualMachine.reap_profile
#check LeanCage.Host.VirtualMachine.final_program_profile
#print axioms LeanCage.Host.VirtualMachine.final_program_profile
#check LeanCage.Host.VirtualMachine.run_profile
#print axioms LeanCage.Host.VirtualMachine.run_profile
#check LeanCage.Host.VirtualMachine.perform_read_safe
#print axioms LeanCage.Host.VirtualMachine.perform_read_safe
#check LeanCage.Host.VirtualMachine.runtime_read_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_read_safe
#check LeanCage.Host.VirtualMachine.consume_read_safe
#print axioms LeanCage.Host.VirtualMachine.consume_read_safe
#check LeanCage.Host.VirtualMachine.runtime_clock_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_clock_safe
#check LeanCage.Host.VirtualMachine.runtime_poll_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_poll_safe
#check LeanCage.Host.VirtualMachine.close_read_safe
#print axioms LeanCage.Host.VirtualMachine.close_read_safe
#check LeanCage.Host.VirtualMachine.connect_read_safe
#print axioms LeanCage.Host.VirtualMachine.connect_read_safe
#check LeanCage.Host.VirtualMachine.consume_ready_read_safe
#print axioms LeanCage.Host.VirtualMachine.consume_ready_read_safe
#check LeanCage.Host.VirtualMachine.after_send_read_safe
#print axioms LeanCage.Host.VirtualMachine.after_send_read_safe
#check LeanCage.Host.VirtualMachine.connected_read_safe
#print axioms LeanCage.Host.VirtualMachine.connected_read_safe
#check LeanCage.Host.VirtualMachine.loop_read_safe
#print axioms LeanCage.Host.VirtualMachine.loop_read_safe
#check LeanCage.Host.VirtualMachine.observe_exit_read_safe
#print axioms LeanCage.Host.VirtualMachine.observe_exit_read_safe
#check LeanCage.Host.VirtualMachine.reap_read_safe
#print axioms LeanCage.Host.VirtualMachine.reap_read_safe
#check LeanCage.Host.VirtualMachine.final_program_read_safe
#print axioms LeanCage.Host.VirtualMachine.final_program_read_safe
#check LeanCage.Host.VirtualMachine.run_read_safe
#print axioms LeanCage.Host.VirtualMachine.run_read_safe
#check LeanCage.Host.VirtualMachine.actual_prefix_read_bounds
#print axioms LeanCage.Host.VirtualMachine.actual_prefix_read_bounds
#check LeanCage.Host.VirtualMachine.source_profile_prefix
#print axioms LeanCage.Host.VirtualMachine.source_profile_prefix
#check LeanCage.Host.VirtualMachine.actual_prefix_spawn_arguments
#print axioms LeanCage.Host.VirtualMachine.actual_prefix_spawn_arguments
#check LeanCage.Host.VirtualMachine.lost_read_not_observation
#print axioms LeanCage.Host.VirtualMachine.lost_read_not_observation
#check LeanCage.Host.Validation.result_reaped_exact
#print axioms LeanCage.Host.Validation.result_reaped_exact
#check LeanCage.Host.Validation.observe_reaped_source
#print axioms LeanCage.Host.Validation.observe_reaped_source
#check LeanCage.Host.Validation.release_requests
#print axioms LeanCage.Host.Validation.release_requests
#check LeanCage.Host.Validation.unknown_finish_prefix
#print axioms LeanCage.Host.Validation.unknown_finish_prefix
#check LeanCage.Host.Validation.rejected_status_reaped
#print axioms LeanCage.Host.Validation.rejected_status_reaped
#check LeanCage.Host.Validation.unknown_wait_not_reaped
#print axioms LeanCage.Host.Validation.unknown_wait_not_reaped
#check LeanCage.Host.Validation.failed_spawn_not_reaped
#print axioms LeanCage.Host.Validation.failed_spawn_not_reaped
#check LeanCage.Host.Publication.closeOwned_requests
#print axioms LeanCage.Host.Publication.closeOwned_requests
#check LeanCage.Host.Publication.finishCommit_requests
#print axioms LeanCage.Host.Publication.finishCommit_requests
#check LeanCage.Host.Publication.finishCommit_release_prefix
#print axioms LeanCage.Host.Publication.finishCommit_release_prefix
#check LeanCage.Host.Publication.native_error_release_exists
#print axioms LeanCage.Host.Publication.native_error_release_exists
#check LeanCage.Host.Publication.lost_rename_prefix
#print axioms LeanCage.Host.Publication.lost_rename_prefix
#check LeanCage.Host.Publication.finishCommit_readOnly
#print axioms LeanCage.Host.Publication.finishCommit_readOnly
#check LeanCage.Host.Publication.finishCommit_no_rollback
#print axioms LeanCage.Host.Publication.finishCommit_no_rollback
#check LeanCage.Host.Publication.attempt_source
#print axioms LeanCage.Host.Publication.attempt_source
#check LeanCage.Host.Kernel.selected_publisher_commit
#print axioms LeanCage.Host.Kernel.selected_publisher_commit
#check LeanCage.Host.Kernel.selected_spawn_source
#print axioms LeanCage.Host.Kernel.selected_spawn_source
#check LeanCage.Host.Entrypoint.main_source
#print axioms LeanCage.Host.Entrypoint.main_source
#print LeanCage.Host.Validation.ChildObservation
#print axioms LeanCage.Host.Validation.ChildObservation
#print LeanCage.Host.Validation.validationResult
#print axioms LeanCage.Host.Validation.validationResult
#print LeanCage.Host.Validation.observeChild
#print axioms LeanCage.Host.Validation.observeChild
#print LeanCage.Host.Validation.releaseDirectory
#print axioms LeanCage.Host.Validation.releaseDirectory
#print LeanCage.Host.Validation.finishValidation
#print axioms LeanCage.Host.Validation.finishValidation
#print LeanCage.Host.Validation.validateCopied
#print axioms LeanCage.Host.Validation.validateCopied
#print LeanCage.Host.Publication.closeOwned
#print axioms LeanCage.Host.Publication.closeOwned
#print LeanCage.Host.Publication.finishCommit
#print axioms LeanCage.Host.Publication.finishCommit
#print LeanCage.Host.Publication.attempt
#print axioms LeanCage.Host.Publication.attempt
#print LeanCage.Host.Publication.ReleaseRequest
#print axioms LeanCage.Host.Publication.ReleaseRequest
#print LeanCage.Host.VirtualMachine.NamespacePassiveRequest
#print axioms LeanCage.Host.VirtualMachine.NamespacePassiveRequest
#print LeanCage.Host.VirtualMachine.BoundedEffect
#print axioms LeanCage.Host.VirtualMachine.BoundedEffect
#print LeanCage.Host.VirtualMachine.ProfileEffect
#print axioms LeanCage.Host.VirtualMachine.ProfileEffect
#print LeanCage.Host.VirtualMachine.SourceProfile
#print axioms LeanCage.Host.VirtualMachine.SourceProfile
