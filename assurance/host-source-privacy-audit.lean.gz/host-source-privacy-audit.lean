import PublicationMarkerProofs
import FilesystemMarkerSources
import FilesystemCryptography
import FilesystemReadSources
import FilesystemBackend
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Publication.namespace_no_attribute
#print axioms LeanCage.Host.Publication.namespace_no_attribute
#check LeanCage.Host.Publication.readOnly_no_attribute
#print axioms LeanCage.Host.Publication.readOnly_no_attribute
#check LeanCage.Host.Publication.writeLoop_no_attribute
#print axioms LeanCage.Host.Publication.writeLoop_no_attribute
#check LeanCage.Host.Publication.writeNew_no_attribute
#print axioms LeanCage.Host.Publication.writeNew_no_attribute
#check LeanCage.Host.Publication.ensureAt_no_attribute
#print axioms LeanCage.Host.Publication.ensureAt_no_attribute
#check LeanCage.Host.Publication.publicAt_no_attribute
#print axioms LeanCage.Host.Publication.publicAt_no_attribute
#check LeanCage.Host.Publication.descend_no_attribute
#print axioms LeanCage.Host.Publication.descend_no_attribute
#check LeanCage.Host.Publication.parent_no_attribute
#print axioms LeanCage.Host.Publication.parent_no_attribute
#check LeanCage.Host.Publication.fresh_no_attribute
#print axioms LeanCage.Host.Publication.fresh_no_attribute
#check LeanCage.Host.Publication.under_no_attribute
#print axioms LeanCage.Host.Publication.under_no_attribute
#check LeanCage.Host.Publication.writeRelative_no_attribute
#print axioms LeanCage.Host.Publication.writeRelative_no_attribute
#check LeanCage.Host.Publication.directories_no_attribute
#print axioms LeanCage.Host.Publication.directories_no_attribute
#check LeanCage.Host.Publication.exports_no_attribute
#print axioms LeanCage.Host.Publication.exports_no_attribute
#check LeanCage.Host.Publication.fill_no_attribute
#print axioms LeanCage.Host.Publication.fill_no_attribute
#check LeanCage.Host.Publication.unlinkRelative_no_attribute
#print axioms LeanCage.Host.Publication.unlinkRelative_no_attribute
#check LeanCage.Host.Publication.cleanup_no_attribute
#print axioms LeanCage.Host.Publication.cleanup_no_attribute
#check LeanCage.Host.Publication.prepare_marker_call
#print axioms LeanCage.Host.Publication.prepare_marker_call
#check LeanCage.Host.Publication.attempt_marker_call
#print axioms LeanCage.Host.Publication.attempt_marker_call
#check LeanCage.Host.Publication.publish_marker_call
#print axioms LeanCage.Host.Publication.publish_marker_call
#check LeanCage.Host.Kernel.no_attribute_no_marker
#print axioms LeanCage.Host.Kernel.no_attribute_no_marker
#check LeanCage.Host.Kernel.run_creation_no_marker
#print axioms LeanCage.Host.Kernel.run_creation_no_marker
#check LeanCage.Host.Kernel.run_cleanup_no_marker
#print axioms LeanCage.Host.Kernel.run_cleanup_no_marker
#check LeanCage.Host.Kernel.image_no_marker
#print axioms LeanCage.Host.Kernel.image_no_marker
#check LeanCage.Host.Kernel.cleanup_no_marker
#print axioms LeanCage.Host.Kernel.cleanup_no_marker
#check LeanCage.Host.Kernel.validator_mutation_no_marker
#print axioms LeanCage.Host.Kernel.validator_mutation_no_marker
#check LeanCage.Host.Kernel.run_marker_publication
#print axioms LeanCage.Host.Kernel.run_marker_publication
#check LeanCage.Host.Kernel.entrypoint_marker_publication
#print axioms LeanCage.Host.Kernel.entrypoint_marker_publication
#check LeanCage.Host.Kernel.entrypoint_marker_call
#print axioms LeanCage.Host.Kernel.entrypoint_marker_call
#check LeanCage.Host.Kernel.selected_publisher_marker
#print axioms LeanCage.Host.Kernel.selected_publisher_marker
#check LeanCage.Host.Kernel.completed_filesystem_events
#print axioms LeanCage.Host.Kernel.completed_filesystem_events
#check LeanCage.Host.Kernel.marker_authentication_trace
#print axioms LeanCage.Host.Kernel.marker_authentication_trace
#check LeanCage.Host.Kernel.recorded_authentication
#print axioms LeanCage.Host.Kernel.recorded_authentication
#check LeanCage.Host.Kernel.actual_recorded_marker_authentication
#print axioms LeanCage.Host.Kernel.actual_recorded_marker_authentication
#check LeanCage.Host.Kernel.recorded_verification
#print axioms LeanCage.Host.Kernel.recorded_verification
#check LeanCage.Host.Kernel.closeResult_noRead
#print axioms LeanCage.Host.Kernel.closeResult_noRead
#check LeanCage.Host.Kernel.publicHandle_noRead
#print axioms LeanCage.Host.Kernel.publicHandle_noRead
#check LeanCage.Host.Kernel.sourceOpenAt_noRead
#print axioms LeanCage.Host.Kernel.sourceOpenAt_noRead
#check LeanCage.Host.Kernel.releaseParent_noRead
#print axioms LeanCage.Host.Kernel.releaseParent_noRead
#check LeanCage.Host.Kernel.sourceWalk_noRead
#print axioms LeanCage.Host.Kernel.sourceWalk_noRead
#check LeanCage.Host.Kernel.sourceAbsolute_noRead
#print axioms LeanCage.Host.Kernel.sourceAbsolute_noRead
#check LeanCage.Host.Kernel.sourceIdentity_noRead
#print axioms LeanCage.Host.Kernel.sourceIdentity_noRead
#check LeanCage.Host.Kernel.sourceAncestry_noRead
#print axioms LeanCage.Host.Kernel.sourceAncestry_noRead
#check LeanCage.Host.Kernel.sourceCheckAncestry_noRead
#print axioms LeanCage.Host.Kernel.sourceCheckAncestry_noRead
#check LeanCage.Host.Kernel.sourceStart_noRead
#print axioms LeanCage.Host.Kernel.sourceStart_noRead
#check LeanCage.Host.Kernel.sourceOpen_noRead
#print axioms LeanCage.Host.Kernel.sourceOpen_noRead
#check LeanCage.Host.Kernel.hash_noRead
#print axioms LeanCage.Host.Kernel.hash_noRead
#check LeanCage.Host.Kernel.identify_noRead
#print axioms LeanCage.Host.Kernel.identify_noRead
#check LeanCage.Host.Kernel.closeDirectory_noRead
#print axioms LeanCage.Host.Kernel.closeDirectory_noRead
#check LeanCage.Host.Kernel.enumerate_noRead
#print axioms LeanCage.Host.Kernel.enumerate_noRead
#check LeanCage.Host.Kernel.source_open_guard_recorded
#print axioms LeanCage.Host.Kernel.source_open_guard_recorded
#check LeanCage.Host.Kernel.empty_recorded_handles
#print axioms LeanCage.Host.Kernel.empty_recorded_handles
#check LeanCage.Host.Kernel.source_start_guard_recorded
#print axioms LeanCage.Host.Kernel.source_start_guard_recorded
#check LeanCage.Host.Kernel.source_walk_guard_recorded
#print axioms LeanCage.Host.Kernel.source_walk_guard_recorded
#check LeanCage.Host.Kernel.source_path_guard_recorded
#print axioms LeanCage.Host.Kernel.source_path_guard_recorded
#check LeanCage.Host.Kernel.prefix_prior_replies
#print axioms LeanCage.Host.Kernel.prefix_prior_replies
#check LeanCage.Host.Kernel.prefix_before_last
#print axioms LeanCage.Host.Kernel.prefix_before_last
#check LeanCage.Host.Kernel.physical_prefix_from_history
#print axioms LeanCage.Host.Kernel.physical_prefix_from_history
#check LeanCage.Host.Kernel.guarded_start_recorded
#print axioms LeanCage.Host.Kernel.guarded_start_recorded
#check LeanCage.Host.Kernel.actual_guarded_copy_read
#print axioms LeanCage.Host.Kernel.actual_guarded_copy_read
#check LeanCage.Host.Kernel.actual_snapshot_guarded_read
#print axioms LeanCage.Host.Kernel.actual_snapshot_guarded_read
#check LeanCage.Host.Kernel.selected_guarded_read_excludes
#print axioms LeanCage.Host.Kernel.selected_guarded_read_excludes
#check LeanCage.Host.Kernel.noRead_sources
#print axioms LeanCage.Host.Kernel.noRead_sources
#check LeanCage.Host.Kernel.read_sources_bind
#print axioms LeanCage.Host.Kernel.read_sources_bind
#check LeanCage.Host.Kernel.traversal_read_sources
#print axioms LeanCage.Host.Kernel.traversal_read_sources
#check LeanCage.Host.Kernel.workspace_read_sources
#print axioms LeanCage.Host.Kernel.workspace_read_sources
#check LeanCage.Host.Kernel.file_read_sources
#print axioms LeanCage.Host.Kernel.file_read_sources
#check LeanCage.Host.Kernel.stdin_read_sources
#print axioms LeanCage.Host.Kernel.stdin_read_sources
#check LeanCage.Host.Kernel.freeze_read_sources
#print axioms LeanCage.Host.Kernel.freeze_read_sources
#check LeanCage.Host.Kernel.guarded_copy_call_descriptor
#print axioms LeanCage.Host.Kernel.guarded_copy_call_descriptor
#check LeanCage.Host.Kernel.process_journal_split
#print axioms LeanCage.Host.Kernel.process_journal_split
#check LeanCage.Host.Kernel.process_journal_owner
#print axioms LeanCage.Host.Kernel.process_journal_owner
#check LeanCage.Host.Kernel.process_journal_arguments
#print axioms LeanCage.Host.Kernel.process_journal_arguments
#check LeanCage.Host.Kernel.process_first_birth
#print axioms LeanCage.Host.Kernel.process_first_birth
#check LeanCage.Host.Kernel.actual_backend_source
#print axioms LeanCage.Host.Kernel.actual_backend_source
#print LeanCage.Host.Publication.NoAttribute
#print axioms LeanCage.Host.Publication.NoAttribute
#print LeanCage.Host.Publication.markerWire
#print axioms LeanCage.Host.Publication.markerWire
#print LeanCage.Host.Publication.PreparedMarkerCall
#print axioms LeanCage.Host.Publication.PreparedMarkerCall
#print LeanCage.Host.Publication.AttemptMarkerCall
#print axioms LeanCage.Host.Publication.AttemptMarkerCall
#print LeanCage.Host.Publication.PublishedMarkerCall
#print axioms LeanCage.Host.Publication.PublishedMarkerCall
#print LeanCage.Host.Kernel.NoPublicationMarker
#print axioms LeanCage.Host.Kernel.NoPublicationMarker
#print LeanCage.Host.Kernel.HostMarkerCall
#print axioms LeanCage.Host.Kernel.HostMarkerCall
#print LeanCage.Host.Kernel.HostMarkerCall.context
#print axioms LeanCage.Host.Kernel.HostMarkerCall.context
#print LeanCage.Host.Kernel.CryptographicContract
#print axioms LeanCage.Host.Kernel.CryptographicContract
#print LeanCage.Host.Kernel.AuthenticationUse
#print axioms LeanCage.Host.Kernel.AuthenticationUse
#print LeanCage.Host.Kernel.RecordedMarkerAuthentication
#print axioms LeanCage.Host.Kernel.RecordedMarkerAuthentication
#print LeanCage.Host.Kernel.VerificationUse
#print axioms LeanCage.Host.Kernel.VerificationUse
#print LeanCage.Host.Kernel.NoRead
#print axioms LeanCage.Host.Kernel.NoRead
#print LeanCage.Host.Kernel.GuardedCopyStart
#print axioms LeanCage.Host.Kernel.GuardedCopyStart
#print LeanCage.Host.Kernel.GuardedCopyStart.events
#print axioms LeanCage.Host.Kernel.GuardedCopyStart.events
#print LeanCage.Host.Kernel.GuardedCopyCall
#print axioms LeanCage.Host.Kernel.GuardedCopyCall
#print LeanCage.Host.Kernel.GuardedCopyCall.prepend
#print axioms LeanCage.Host.Kernel.GuardedCopyCall.prepend
#print LeanCage.Host.Kernel.ReadSources
#print axioms LeanCage.Host.Kernel.ReadSources
#print LeanCage.Host.Kernel.PublicGuard
#print axioms LeanCage.Host.Kernel.PublicGuard
#print LeanCage.Host.Kernel.GuardedHandle
#print axioms LeanCage.Host.Kernel.GuardedHandle
#print LeanCage.Host.Kernel.SelectedGuardedRead
#print axioms LeanCage.Host.Kernel.SelectedGuardedRead
#print LeanCage.Host.Kernel.Processes.empty
#print axioms LeanCage.Host.Kernel.Processes.empty
#print LeanCage.Host.Kernel.ProcessBirthCut
#print axioms LeanCage.Host.Kernel.ProcessBirthCut
#print LeanCage.Host.Kernel.BackendSource
#print axioms LeanCage.Host.Kernel.BackendSource
