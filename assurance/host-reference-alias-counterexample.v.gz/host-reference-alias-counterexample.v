From Stdlib Require Import List.
From compcert Require Import Integers Values Memory.
From HostGateway Require Import GatewayMachine GatewayPython GatewayObjects GatewayRootLeases.
Import ListNotations.

Lemma universal_decref_alias_contradiction {World Event}(backend:gateway_backend World Event)
    python objects decimal_float leases
    (roots:gateway_root_lease_runtime backend python objects decimal_float leases)
    before world first second object returned after next observed :
  python_world_valid(python world)before ->python_gil(python world)=true ->
  first<>second ->leases world first object ->leases world second object ->
  gateway_object_operation backend gateway_api_decref[object]before world returned after next observed ->False.
Proof.
  intros VALID GIL DIFFERENT FIRST SECOND OPERATION.
  pose proof(gateway_decref_lease _ _ _ _ _ roots before world first object returned after next observed VALID GIL FIRST OPERATION)
    as[REMOVED_FIRST RETAINED_SECOND].
  pose proof(gateway_decref_lease _ _ _ _ _ roots before world second object returned after next observed VALID GIL SECOND OPERATION)
    as[REMOVED_SECOND RETAINED_FIRST].
  apply(REMOVED_SECOND object);apply(RETAINED_SECOND second object);[congruence|exact SECOND].
Qed.
Print universal_decref_alias_contradiction.
Print Assumptions universal_decref_alias_contradiction.
