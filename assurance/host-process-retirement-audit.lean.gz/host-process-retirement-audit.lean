import FilesystemRetirement
import FilesystemRetirementProjection
import FilesystemNativeRetirement
import FilesystemRetirementCustody
import FilesystemProjection
import FilesystemReferences
import FilesystemNativeEffects
import FilesystemNativeExecutions
import FilesystemNativeAuthority
import FilesystemAnchorHistory
import FilesystemNamespaceMetadata
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.actor_step_source_for
#print axioms LeanCage.Host.Kernel.actor_step_source_for
#check LeanCage.Host.Kernel.actor_history_source_for
#print axioms LeanCage.Host.Kernel.actor_history_source_for
#check LeanCage.Host.Kernel.actor_step_consistent
#print axioms LeanCage.Host.Kernel.actor_step_consistent
#check LeanCage.Host.Kernel.projection_from_reference_laws
#print axioms LeanCage.Host.Kernel.projection_from_reference_laws
#check LeanCage.Host.Kernel.actor_journal_projection_with
#print axioms LeanCage.Host.Kernel.actor_journal_projection_with
#check LeanCage.Host.Kernel.actor_step_stopped_source
#print axioms LeanCage.Host.Kernel.actor_step_stopped_source
#check LeanCage.Host.Kernel.actor_journal_stopped_source
#print axioms LeanCage.Host.Kernel.actor_journal_stopped_source
#check LeanCage.Host.Kernel.retired_engine_resources_complete
#print axioms LeanCage.Host.Kernel.retired_engine_resources_complete
#check LeanCage.Host.Kernel.NativeRetirementAt.observed
#print axioms LeanCage.Host.Kernel.NativeRetirementAt.observed
#check LeanCage.Host.Kernel.NativeRetirementAt.stopped
#print axioms LeanCage.Host.Kernel.NativeRetirementAt.stopped
#check LeanCage.Host.Kernel.NativeExternalStep.stopped
#print axioms LeanCage.Host.Kernel.NativeExternalStep.stopped
#check LeanCage.Host.Kernel.native_journal_stopped
#print axioms LeanCage.Host.Kernel.native_journal_stopped
#check LeanCage.Host.Kernel.native_stopped_cannot_call
#print axioms LeanCage.Host.Kernel.native_stopped_cannot_call
#check LeanCage.Host.Kernel.native_stopped_cannot_launch
#print axioms LeanCage.Host.Kernel.native_stopped_cannot_launch
#check LeanCage.Host.Kernel.native_retirement_held_before
#print axioms LeanCage.Host.Kernel.native_retirement_held_before
#check LeanCage.Host.Kernel.native_retirement_resources_complete
#print axioms LeanCage.Host.Kernel.native_retirement_resources_complete
#check LeanCage.Host.Kernel.retirement_ownership_prefix
#print axioms LeanCage.Host.Kernel.retirement_ownership_prefix
#check LeanCage.Host.Kernel.engine_retirement_custody_state
#print axioms LeanCage.Host.Kernel.engine_retirement_custody_state
#check LeanCage.Host.Kernel.native_retirement_custody_state
#print axioms LeanCage.Host.Kernel.native_retirement_custody_state
#check LeanCage.Host.Kernel.NativeExternalStep.birth_frame
#print axioms LeanCage.Host.Kernel.NativeExternalStep.birth_frame
#check LeanCage.Host.Kernel.native_execution_source
#print axioms LeanCage.Host.Kernel.native_execution_source
#check LeanCage.Host.Kernel.actor_step_allocated
#print axioms LeanCage.Host.Kernel.actor_step_allocated
#check LeanCage.Host.Kernel.actor_step_raw
#print axioms LeanCage.Host.Kernel.actor_step_raw
#check LeanCage.Host.Kernel.actor_journal_reference_continuity
#print axioms LeanCage.Host.Kernel.actor_journal_reference_continuity
#check LeanCage.Host.Kernel.actor_step_live_backward_for
#print axioms LeanCage.Host.Kernel.actor_step_live_backward_for
#check LeanCage.Host.Kernel.actor_step_live_backward
#print axioms LeanCage.Host.Kernel.actor_step_live_backward
#check LeanCage.Host.Kernel.external_step_live_authority
#print axioms LeanCage.Host.Kernel.external_step_live_authority
#check LeanCage.Host.Kernel.external_step_protected_marker
#print axioms LeanCage.Host.Kernel.external_step_protected_marker
#check LeanCage.Host.Kernel.system_anchor_step
#print axioms LeanCage.Host.Kernel.system_anchor_step
#print LeanCage.Host.Kernel.EngineState
#print axioms LeanCage.Host.Kernel.EngineState
#print LeanCage.Host.Kernel.EngineRetirement
#print axioms LeanCage.Host.Kernel.EngineRetirement
#print LeanCage.Host.Kernel.RetirementResources
#print axioms LeanCage.Host.Kernel.RetirementResources
#print LeanCage.Host.Kernel.EngineState.retired
#print axioms LeanCage.Host.Kernel.EngineState.retired
#print LeanCage.Host.Kernel.ActorRuntime
#print axioms LeanCage.Host.Kernel.ActorRuntime
#print LeanCage.Host.Kernel.ActorAction
#print axioms LeanCage.Host.Kernel.ActorAction
#print LeanCage.Host.Kernel.ActorStep
#print axioms LeanCage.Host.Kernel.ActorStep
#print LeanCage.Host.Kernel.RetirementContract
#print axioms LeanCage.Host.Kernel.RetirementContract
#print LeanCage.Host.Kernel.RuntimeDescriptorContract
#print axioms LeanCage.Host.Kernel.RuntimeDescriptorContract
#print LeanCage.Host.Kernel.ReferenceContract
#print axioms LeanCage.Host.Kernel.ReferenceContract
#print LeanCage.Host.Kernel.LifetimeContract
#print axioms LeanCage.Host.Kernel.LifetimeContract
#print LeanCage.Host.Kernel.NativeProcesses
#print axioms LeanCage.Host.Kernel.NativeProcesses
#print LeanCage.Host.Kernel.NativeProcesses.retire
#print axioms LeanCage.Host.Kernel.NativeProcesses.retire
#print LeanCage.Host.Kernel.NativeRetirementAt
#print axioms LeanCage.Host.Kernel.NativeRetirementAt
#print LeanCage.Host.Kernel.NativeExternalStep
#print axioms LeanCage.Host.Kernel.NativeExternalStep
#print LeanCage.Host.Kernel.RetirementResources.Held
#print axioms LeanCage.Host.Kernel.RetirementResources.Held
#print LeanCage.Host.Kernel.NativeHeld
#print axioms LeanCage.Host.Kernel.NativeHeld
#print LeanCage.Host.Kernel.ActionFamily
#print axioms LeanCage.Host.Kernel.ActionFamily
#print LeanCage.Host.Kernel.GlobalAuthorityContract
#print axioms LeanCage.Host.Kernel.GlobalAuthorityContract
#print LeanCage.Host.Kernel.ObjectLifetimeContract
#print axioms LeanCage.Host.Kernel.ObjectLifetimeContract
#print LeanCage.Host.Kernel.LiveMetadataContract
#print axioms LeanCage.Host.Kernel.LiveMetadataContract
#print LeanCage.Host.Kernel.ExistingAttributeContract
#print axioms LeanCage.Host.Kernel.ExistingAttributeContract
#print LeanCage.Host.Kernel.NamespaceMetadataContract
#print axioms LeanCage.Host.Kernel.NamespaceMetadataContract
#print LeanCage.Host.Kernel.LookupMutationContract
#print axioms LeanCage.Host.Kernel.LookupMutationContract
#print LeanCage.Host.Kernel.AnchorOperationContract
#print axioms LeanCage.Host.Kernel.AnchorOperationContract
