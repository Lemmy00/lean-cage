import FilesystemDirectoryHandles
import FilesystemMarkerBindings
import FilesystemObjectLifetime
import FilesystemLiveMetadata
import FilesystemMarkerLifetime
import FilesystemMarkerGuards
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.directory_observation_returns
#print axioms LeanCage.Host.Kernel.directory_observation_returns
#check LeanCage.Host.Kernel.directory_observation_handle
#print axioms LeanCage.Host.Kernel.directory_observation_handle
#check LeanCage.Host.Kernel.created_observation_handle
#print axioms LeanCage.Host.Kernel.created_observation_handle
#check LeanCage.Host.Kernel.actual_child_handle
#print axioms LeanCage.Host.Kernel.actual_child_handle
#check LeanCage.Host.Kernel.actual_fresh_handles
#print axioms LeanCage.Host.Kernel.actual_fresh_handles
#check LeanCage.Host.Kernel.operation_live_backward
#print axioms LeanCage.Host.Kernel.operation_live_backward
#check LeanCage.Host.Kernel.actor_step_live_backward
#print axioms LeanCage.Host.Kernel.actor_step_live_backward
#check LeanCage.Host.Kernel.actor_journal_live_backward
#print axioms LeanCage.Host.Kernel.actor_journal_live_backward
#check LeanCage.Host.Kernel.actor_journal_live_snapshots
#print axioms LeanCage.Host.Kernel.actor_journal_live_snapshots
#check LeanCage.Host.Kernel.external_step_live_authority
#print axioms LeanCage.Host.Kernel.external_step_live_authority
#check LeanCage.Host.Kernel.external_step_protected_marker
#print axioms LeanCage.Host.Kernel.external_step_protected_marker
#check LeanCage.Host.Kernel.external_journal_protected_marker
#print axioms LeanCage.Host.Kernel.external_journal_protected_marker
#check LeanCage.Host.Kernel.selected_safe_external_cut
#print axioms LeanCage.Host.Kernel.selected_safe_external_cut
#check LeanCage.Host.Kernel.actual_guard_excludes_initial_marker
#print axioms LeanCage.Host.Kernel.actual_guard_excludes_initial_marker
#check LeanCage.Host.Kernel.actual_guarded_read_excludes_initial_marker
#print axioms LeanCage.Host.Kernel.actual_guarded_read_excludes_initial_marker
#check LeanCage.Host.Kernel.actual_snapshot_protected_reference
#print axioms LeanCage.Host.Kernel.actual_snapshot_protected_reference
#check LeanCage.Host.Kernel.entrypoint_private_marker_call
#print axioms LeanCage.Host.Kernel.entrypoint_private_marker_call
#check LeanCage.Host.Kernel.marker_creation_trace
#print axioms LeanCage.Host.Kernel.marker_creation_trace
#check LeanCage.Host.Kernel.selected_publisher_marker_handle
#print axioms LeanCage.Host.Kernel.selected_publisher_marker_handle
#check LeanCage.Host.Kernel.run_after_mark_no_attribute
#print axioms LeanCage.Host.Kernel.run_after_mark_no_attribute
#check LeanCage.Host.Kernel.run_marker_call
#print axioms LeanCage.Host.Kernel.run_marker_call
#check LeanCage.Host.Kernel.selected_private_marker_handle
#print axioms LeanCage.Host.Kernel.selected_private_marker_handle
#check LeanCage.Host.Kernel.selected_attribute_handle
#print axioms LeanCage.Host.Kernel.selected_attribute_handle
#check LeanCage.Host.Kernel.foreign_cannot_remove_private_child
#print axioms LeanCage.Host.Kernel.foreign_cannot_remove_private_child
#check LeanCage.Host.Kernel.foreign_cannot_mutate_private_directory
#print axioms LeanCage.Host.Kernel.foreign_cannot_mutate_private_directory
#check LeanCage.Host.Kernel.foreign_cannot_clear_private_attribute
#print axioms LeanCage.Host.Kernel.foreign_cannot_clear_private_attribute
#print LeanCage.Host.Kernel.ObjectAlive
#print axioms LeanCage.Host.Kernel.ObjectAlive
#print LeanCage.Host.Kernel.ForeignContract
#print axioms LeanCage.Host.Kernel.ForeignContract
#print LeanCage.Host.Kernel.ObjectLifetimeContract
#print axioms LeanCage.Host.Kernel.ObjectLifetimeContract
#print LeanCage.Host.Kernel.LiveMetadataContract
#print axioms LeanCage.Host.Kernel.LiveMetadataContract
#print LeanCage.Host.Kernel.ExistingAttributeContract
#print axioms LeanCage.Host.Kernel.ExistingAttributeContract
#print LeanCage.Host.Kernel.ProtectedMarker
#print axioms LeanCage.Host.Kernel.ProtectedMarker
#print LeanCage.Host.Kernel.SafeExternalCut
#print axioms LeanCage.Host.Kernel.SafeExternalCut
#print LeanCage.Host.Kernel.RunMarkerCall
#print axioms LeanCage.Host.Kernel.RunMarkerCall
#print LeanCage.Host.Kernel.RunCreationPrefix
#print axioms LeanCage.Host.Kernel.RunCreationPrefix
#print LeanCage.Host.Kernel.runAfterMark
#print axioms LeanCage.Host.Kernel.runAfterMark
#print LeanCage.Host.Kernel.HostMarkerCall.creatingContext
#print axioms LeanCage.Host.Kernel.HostMarkerCall.creatingContext
