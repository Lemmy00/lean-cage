import FilesystemParentHandles
import FilesystemPublicationHandles
import FilesystemForeignNamespace
import FilesystemRootRegistration
import FilesystemBoundaries
import FilesystemFamilyAuthority
import FilesystemMkdirSources
import FilesystemReferenceLifetime
import FilesystemDirectoryObservations
import FilesystemIntervals
import FilesystemObservedAuthority
import FilesystemCommitAuthority
import FilesystemNamespaceState
import FilesystemMkdirOrigins
import FilesystemRunMkdirAuthority
import FilesystemPrimitiveSelection
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.Kernel.ensured_directory_handle
#print axioms LeanCage.Host.Kernel.ensured_directory_handle
#check LeanCage.Host.Kernel.public_at_borrow
#print axioms LeanCage.Host.Kernel.public_at_borrow
#check LeanCage.Host.Kernel.public_at_handle
#print axioms LeanCage.Host.Kernel.public_at_handle
#check LeanCage.Host.Kernel.descend_handle
#print axioms LeanCage.Host.Kernel.descend_handle
#check LeanCage.Host.Kernel.inspected_handle
#print axioms LeanCage.Host.Kernel.inspected_handle
#check LeanCage.Host.Kernel.parent_handle
#print axioms LeanCage.Host.Kernel.parent_handle
#check LeanCage.Host.Kernel.directory_open_alias
#print axioms LeanCage.Host.Kernel.directory_open_alias
#check LeanCage.Host.Kernel.fresh_container_alias
#print axioms LeanCage.Host.Kernel.fresh_container_alias
#check LeanCage.Host.Kernel.commit_parent_trace
#print axioms LeanCage.Host.Kernel.commit_parent_trace
#check LeanCage.Host.Kernel.selected_commit_handles
#print axioms LeanCage.Host.Kernel.selected_commit_handles
#check LeanCage.Host.Kernel.foreign_acquisition_safe
#print axioms LeanCage.Host.Kernel.foreign_acquisition_safe
#check LeanCage.Host.Kernel.foreign_entry_origin_not_private
#print axioms LeanCage.Host.Kernel.foreign_entry_origin_not_private
#check LeanCage.Host.Kernel.foreign_private_binding_earlier
#print axioms LeanCage.Host.Kernel.foreign_private_binding_earlier
#check LeanCage.Host.Kernel.foreign_namespace_family
#print axioms LeanCage.Host.Kernel.foreign_namespace_family
#check LeanCage.Host.Kernel.foreign_namespace_references
#print axioms LeanCage.Host.Kernel.foreign_namespace_references
#check LeanCage.Host.Kernel.foreign_namespace_well_formed
#print axioms LeanCage.Host.Kernel.foreign_namespace_well_formed
#check LeanCage.Host.Kernel.foreign_references_public_retained
#print axioms LeanCage.Host.Kernel.foreign_references_public_retained
#check LeanCage.Host.Kernel.foreign_reference_external_step
#print axioms LeanCage.Host.Kernel.foreign_reference_external_step
#check LeanCage.Host.Kernel.foreign_reference_journal_split
#print axioms LeanCage.Host.Kernel.foreign_reference_journal_split
#check LeanCage.Host.Kernel.register_root_at_commit
#print axioms LeanCage.Host.Kernel.register_root_at_commit
#check LeanCage.Host.Kernel.register_descendant_at_commit
#print axioms LeanCage.Host.Kernel.register_descendant_at_commit
#check LeanCage.Host.Kernel.register_root_authority_at_commit
#print axioms LeanCage.Host.Kernel.register_root_authority_at_commit
#check LeanCage.Host.Kernel.retained_registry_authorities
#print axioms LeanCage.Host.Kernel.retained_registry_authorities
#check LeanCage.Host.Kernel.published_registry_authorities
#print axioms LeanCage.Host.Kernel.published_registry_authorities
#check LeanCage.Host.Kernel.empty_root_boundaries
#print axioms LeanCage.Host.Kernel.empty_root_boundaries
#check LeanCage.Host.Kernel.root_boundaries_authority
#print axioms LeanCage.Host.Kernel.root_boundaries_authority
#check LeanCage.Host.Kernel.root_boundaries_retain
#print axioms LeanCage.Host.Kernel.root_boundaries_retain
#check LeanCage.Host.Kernel.root_boundaries_adjoin
#print axioms LeanCage.Host.Kernel.root_boundaries_adjoin
#check LeanCage.Host.Kernel.root_boundaries_descendant
#print axioms LeanCage.Host.Kernel.root_boundaries_descendant
#check LeanCage.Host.Kernel.root_boundaries_public_birth
#print axioms LeanCage.Host.Kernel.root_boundaries_public_birth
#check LeanCage.Host.Kernel.root_boundaries_published
#print axioms LeanCage.Host.Kernel.root_boundaries_published
#check LeanCage.Host.Kernel.empty_scope_directories
#print axioms LeanCage.Host.Kernel.empty_scope_directories
#check LeanCage.Host.Kernel.set_scope_directories
#print axioms LeanCage.Host.Kernel.set_scope_directories
#check LeanCage.Host.Kernel.clear_scope_directories
#print axioms LeanCage.Host.Kernel.clear_scope_directories
#check LeanCage.Host.Kernel.retained_private_directory_authority
#print axioms LeanCage.Host.Kernel.retained_private_directory_authority
#check LeanCage.Host.Kernel.created_private_directory_authority
#print axioms LeanCage.Host.Kernel.created_private_directory_authority
#check LeanCage.Host.Kernel.adjoined_private_directory_authority
#print axioms LeanCage.Host.Kernel.adjoined_private_directory_authority
#check LeanCage.Host.Kernel.passive_private_directory_mode
#print axioms LeanCage.Host.Kernel.passive_private_directory_mode
#check LeanCage.Host.Kernel.publication_private_directory_mode
#print axioms LeanCage.Host.Kernel.publication_private_directory_mode
#check LeanCage.Host.Kernel.publication_private_directory_program
#print axioms LeanCage.Host.Kernel.publication_private_directory_program
#check LeanCage.Host.Kernel.run_creation_private_directory_program
#print axioms LeanCage.Host.Kernel.run_creation_private_directory_program
#check LeanCage.Host.Kernel.run_cleanup_private_directory_program
#print axioms LeanCage.Host.Kernel.run_cleanup_private_directory_program
#check LeanCage.Host.Kernel.safe_private_directory_program
#print axioms LeanCage.Host.Kernel.safe_private_directory_program
#check LeanCage.Host.Kernel.image_private_directory_program
#print axioms LeanCage.Host.Kernel.image_private_directory_program
#check LeanCage.Host.Kernel.cleanup_private_directory_mode
#print axioms LeanCage.Host.Kernel.cleanup_private_directory_mode
#check LeanCage.Host.Kernel.validator_private_directory_mode
#print axioms LeanCage.Host.Kernel.validator_private_directory_mode
#check LeanCage.Host.Kernel.run_private_directory_mode
#print axioms LeanCage.Host.Kernel.run_private_directory_mode
#check LeanCage.Host.Kernel.entrypoint_private_directory_mode
#print axioms LeanCage.Host.Kernel.entrypoint_private_directory_mode
#check LeanCage.Host.Kernel.selected_private_directory_mode
#print axioms LeanCage.Host.Kernel.selected_private_directory_mode
#check LeanCage.Host.Kernel.new_raw_reference_has_fresh_description
#print axioms LeanCage.Host.Kernel.new_raw_reference_has_fresh_description
#check LeanCage.Host.Kernel.operation_reference_before
#print axioms LeanCage.Host.Kernel.operation_reference_before
#check LeanCage.Host.Kernel.actor_step_description_allocated
#print axioms LeanCage.Host.Kernel.actor_step_description_allocated
#check LeanCage.Host.Kernel.actor_step_presence
#print axioms LeanCage.Host.Kernel.actor_step_presence
#check LeanCage.Host.Kernel.actor_step_reference_before
#print axioms LeanCage.Host.Kernel.actor_step_reference_before
#check LeanCage.Host.Kernel.actor_journal_reference_continuity
#print axioms LeanCage.Host.Kernel.actor_journal_reference_continuity
#check LeanCage.Host.Kernel.directory_inspect_recorded
#print axioms LeanCage.Host.Kernel.directory_inspect_recorded
#check LeanCage.Host.Kernel.directory_open_recorded
#print axioms LeanCage.Host.Kernel.directory_open_recorded
#check LeanCage.Host.Kernel.directory_ensure_recorded
#print axioms LeanCage.Host.Kernel.directory_ensure_recorded
#check LeanCage.Host.Kernel.directory_public_recorded
#print axioms LeanCage.Host.Kernel.directory_public_recorded
#check LeanCage.Host.Kernel.directory_descend_recorded
#print axioms LeanCage.Host.Kernel.directory_descend_recorded
#check LeanCage.Host.Kernel.parent_recorded
#print axioms LeanCage.Host.Kernel.parent_recorded
#check LeanCage.Host.Kernel.temporary_parent_recorded
#print axioms LeanCage.Host.Kernel.temporary_parent_recorded
#check LeanCage.Host.Kernel.sampled_uid_is_host
#print axioms LeanCage.Host.Kernel.sampled_uid_is_host
#check LeanCage.Host.Kernel.journal_selected_prefix
#print axioms LeanCage.Host.Kernel.journal_selected_prefix
#check LeanCage.Host.Kernel.journal_between_selected
#print axioms LeanCage.Host.Kernel.journal_between_selected
#check LeanCage.Host.Kernel.safe_external_split
#print axioms LeanCage.Host.Kernel.safe_external_split
#check LeanCage.Host.Kernel.observed_directory_current_authority
#print axioms LeanCage.Host.Kernel.observed_directory_current_authority
#check LeanCage.Host.Kernel.selected_commit_authority
#print axioms LeanCage.Host.Kernel.selected_commit_authority
#check LeanCage.Host.Kernel.initial_namespace_custody
#print axioms LeanCage.Host.Kernel.initial_namespace_custody
#check LeanCage.Host.Kernel.ordinary_namespace_custody
#print axioms LeanCage.Host.Kernel.ordinary_namespace_custody
#check LeanCage.Host.Kernel.run_mkdir_site
#print axioms LeanCage.Host.Kernel.run_mkdir_site
#check LeanCage.Host.Kernel.entrypoint_mkdir_site
#print axioms LeanCage.Host.Kernel.entrypoint_mkdir_site
#check LeanCage.Host.Kernel.selected_mkdir_site
#print axioms LeanCage.Host.Kernel.selected_mkdir_site
#check LeanCage.Host.Kernel.run_creation_mkdir_authority
#print axioms LeanCage.Host.Kernel.run_creation_mkdir_authority
#check LeanCage.Host.Kernel.selected_filesystem_step
#print axioms LeanCage.Host.Kernel.selected_filesystem_step
#print LeanCage.Host.Kernel.ForeignReferences
#print axioms LeanCage.Host.Kernel.ForeignReferences
#print LeanCage.Host.Kernel.DirectoryView
#print axioms LeanCage.Host.Kernel.DirectoryView
#print LeanCage.Host.Kernel.PrivateDirectoryAuthority
#print axioms LeanCage.Host.Kernel.PrivateDirectoryAuthority
#print LeanCage.Host.Kernel.PrivateBoundaryAuthority
#print axioms LeanCage.Host.Kernel.PrivateBoundaryAuthority
#print LeanCage.Host.Kernel.ForeignReferenceSafe
#print axioms LeanCage.Host.Kernel.ForeignReferenceSafe
#print LeanCage.Host.Kernel.ForeignAcquisition
#print axioms LeanCage.Host.Kernel.ForeignAcquisition
#print LeanCage.Host.Kernel.ForeignEntryOrigin
#print axioms LeanCage.Host.Kernel.ForeignEntryOrigin
#print LeanCage.Host.Kernel.ForeignNamespaceObservation
#print axioms LeanCage.Host.Kernel.ForeignNamespaceObservation
#print LeanCage.Host.Kernel.ForeignNamespaceContract
#print axioms LeanCage.Host.Kernel.ForeignNamespaceContract
#print LeanCage.Host.Kernel.ForeignReferenceJournal
#print axioms LeanCage.Host.Kernel.ForeignReferenceJournal
#print LeanCage.Host.Kernel.RootBoundaries
#print axioms LeanCage.Host.Kernel.RootBoundaries
#print LeanCage.Host.Kernel.CreationTypeContract
#print axioms LeanCage.Host.Kernel.CreationTypeContract
#print LeanCage.Host.Kernel.ScopeDirectories
#print axioms LeanCage.Host.Kernel.ScopeDirectories
#print LeanCage.Host.Kernel.NamespaceCustody
#print axioms LeanCage.Host.Kernel.NamespaceCustody
#print LeanCage.Host.Kernel.RawReferenceLifetimeContract
#print axioms LeanCage.Host.Kernel.RawReferenceLifetimeContract
#print LeanCage.Host.Kernel.StatSample
#print axioms LeanCage.Host.Kernel.StatSample
#print LeanCage.Host.Kernel.UidSample
#print axioms LeanCage.Host.Kernel.UidSample
#print LeanCage.Host.Kernel.ObservedDirectory
#print axioms LeanCage.Host.Kernel.ObservedDirectory
#print LeanCage.Host.Kernel.ObservedParent
#print axioms LeanCage.Host.Kernel.ObservedParent
#print LeanCage.Host.Kernel.RunMkdirAuthority
#print axioms LeanCage.Host.Kernel.RunMkdirAuthority
#print LeanCage.Host.Kernel.CommitHandles
#print axioms LeanCage.Host.Kernel.CommitHandles
#print LeanCage.Host.Kernel.CommitAuthority
#print axioms LeanCage.Host.Kernel.CommitAuthority
#print LeanCage.Host.Kernel.RunMkdirSite
#print axioms LeanCage.Host.Kernel.RunMkdirSite
#print LeanCage.Host.Kernel.HostMkdirSite
#print axioms LeanCage.Host.Kernel.HostMkdirSite
#print LeanCage.Host.Kernel.PrivateDirectoryMode
#print axioms LeanCage.Host.Kernel.PrivateDirectoryMode
