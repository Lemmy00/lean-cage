import importlib.util
import pathlib
import sys
import types
import json

extension = '/localhome/milikic/sandbox-formalization/.tools/host/gateway/immutable-runtime/python/leancage/_host.abi3.so'
real_pathlib = pathlib
original = sys.modules['pathlib']
seen = []
created = []

class PathModule(types.ModuleType):
    def __getattr__(self, name):
        if name != 'Path':
            raise AttributeError(name)
        seen.append('Path lookup')
        if len(seen) == 1:
            inner_spec = importlib.util.spec_from_file_location('_host', extension)
            inner = importlib.util.module_from_spec(inner_spec)
            inner_spec.loader.exec_module(inner)
            created.append(inner)
            seen.append('nested native init returned')
        return real_pathlib.Path

sys.modules['pathlib'] = PathModule('pathlib')
try:
    outer_spec = importlib.util.spec_from_file_location('_host', extension)
    outer = importlib.util.module_from_spec(outer_spec)
    outer_spec.loader.exec_module(outer)
    print(json.dumps({'events': seen, 'nested_modules': len(created),
                      'different_outcome_classes': bool(created and outer.Outcome is not created[0].Outcome),
                      'outer_type': str(outer.Outcome),
                      'kind': 'bounded isolated native initialization callback; no engine or VM'}))
finally:
    sys.modules['pathlib'] = original
