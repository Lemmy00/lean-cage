import ArtifactsProofs
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option maxRecDepth 16384
#check @LeanCage.Host.Artifacts.blob_index_empty
#print axioms LeanCage.Host.Artifacts.blob_index_empty
#check @LeanCage.Host.Artifacts.blob_index_insert
#print axioms LeanCage.Host.Artifacts.blob_index_insert
#check @LeanCage.Host.Artifacts.checkBlobs_provenance
#print axioms LeanCage.Host.Artifacts.checkBlobs_provenance
#check @LeanCage.Host.Artifacts.checkBlobs_index_sound
#print axioms LeanCage.Host.Artifacts.checkBlobs_index_sound
#check @LeanCage.Host.Artifacts.blob_bounded_initial
#print axioms LeanCage.Host.Artifacts.blob_bounded_initial
#check @LeanCage.Host.Artifacts.blob_bounded_insert
#print axioms LeanCage.Host.Artifacts.blob_bounded_insert
#check @LeanCage.Host.Artifacts.checkBlobs_bounded
#print axioms LeanCage.Host.Artifacts.checkBlobs_bounded
#check @LeanCage.Host.Artifacts.checkBlobs_sequence
#print axioms LeanCage.Host.Artifacts.checkBlobs_sequence
#check @LeanCage.Host.Artifacts.pathBytes_bound
#print axioms LeanCage.Host.Artifacts.pathBytes_bound
#check @LeanCage.Host.Artifacts.export_path_bytes_bound
#print axioms LeanCage.Host.Artifacts.export_path_bytes_bound
#check @LeanCage.Host.Artifacts.capture_getD_bound
#print axioms LeanCage.Host.Artifacts.capture_getD_bound
#check @LeanCage.Host.Artifacts.validated_retained_bounds
#print axioms LeanCage.Host.Artifacts.validated_retained_bounds
#check @LeanCage.Host.Artifacts.componentParts_nonempty
#print axioms LeanCage.Host.Artifacts.componentParts_nonempty
#check @LeanCage.Host.Artifacts.componentParts_identity
#print axioms LeanCage.Host.Artifacts.componentParts_identity
#check @LeanCage.Host.Artifacts.pathComponents_identity
#print axioms LeanCage.Host.Artifacts.pathComponents_identity
#check @LeanCage.Host.Artifacts.unhexLoop_size
#print axioms LeanCage.Host.Artifacts.unhexLoop_size
#check @LeanCage.Host.Artifacts.decodePath_identity
#print axioms LeanCage.Host.Artifacts.decodePath_identity
#check @LeanCage.Host.Artifacts.splitFields_count
#print axioms LeanCage.Host.Artifacts.splitFields_count
#check @LeanCage.Host.Artifacts.validateExport_execution
#print axioms LeanCage.Host.Artifacts.validateExport_execution
#check @LeanCage.Host.Artifacts.validate_execution
#print axioms LeanCage.Host.Artifacts.validate_execution
#check @LeanCage.Host.Artifacts.validateExport_sound
#print axioms LeanCage.Host.Artifacts.validateExport_sound
#check @LeanCage.Host.Artifacts.validateExport_omitted
#print axioms LeanCage.Host.Artifacts.validateExport_omitted
#check @LeanCage.Host.Artifacts.uncommitted_absent
#print axioms LeanCage.Host.Artifacts.uncommitted_absent
#check @LeanCage.Host.Artifacts.validate_sound
#print axioms LeanCage.Host.Artifacts.validate_sound
#check @LeanCage.Host.Artifacts.actual_transport_artifacts
#print axioms LeanCage.Host.Artifacts.actual_transport_artifacts
#check @LeanCage.Host.Artifacts.hashSeen_meaning
#print axioms LeanCage.Host.Artifacts.hashSeen_meaning
#check @LeanCage.Host.Artifacts.hashOnly_bind
#print axioms LeanCage.Host.Artifacts.hashOnly_bind
#check @LeanCage.Host.Artifacts.hashOnly_hash
#print axioms LeanCage.Host.Artifacts.hashOnly_hash
#check @LeanCage.Host.Artifacts.checkBlobs_hashOnly
#print axioms LeanCage.Host.Artifacts.checkBlobs_hashOnly
#check @LeanCage.Host.Artifacts.validateExport_hashOnly
#print axioms LeanCage.Host.Artifacts.validateExport_hashOnly
#check @LeanCage.Host.Artifacts.validate_hashOnly
#print axioms LeanCage.Host.Artifacts.validate_hashOnly
#check @LeanCage.Host.Artifacts.hashOnly_prefix
#print axioms LeanCage.Host.Artifacts.hashOnly_prefix
#check @LeanCage.Host.Artifacts.validate_prefix_no_write
#print axioms LeanCage.Host.Artifacts.validate_prefix_no_write
#check @LeanCage.Host.Artifacts.hash_returned
#print axioms LeanCage.Host.Artifacts.hash_returned
#check @LeanCage.Host.Artifacts.hashSeen_append_left
#print axioms LeanCage.Host.Artifacts.hashSeen_append_left
#check @LeanCage.Host.Artifacts.hashSeen_append_right
#print axioms LeanCage.Host.Artifacts.hashSeen_append_right
#check @LeanCage.Host.Artifacts.bindFiles_retains
#print axioms LeanCage.Host.Artifacts.bindFiles_retains
#check @LeanCage.Host.Artifacts.bindFiles_provenance
#print axioms LeanCage.Host.Artifacts.bindFiles_provenance
#check @LeanCage.Host.Artifacts.bindFiles_bytes
#print axioms LeanCage.Host.Artifacts.bindFiles_bytes
#check @LeanCage.Host.Artifacts.bindFiles_count
#print axioms LeanCage.Host.Artifacts.bindFiles_count
#check @LeanCage.Host.Artifacts.bindFiles_required
#print axioms LeanCage.Host.Artifacts.bindFiles_required
#check @LeanCage.Host.Artifacts.bindFiles_complete
#print axioms LeanCage.Host.Artifacts.bindFiles_complete
#check @LeanCage.Host.Artifacts.fileNames_member
#print axioms LeanCage.Host.Artifacts.fileNames_member
#check @LeanCage.Host.Artifacts.fileNames_unique
#print axioms LeanCage.Host.Artifacts.fileNames_unique
#check @LeanCage.Host.Artifacts.bindFiles_names
#print axioms LeanCage.Host.Artifacts.bindFiles_names
#check @LeanCage.Host.Artifacts.node_partition_count
#print axioms LeanCage.Host.Artifacts.node_partition_count
#check @LeanCage.Host.Artifacts.node_omitted_count
#print axioms LeanCage.Host.Artifacts.node_omitted_count
#check @LeanCage.Host.Artifacts.manifest_directory_member
#print axioms LeanCage.Host.Artifacts.manifest_directory_member
#check @LeanCage.Host.Artifacts.manifest_omitted_member
#print axioms LeanCage.Host.Artifacts.manifest_omitted_member
#check @LeanCage.Host.Artifacts.Witness.replay_returns
#print axioms LeanCage.Host.Artifacts.Witness.replay_returns
#check @LeanCage.Host.Artifacts.manifest_initial
#print axioms LeanCage.Host.Artifacts.manifest_initial
#check @LeanCage.Host.Artifacts.appendNode_fields
#print axioms LeanCage.Host.Artifacts.appendNode_fields
#check @LeanCage.Host.Artifacts.manifest_append
#print axioms LeanCage.Host.Artifacts.manifest_append
#check @LeanCage.Host.Artifacts.scanManifest_invariant
#print axioms LeanCage.Host.Artifacts.scanManifest_invariant
#check @LeanCage.Host.Artifacts.parseManifest_sound
#print axioms LeanCage.Host.Artifacts.parseManifest_sound
#check @LeanCage.Host.Artifacts.manifest_hierarchy
#print axioms LeanCage.Host.Artifacts.manifest_hierarchy
#check @LeanCage.Host.Artifacts.except_bind_ok
#print axioms LeanCage.Host.Artifacts.except_bind_ok
#check @LeanCage.Host.Artifacts.reportFields_decoded
#print axioms LeanCage.Host.Artifacts.reportFields_decoded
#check @LeanCage.Host.Artifacts.readNatural_bounded
#print axioms LeanCage.Host.Artifacts.readNatural_bounded
#check @LeanCage.Host.Artifacts.readOptionalNatural_bounded
#print axioms LeanCage.Host.Artifacts.readOptionalNatural_bounded
#check @LeanCage.Host.Artifacts.checkControl_sound
#print axioms LeanCage.Host.Artifacts.checkControl_sound
#check @LeanCage.Host.Artifacts.checkReport_sound
#print axioms LeanCage.Host.Artifacts.checkReport_sound
#check @LeanCage.Host.Artifacts.report_run0_entry
#print axioms LeanCage.Host.Artifacts.report_run0_entry
#check @LeanCage.Host.Artifacts.report_preflight_entry
#print axioms LeanCage.Host.Artifacts.report_preflight_entry
#check @LeanCage.Host.Artifacts.noArtifacts_fields
#print axioms LeanCage.Host.Artifacts.noArtifacts_fields
#check @LeanCage.Host.Artifacts.capture_present_bound
#print axioms LeanCage.Host.Artifacts.capture_present_bound
#check @LeanCage.Host.Artifacts.capture_known_present
#print axioms LeanCage.Host.Artifacts.capture_known_present
#check @LeanCage.Host.Artifacts.capture_known_absent
#print axioms LeanCage.Host.Artifacts.capture_known_absent
#check @LeanCage.Host.Artifacts.knownReport_preserved
#print axioms LeanCage.Host.Artifacts.knownReport_preserved
#check @LeanCage.Host.Artifacts.Witness.useful_program_completes
#print axioms LeanCage.Host.Artifacts.Witness.useful_program_completes
#check @LeanCage.Host.Artifacts.Witness.useful_actual_export
#print axioms LeanCage.Host.Artifacts.Witness.useful_actual_export
#check @LeanCage.Host.Artifacts.Witness.useful_full_completes
#print axioms LeanCage.Host.Artifacts.Witness.useful_full_completes
#check @LeanCage.Host.Artifacts.Witness.useful_actual_validation
#print axioms LeanCage.Host.Artifacts.Witness.useful_actual_validation
#check @LeanCage.Host.Artifacts.Witness.invalid_hash_rejected
#print axioms LeanCage.Host.Artifacts.Witness.invalid_hash_rejected
#check @LeanCage.Host.Artifacts.Witness.omitted_count_rejected
#print axioms LeanCage.Host.Artifacts.Witness.omitted_count_rejected
#check @LeanCage.Host.Artifacts.Witness.missing_blob_rejected
#print axioms LeanCage.Host.Artifacts.Witness.missing_blob_rejected
#check @LeanCage.Host.Artifacts.Witness.duplicate_path_rejected
#print axioms LeanCage.Host.Artifacts.Witness.duplicate_path_rejected
#check @LeanCage.Host.Artifacts.Witness.missing_parent_rejected
#print axioms LeanCage.Host.Artifacts.Witness.missing_parent_rejected
#check @LeanCage.Host.Artifacts.Witness.conflicting_parent_rejected
#print axioms LeanCage.Host.Artifacts.Witness.conflicting_parent_rejected
#check @LeanCage.Host.Artifacts.Witness.leading_zero_rejected
#print axioms LeanCage.Host.Artifacts.Witness.leading_zero_rejected
#check @LeanCage.Host.Artifacts.Witness.invalid_utf8_rejected
#print axioms LeanCage.Host.Artifacts.Witness.invalid_utf8_rejected
#check @LeanCage.Host.Artifacts.Witness.traversal_rejected
#print axioms LeanCage.Host.Artifacts.Witness.traversal_rejected
#check @LeanCage.Host.Artifacts.Witness.uppercase_hex_rejected
#print axioms LeanCage.Host.Artifacts.Witness.uppercase_hex_rejected
#print LeanCage.Host.Artifacts.Expected
#print axioms LeanCage.Host.Artifacts.Expected
#print LeanCage.Host.Artifacts.ValidPath
#print axioms LeanCage.Host.Artifacts.ValidPath
#print LeanCage.Host.Artifacts.ExportPath
#print axioms LeanCage.Host.Artifacts.ExportPath
#print LeanCage.Host.Artifacts.ExportPath.components
#print axioms LeanCage.Host.Artifacts.ExportPath.components
#print LeanCage.Host.Artifacts.componentParts
#print axioms LeanCage.Host.Artifacts.componentParts
#print LeanCage.Host.Artifacts.pathComponents
#print axioms LeanCage.Host.Artifacts.pathComponents
#print LeanCage.Host.Artifacts.Report
#print axioms LeanCage.Host.Artifacts.Report
#print LeanCage.Host.Artifacts.ValidatedFile
#print axioms LeanCage.Host.Artifacts.ValidatedFile
#print LeanCage.Host.Artifacts.Validated
#print axioms LeanCage.Host.Artifacts.Validated
#print LeanCage.Host.Artifacts.CheckedBlob
#print axioms LeanCage.Host.Artifacts.CheckedBlob
#print LeanCage.Host.Artifacts.ReportDecoded
#print axioms LeanCage.Host.Artifacts.ReportDecoded
#print LeanCage.Host.Artifacts.ControlValid
#print axioms LeanCage.Host.Artifacts.ControlValid
#print LeanCage.Host.Artifacts.ReportValid
#print axioms LeanCage.Host.Artifacts.ReportValid
#print LeanCage.Host.Artifacts.ManifestInvariant
#print axioms LeanCage.Host.Artifacts.ManifestInvariant
#print LeanCage.Host.Artifacts.BlobBounded
#print axioms LeanCage.Host.Artifacts.BlobBounded
#print LeanCage.Host.Artifacts.FileFromNode
#print axioms LeanCage.Host.Artifacts.FileFromNode
#print LeanCage.Host.Artifacts.HashOnly
#print axioms LeanCage.Host.Artifacts.HashOnly
#print LeanCage.Host.Artifacts.HashSeen
#print axioms LeanCage.Host.Artifacts.HashSeen
#print LeanCage.Host.Artifacts.ExportValid
#print axioms LeanCage.Host.Artifacts.ExportValid
#print LeanCage.Host.Artifacts.ArtifactsValid
#print axioms LeanCage.Host.Artifacts.ArtifactsValid
#print LeanCage.Host.Artifacts.HashReplyContract
#print axioms LeanCage.Host.Artifacts.HashReplyContract
#print LeanCage.Host.Artifacts.checkReport
#print axioms LeanCage.Host.Artifacts.checkReport
#print LeanCage.Host.Artifacts.checkControl
#print axioms LeanCage.Host.Artifacts.checkControl
#print LeanCage.Host.Artifacts.decodePath
#print axioms LeanCage.Host.Artifacts.decodePath
#print LeanCage.Host.Artifacts.splitFields
#print axioms LeanCage.Host.Artifacts.splitFields
#print LeanCage.Host.Artifacts.parseLine
#print axioms LeanCage.Host.Artifacts.parseLine
#print LeanCage.Host.Artifacts.scanManifest
#print axioms LeanCage.Host.Artifacts.scanManifest
#print LeanCage.Host.Artifacts.parseManifest
#print axioms LeanCage.Host.Artifacts.parseManifest
#print LeanCage.Host.Artifacts.checkBlobs
#print axioms LeanCage.Host.Artifacts.checkBlobs
#print LeanCage.Host.Artifacts.bindFiles
#print axioms LeanCage.Host.Artifacts.bindFiles
#print LeanCage.Host.Artifacts.validateExport
#print axioms LeanCage.Host.Artifacts.validateExport
#print LeanCage.Host.Artifacts.validate
#print axioms LeanCage.Host.Artifacts.validate
#print LeanCage.Host.Artifacts.assemble
#print axioms LeanCage.Host.Artifacts.assemble
