import FilesystemJointExclusives
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
#check @LeanCage.Host.Kernel.actual_source_exclusive_publication_joint
#print axioms LeanCage.Host.Kernel.actual_source_exclusive_publication_joint
#check @LeanCage.Host.Kernel.actual_run_file_publication_joint
#print axioms LeanCage.Host.Kernel.actual_run_file_publication_joint
#check @LeanCage.Host.Kernel.actual_preparing_exclusive_joint
#print axioms LeanCage.Host.Kernel.actual_preparing_exclusive_joint
#check @LeanCage.Host.Kernel.entrypoint_exclusive_site
#print axioms LeanCage.Host.Kernel.entrypoint_exclusive_site
#check @LeanCage.Host.Kernel.PublicationExclusive.preparing_of_exclusive
#print axioms LeanCage.Host.Kernel.PublicationExclusive.preparing_of_exclusive
#check @LeanCage.Host.Publication.preparing_exclusive_frontier
#print axioms LeanCage.Host.Publication.preparing_exclusive_frontier
