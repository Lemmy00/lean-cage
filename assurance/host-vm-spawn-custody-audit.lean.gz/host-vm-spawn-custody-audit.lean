import VirtualMachineCustodyProofs
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.VirtualMachine.spawn_error_source
#print axioms LeanCage.Host.VirtualMachine.spawn_error_source
#check LeanCage.Host.VirtualMachine.dispatch_spawn_error_source
#print axioms LeanCage.Host.VirtualMachine.dispatch_spawn_error_source
#check LeanCage.Host.VirtualMachine.spawn_error_report_preserved
#print axioms LeanCage.Host.VirtualMachine.spawn_error_report_preserved
#check LeanCage.Host.VirtualMachine.unknown_cleanup_prefix
#print axioms LeanCage.Host.VirtualMachine.unknown_cleanup_prefix
#check LeanCage.Host.VirtualMachine.spawn_error_cleanup_prefix
#print axioms LeanCage.Host.VirtualMachine.spawn_error_cleanup_prefix
#print LeanCage.Host.VirtualMachine.run
#print axioms LeanCage.Host.VirtualMachine.run
#print LeanCage.Host.VirtualMachine.spawnErrorResult
#print axioms LeanCage.Host.VirtualMachine.spawnErrorResult
#print LeanCage.Host.VirtualMachine.spawnErrorInput
#print axioms LeanCage.Host.VirtualMachine.spawnErrorInput
#print LeanCage.Host.cleanupRun
#print axioms LeanCage.Host.cleanupRun
#print LeanCage.Host.receive
#print axioms LeanCage.Host.receive
