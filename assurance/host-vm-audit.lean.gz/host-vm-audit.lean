import VirtualMachineProofs
set_option pp.all true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.maxSteps 1000000
set_option pp.deepTerms true
#check LeanCage.Host.VirtualMachine.arguments_paths
#print axioms LeanCage.Host.VirtualMachine.arguments_paths
#check LeanCage.Host.VirtualMachine.arguments_environment
#print axioms LeanCage.Host.VirtualMachine.arguments_environment
#check LeanCage.Host.VirtualMachine.connect_source
#print axioms LeanCage.Host.VirtualMachine.connect_source
#check LeanCage.Host.VirtualMachine.connected_fd_bound
#print axioms LeanCage.Host.VirtualMachine.connected_fd_bound
#check LeanCage.Host.VirtualMachine.read_budget_bound
#print axioms LeanCage.Host.VirtualMachine.read_budget_bound
#check LeanCage.Host.VirtualMachine.consume_factor
#print axioms LeanCage.Host.VirtualMachine.consume_factor
#check LeanCage.Host.VirtualMachine.consume_returns
#print axioms LeanCage.Host.VirtualMachine.consume_returns
#check LeanCage.Host.VirtualMachine.consume_connection
#print axioms LeanCage.Host.VirtualMachine.consume_connection
#check LeanCage.Host.VirtualMachine.collect_source
#print axioms LeanCage.Host.VirtualMachine.collect_source
#check LeanCage.Host.VirtualMachine.consume_result_bounded
#print axioms LeanCage.Host.VirtualMachine.consume_result_bounded
#check LeanCage.Host.VirtualMachine.boot_overflow_retains
#print axioms LeanCage.Host.VirtualMachine.boot_overflow_retains
#check LeanCage.Host.VirtualMachine.diagnostic_overflow_retains
#print axioms LeanCage.Host.VirtualMachine.diagnostic_overflow_retains
#check LeanCage.Host.VirtualMachine.stream_source_one
#print axioms LeanCage.Host.VirtualMachine.stream_source_one
#check LeanCage.Host.VirtualMachine.consume_result_source
#print axioms LeanCage.Host.VirtualMachine.consume_result_source
#check LeanCage.Host.VirtualMachine.consume_source
#print axioms LeanCage.Host.VirtualMachine.consume_source
#check LeanCage.Host.VirtualMachine.after_send_progress
#print axioms LeanCage.Host.VirtualMachine.after_send_progress
#check LeanCage.Host.VirtualMachine.connected_progress
#print axioms LeanCage.Host.VirtualMachine.connected_progress
#check LeanCage.Host.VirtualMachine.loop_progress
#print axioms LeanCage.Host.VirtualMachine.loop_progress
#check LeanCage.Host.VirtualMachine.read_safe_bind
#print axioms LeanCage.Host.VirtualMachine.read_safe_bind
#check LeanCage.Host.VirtualMachine.read_safe_prefix
#print axioms LeanCage.Host.VirtualMachine.read_safe_prefix
#check LeanCage.Host.VirtualMachine.prefix_of_return_bind
#print axioms LeanCage.Host.VirtualMachine.prefix_of_return_bind
#check LeanCage.Host.VirtualMachine.perform_read_safe
#print axioms LeanCage.Host.VirtualMachine.perform_read_safe
#check LeanCage.Host.VirtualMachine.runtime_read_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_read_safe
#check LeanCage.Host.VirtualMachine.consume_read_safe
#print axioms LeanCage.Host.VirtualMachine.consume_read_safe
#check LeanCage.Host.VirtualMachine.runtime_clock_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_clock_safe
#check LeanCage.Host.VirtualMachine.runtime_poll_safe
#print axioms LeanCage.Host.VirtualMachine.runtime_poll_safe
#check LeanCage.Host.VirtualMachine.close_read_safe
#print axioms LeanCage.Host.VirtualMachine.close_read_safe
#check LeanCage.Host.VirtualMachine.connect_read_safe
#print axioms LeanCage.Host.VirtualMachine.connect_read_safe
#check LeanCage.Host.VirtualMachine.consume_ready_read_safe
#print axioms LeanCage.Host.VirtualMachine.consume_ready_read_safe
#check LeanCage.Host.VirtualMachine.after_send_read_safe
#print axioms LeanCage.Host.VirtualMachine.after_send_read_safe
#check LeanCage.Host.VirtualMachine.connected_read_safe
#print axioms LeanCage.Host.VirtualMachine.connected_read_safe
#check LeanCage.Host.VirtualMachine.loop_read_safe
#print axioms LeanCage.Host.VirtualMachine.loop_read_safe
#check LeanCage.Host.VirtualMachine.observe_exit_read_safe
#print axioms LeanCage.Host.VirtualMachine.observe_exit_read_safe
#check LeanCage.Host.VirtualMachine.reap_read_safe
#print axioms LeanCage.Host.VirtualMachine.reap_read_safe
#check LeanCage.Host.VirtualMachine.final_program_read_safe
#print axioms LeanCage.Host.VirtualMachine.final_program_read_safe
#check LeanCage.Host.VirtualMachine.run_read_safe
#print axioms LeanCage.Host.VirtualMachine.run_read_safe
#check LeanCage.Host.VirtualMachine.actual_prefix_read_bounds
#print axioms LeanCage.Host.VirtualMachine.actual_prefix_read_bounds
#check LeanCage.Host.VirtualMachine.lost_read_not_observation
#print axioms LeanCage.Host.VirtualMachine.lost_read_not_observation
#check LeanCage.Host.VirtualMachine.program_pure_bind
#print axioms LeanCage.Host.VirtualMachine.program_pure_bind
#check LeanCage.Host.VirtualMachine.program_bind_assoc
#print axioms LeanCage.Host.VirtualMachine.program_bind_assoc
#check LeanCage.Host.VirtualMachine.program_bind_except
#print axioms LeanCage.Host.VirtualMachine.program_bind_except
#check LeanCage.Host.VirtualMachine.Progress.unchanged
#print axioms LeanCage.Host.VirtualMachine.Progress.unchanged
#check LeanCage.Host.VirtualMachine.Progress.refl
#print axioms LeanCage.Host.VirtualMachine.Progress.refl
#check LeanCage.Host.VirtualMachine.Progress.trans
#print axioms LeanCage.Host.VirtualMachine.Progress.trans
#check LeanCage.Host.VirtualMachine.Progress.fail
#print axioms LeanCage.Host.VirtualMachine.Progress.fail
#check LeanCage.Host.VirtualMachine.consume_progress
#print axioms LeanCage.Host.VirtualMachine.consume_progress
#check LeanCage.Host.VirtualMachine.events_selected
#print axioms LeanCage.Host.VirtualMachine.events_selected
#check LeanCage.Host.VirtualMachine.consume_ready_progress
#print axioms LeanCage.Host.VirtualMachine.consume_ready_progress
#check LeanCage.Host.VirtualMachine.read_subsequence_member
#print axioms LeanCage.Host.VirtualMachine.read_subsequence_member
#check LeanCage.Host.VirtualMachine.actual_finished_origin
#print axioms LeanCage.Host.VirtualMachine.actual_finished_origin
#check LeanCage.Host.VirtualMachine.actual_run_bounds
#print axioms LeanCage.Host.VirtualMachine.actual_run_bounds
#check LeanCage.Host.VirtualMachine.reap_frame
#print axioms LeanCage.Host.VirtualMachine.reap_frame
#check LeanCage.Host.VirtualMachine.initial_program_progress
#print axioms LeanCage.Host.VirtualMachine.initial_program_progress
#check LeanCage.Host.VirtualMachine.final_program_frame
#print axioms LeanCage.Host.VirtualMachine.final_program_frame
#check LeanCage.Host.VirtualMachine.finish_result_source
#print axioms LeanCage.Host.VirtualMachine.finish_result_source
#check LeanCage.Host.VirtualMachine.run_source
#print axioms LeanCage.Host.VirtualMachine.run_source
#check LeanCage.Host.VirtualMachine.runtime_read_data
#print axioms LeanCage.Host.VirtualMachine.runtime_read_data
#check LeanCage.Host.VirtualMachine.runtime_read_eof
#print axioms LeanCage.Host.VirtualMachine.runtime_read_eof
#check LeanCage.Host.VirtualMachine.read_subsequence_append
#print axioms LeanCage.Host.VirtualMachine.read_subsequence_append
#check LeanCage.Host.VirtualMachine.read_subsequence_empty
#print axioms LeanCage.Host.VirtualMachine.read_subsequence_empty
#check LeanCage.Host.VirtualMachine.read_subsequence_mono
#print axioms LeanCage.Host.VirtualMachine.read_subsequence_mono
#check LeanCage.Host.VirtualMachine.stream_source_refl
#print axioms LeanCage.Host.VirtualMachine.stream_source_refl
#check LeanCage.Host.VirtualMachine.stream_source_append
#print axioms LeanCage.Host.VirtualMachine.stream_source_append
#check LeanCage.Host.VirtualMachine.runtime_read_useful
#print axioms LeanCage.Host.VirtualMachine.runtime_read_useful
#check LeanCage.Host.VirtualMachine.runtime_eof_useful
#print axioms LeanCage.Host.VirtualMachine.runtime_eof_useful
#check LeanCage.Host.VirtualMachine.Witness.data_delivered
#print axioms LeanCage.Host.VirtualMachine.Witness.data_delivered
#check LeanCage.Host.VirtualMachine.Witness.eof_observed
#print axioms LeanCage.Host.VirtualMachine.Witness.eof_observed
#check LeanCage.Host.VirtualMachine.Witness.actual_useful_consumer
#print axioms LeanCage.Host.VirtualMachine.Witness.actual_useful_consumer
#check LeanCage.Host.VirtualMachine.Witness.useful_framed
#print axioms LeanCage.Host.VirtualMachine.Witness.useful_framed
#check LeanCage.Host.VirtualMachine.Witness.no_eof_incomplete
#print axioms LeanCage.Host.VirtualMachine.Witness.no_eof_incomplete
#check LeanCage.Host.VirtualMachine.Witness.actual_lost_eof
#print axioms LeanCage.Host.VirtualMachine.Witness.actual_lost_eof
#print LeanCage.Host.VirtualMachine.ReadOrigin
#print axioms LeanCage.Host.VirtualMachine.ReadOrigin
#print LeanCage.Host.VirtualMachine.ReadSubsequence
#print axioms LeanCage.Host.VirtualMachine.ReadSubsequence
#print LeanCage.Host.VirtualMachine.StreamSource
#print axioms LeanCage.Host.VirtualMachine.StreamSource
#print LeanCage.Host.VirtualMachine.Progress
#print axioms LeanCage.Host.VirtualMachine.Progress
#print LeanCage.Host.VirtualMachine.Connected
#print axioms LeanCage.Host.VirtualMachine.Connected
#print LeanCage.Host.VirtualMachine.ReadSafe
#print axioms LeanCage.Host.VirtualMachine.ReadSafe
#print LeanCage.Host.VirtualMachine.BoundedEffect
#print axioms LeanCage.Host.VirtualMachine.BoundedEffect
#print LeanCage.Host.VirtualMachine.BoundedEvent
#print axioms LeanCage.Host.VirtualMachine.BoundedEvent
#print LeanCage.Host.VirtualMachine.FinishedOrigin
#print axioms LeanCage.Host.VirtualMachine.FinishedOrigin
#print LeanCage.Host.VirtualMachine.consumeResult
#print axioms LeanCage.Host.VirtualMachine.consumeResult
#print LeanCage.Host.VirtualMachine.readBudget
#print axioms LeanCage.Host.VirtualMachine.readBudget
#print LeanCage.Host.VirtualMachine.afterSend
#print axioms LeanCage.Host.VirtualMachine.afterSend
#print LeanCage.Host.VirtualMachine.connectedProgram
#print axioms LeanCage.Host.VirtualMachine.connectedProgram
#print LeanCage.Host.VirtualMachine.initialProgram
#print axioms LeanCage.Host.VirtualMachine.initialProgram
#print LeanCage.Host.VirtualMachine.finalProgram
#print axioms LeanCage.Host.VirtualMachine.finalProgram
#print LeanCage.Host.VirtualMachine.arguments
#print axioms LeanCage.Host.VirtualMachine.arguments
#print LeanCage.Host.VirtualMachine.consume
#print axioms LeanCage.Host.VirtualMachine.consume
#print LeanCage.Host.VirtualMachine.loop
#print axioms LeanCage.Host.VirtualMachine.loop
#print LeanCage.Host.VirtualMachine.run
#print axioms LeanCage.Host.VirtualMachine.run
#print LeanCage.Host.Runtime.read
#print axioms LeanCage.Host.Runtime.read
