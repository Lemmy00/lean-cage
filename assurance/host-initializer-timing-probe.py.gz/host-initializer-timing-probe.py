import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import pathlib
import sys
import types

extension = Path('/localhome/milikic/sandbox-formalization/.tools/host/gateway/initialization-runtime/python/leancage/_host.abi3.so')
real_path = pathlib.Path
original = sys.modules['pathlib']
events = []
callback_phases = []
retained = []
seen = set()
path_callback_active = False
path_callback_returned = False
module_creation_returned = False


def observe(phase, information):
    if not path_callback_active:
        return
    callback_phases.append(phase)
    for candidate in object.__subclasses__():
        module = type.__getattribute__(candidate, '__module__')
        name = type.__getattribute__(candidate, '__name__')
        if module == 'leancage._host' and name in ('Workspace', 'Outcome', 'Cancellation'):
            key = (name, id(candidate))
            if key not in seen:
                seen.add(key)
                retained.append(candidate)
                events.append(dict(name=name, gc_phase=phase,
                    awaited_path_lookup_active=path_callback_active,
                    awaited_path_lookup_returned=path_callback_returned,
                    module_creation_returned=module_creation_returned))


class PathModule(types.ModuleType):
    def __getattr__(self, name):
        global path_callback_active, path_callback_returned
        if name != 'Path':
            raise AttributeError(name)
        path_callback_active = True
        try:
            gc.collect()
        finally:
            path_callback_active = False
        path_callback_returned = True
        return real_path


spec = importlib.util.spec_from_file_location('subclass_initializer_probe._host', str(extension))
gc.callbacks.append(observe)
sys.modules['pathlib'] = PathModule('pathlib')
try:
    module = importlib.util.module_from_spec(spec)
    module_creation_returned = True
finally:
    sys.modules['pathlib'] = original
    gc.callbacks.remove(observe)
spec.loader.exec_module(module)
assert path_callback_returned
print(json.dumps(dict(events=events, gc_callback_phases=callback_phases,
    retained_classes_match_returned={type.__getattribute__(candidate, '__name__'):
        candidate is getattr(module, type.__getattribute__(candidate, '__name__'))
        for candidate in retained},
    extension=str(extension), sha256=hashlib.file_digest(extension.open('rb'), 'sha256').hexdigest(),
    causal_boundary='gc callback ran synchronously inside the Path attribute callback awaited by actual host_initialize before that callback returned',
    scope='read-only public weak subclass-registry probe in an initializer callback; no object constructors, engine, VM or workload')))
