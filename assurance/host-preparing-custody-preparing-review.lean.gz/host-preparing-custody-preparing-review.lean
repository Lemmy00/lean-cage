import FilesystemJointMkdirs
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
#check @LeanCage.Host.Kernel.actual_source_mkdir_publication_joint
#print axioms LeanCage.Host.Kernel.actual_source_mkdir_publication_joint
#check @LeanCage.Host.Kernel.actual_preparing_mkdir_joint
#print axioms LeanCage.Host.Kernel.actual_preparing_mkdir_joint
#check @LeanCage.Host.Kernel.actual_preparing_root_from_resources
#print axioms LeanCage.Host.Kernel.actual_preparing_root_from_resources
#check @LeanCage.Host.Publication.preparing_mkdir_frontier
#print axioms LeanCage.Host.Publication.preparing_mkdir_frontier
