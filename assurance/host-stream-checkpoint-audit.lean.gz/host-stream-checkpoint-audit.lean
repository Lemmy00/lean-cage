import GatewayStreamJournal
set_option pp.all true
set_option pp.maxSteps 10000000
#check @LeanCage.Host.PrivateStreams.actual_engine_response_unique
#print axioms LeanCage.Host.PrivateStreams.actual_engine_response_unique
#check @LeanCage.Host.PrivateStreams.pending_response_raw
#print axioms LeanCage.Host.PrivateStreams.pending_response_raw
#check @LeanCage.Host.PrivateStreams.pending_response_sequence
#print axioms LeanCage.Host.PrivateStreams.pending_response_sequence
#check @LeanCage.Host.PrivateStreams.engine_response_from_inherited
#print axioms LeanCage.Host.PrivateStreams.engine_response_from_inherited
#check @LeanCage.Host.PrivateStreams.ObservedStep.written_origin
#print axioms LeanCage.Host.PrivateStreams.ObservedStep.written_origin
#check @LeanCage.Host.PrivateStreams.ObservedJournal.birth_cut
#print axioms LeanCage.Host.PrivateStreams.ObservedJournal.birth_cut
#check @LeanCage.Host.PrivateStreams.actual_received_prefix_from_birth
#print axioms LeanCage.Host.PrivateStreams.actual_received_prefix_from_birth
#check @LeanCage.Host.PrivateStreams.native_read_code
#print axioms LeanCage.Host.PrivateStreams.native_read_code
